"""Trace context propagation via ``contextvars``.

Every governed invocation (``wrap()`` / ``guard()``) sets the
trace/session/user/project context.  Downstream components
(``ChatModel``, guards, audit) read from here so Langfuse spans and
audit events are correlated automatically.

Project identity
----------------
``project_id`` travels alongside the trace so that every LLM call,
governance check, and audit event carries the identity of the project
that triggered it.
"""

from __future__ import annotations

import contextvars

_trace_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "langfuse_trace_id", default=None
)
_session_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "langfuse_session_id", default=None
)
_user_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "langfuse_user_id", default=None
)
_project_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "ab_project_id", default=None
)
_workflow_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "ab_workflow_id", default=None
)


# -- setters ----------------------------------------------------


def set_current_trace_id(trace_id: str | None) -> contextvars.Token[str | None]:
    return _trace_id_var.set(trace_id)


def set_session_id(session_id: str | None) -> contextvars.Token[str | None]:
    return _session_id_var.set(session_id)


def set_user_id(user_id: str | None) -> contextvars.Token[str | None]:
    return _user_id_var.set(user_id)


def set_project_id(project_id: str | None) -> contextvars.Token[str | None]:
    return _project_id_var.set(project_id)


def set_workflow_id(workflow_id: str | None) -> contextvars.Token[str | None]:
    return _workflow_id_var.set(workflow_id)


# -- getters ----------------------------------------------------


def get_current_trace_id() -> str | None:
    return _trace_id_var.get()


def get_session_id() -> str | None:
    return _session_id_var.get()


def get_user_id() -> str | None:
    return _user_id_var.get()


def get_project_id() -> str | None:
    return _project_id_var.get()


def get_workflow_id() -> str | None:
    return _workflow_id_var.get()
