"""Tracing decorators for non-LLM operations.

LLM calls are auto-traced by ``langfuse.openai``.  For non-LLM work
(tool calls, retrieval, custom logic) use ``@traced`` to get a Langfuse span.
"""

from __future__ import annotations

import asyncio
import functools
import time
from typing import Any, Callable

from agentic_blueprint.observability.context import get_current_trace_id

try:
    from langfuse import Langfuse as _Langfuse

    _langfuse_available = True
except ImportError:
    _langfuse_available = False


def traced(name: str | None = None) -> Callable[..., Any]:
    """Decorator that wraps a function in a Langfuse span.

    Usage::

        @traced("vector-search")
        async def search(query: str) -> list[dict]:
            ...

    If Langfuse is not installed or tracing is disabled the function
    runs unmodified.
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        span_name = name or fn.__name__

        @functools.wraps(fn)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            trace_id = get_current_trace_id()
            if not _langfuse_available or trace_id is None:
                return await fn(*args, **kwargs)

            lf = _Langfuse()
            span = lf.start_span(
                trace_context={"trace_id": trace_id},
                name=span_name,
            )
            start = time.perf_counter()
            try:
                result = await fn(*args, **kwargs)
                elapsed_ms = (time.perf_counter() - start) * 1000
                span.update(
                    output={"status": "ok"},
                    metadata={"duration_ms": round(elapsed_ms, 2)},
                )
                return result
            except Exception as exc:
                elapsed_ms = (time.perf_counter() - start) * 1000
                span.update(
                    output={"status": "error", "error": str(exc)},
                    level="ERROR",
                    metadata={"duration_ms": round(elapsed_ms, 2)},
                )
                raise
            finally:
                span.end()

        @functools.wraps(fn)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            # For sync functions, just run without Langfuse span to keep simple
            return fn(*args, **kwargs)

        if asyncio.iscoroutinefunction(fn):
            return async_wrapper
        return sync_wrapper

    return decorator
