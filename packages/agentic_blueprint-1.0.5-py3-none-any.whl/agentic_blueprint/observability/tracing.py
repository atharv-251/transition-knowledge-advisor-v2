"""Langfuse initialisation -- graceful, zero-config.

Call :func:`setup_langfuse` once at application startup (via ``init_blueprint``).
If ``LANGFUSE_PUBLIC_KEY`` and ``LANGFUSE_SECRET_KEY`` are present the SDK
automatically enables tracing.  If they are absent **the SDK works perfectly
without tracing** -- no errors, no warnings in normal operation.

Use :func:`is_langfuse_configured` anywhere you need to branch on whether
tracing is actually available.
"""

from __future__ import annotations

import logging
import os

from agentic_blueprint.config.settings import AgenticBlueprintSettings, get_settings

logger = logging.getLogger(__name__)

_initialised = False
_langfuse_available = False


def is_langfuse_configured() -> bool:
    """Return ``True`` when Langfuse tracing is active and usable.

    This checks two things:
    1. The ``langfuse`` package is importable.
    2. Valid credentials were detected at startup.

    Safe to call at any time -- returns ``False`` before ``setup_langfuse()``.
    """
    return _langfuse_available


def setup_langfuse(settings: AgenticBlueprintSettings | None = None) -> None:
    """Configure Langfuse environment variables from platform settings.

    The ``langfuse`` library reads ``LANGFUSE_PUBLIC_KEY``,
    ``LANGFUSE_SECRET_KEY`` and ``LANGFUSE_HOST`` from the environment.
    We ensure they are set so the drop-in ``langfuse.openai`` SDK works.

    Graceful behaviour:
    * If credentials are absent tracing is silently disabled.
    * If the ``langfuse`` package is not installed tracing is silently disabled.
    * The rest of the SDK continues to work in both cases.
    """
    global _initialised, _langfuse_available  # noqa: PLW0603
    if _initialised:
        return

    s = settings or get_settings()

    # User explicitly disabled tracing
    if not s.enable_tracing:
        logger.info("Langfuse tracing is disabled (AGENTIC_BLUEPRINT_ENABLE_TRACING=false)")
        os.environ.setdefault("LANGFUSE_ENABLED", "false")
        _langfuse_available = False
        _initialised = True
        return

    # Auto-detect: are credentials actually present?
    if not s.langfuse.is_configured:
        logger.info(
            "Langfuse credentials not found -- tracing is disabled. "
            "Set LANGFUSE_PUBLIC_KEY and LANGFUSE_SECRET_KEY to enable."
        )
        os.environ.setdefault("LANGFUSE_ENABLED", "false")
        _langfuse_available = False
        _initialised = True
        return

    # Check that the langfuse package is installed
    try:
        import langfuse  # noqa: F401
    except ImportError:
        logger.info(
            "langfuse package not installed -- tracing is disabled. "
            "Install with: pip install langfuse"
        )
        os.environ.setdefault("LANGFUSE_ENABLED", "false")
        _langfuse_available = False
        _initialised = True
        return

    # Everything is available -- configure env vars
    # LANGFUSE_HOST is hardcoded in the SDK (VW LLMaaS Langfuse instance).
    # Developers only need LANGFUSE_PUBLIC_KEY and LANGFUSE_SECRET_KEY.
    lf = s.langfuse
    os.environ.setdefault("LANGFUSE_PUBLIC_KEY", lf.public_key)
    os.environ.setdefault("LANGFUSE_SECRET_KEY", lf.secret_key.get_secret_value())
    os.environ["LANGFUSE_HOST"] = lf.host  # always enforce SDK default, not developer env

    # Set the trace-level environment so every Langfuse() instance
    # (including ad-hoc ones in MCP tools & decorators) automatically
    # tags traces with the correct environment in the Langfuse UI.
    os.environ.setdefault(
        "LANGFUSE_TRACING_ENVIRONMENT", s.environment.value,
    )

    # -- Propagate project_id and workflow_id as default trace tags -------
    # Read from env vars (set by init_blueprint after Control Plane gating).
    _project_id = os.environ.get("LANGFUSE_PROJECT_ID") or os.environ.get(
        "AGENTIC_BLUEPRINT_PROJECT_ID", ""
    )
    _workflow_id = os.environ.get("LANGFUSE_WORKFLOW_ID") or os.environ.get(
        "AGENTIC_BLUEPRINT_WORKFLOW_ID", ""
    )
    _default_tags: list[str] = []
    if _project_id:
        _default_tags.append(f"project:{_project_id}")
    if _workflow_id:
        _default_tags.append(f"workflow:{_workflow_id}")
    if _default_tags:
        # LANGFUSE_TRACE_TAGS is a comma-separated list recognised by the
        # Langfuse Python SDK for auto-tagging every new trace.
        existing_tags = os.environ.get("LANGFUSE_TRACE_TAGS", "")
        merged = ",".join(filter(None, [existing_tags, *_default_tags]))
        os.environ["LANGFUSE_TRACE_TAGS"] = merged

    _langfuse_available = True
    _initialised = True
    logger.info(
        "Langfuse tracing configured (host=%s, environment=%s)",
        lf.host,
        s.environment.value,
    )
