"""Platform-specific exceptions.

A clean hierarchy so consumers can catch at the right granularity:

    AgenticBlueprintPlatformError
    +-- ConfigurationError
    +-- LLMaaSError
    |   +-- AuthenticationError
    |   +-- ModelNotAllowedError
    +-- GovernanceError
    |   +-- PolicyViolationError
    |   +-- GuardrailBlockedError
    |   +-- BudgetExceededError
    |   +-- RateLimitExceededError
    +-- MCPError
    |   +-- MCPConnectionError
    |   +-- MCPToolCallError
    +-- ToolExecutionError
    +-- TracingError
"""

from __future__ import annotations


class AgenticBlueprintPlatformError(Exception):
    """Base exception for all Agentic Blueprint errors."""


# -- Configuration ----------------------------------------------


class ConfigurationError(AgenticBlueprintPlatformError):
    """Missing or invalid configuration."""


# -- LLMaaS -----------------------------------------------------


class LLMaaSError(AgenticBlueprintPlatformError):
    """Error communicating with VW LLMaaS."""


class AuthenticationError(LLMaaSError):
    """OAuth token acquisition or refresh failed."""


class ModelNotAllowedError(LLMaaSError):
    """Requested model is not on the CISO-approved allowlist."""

    def __init__(
        self,
        model: str,
        allowed: list[str] | None = None,
        *,
        block_response: str | None = None,
    ) -> None:
        self.model = model
        self.allowed = allowed or []
        self.block_response = block_response
        msg = f"Model '{model}' is not on the approved allowlist"
        if self.allowed:
            msg += f". Allowed: {', '.join(self.allowed)}"
        super().__init__(msg)


# -- Governance -------------------------------------------------


class GovernanceError(AgenticBlueprintPlatformError):
    """Base for all governance-related errors."""


class PolicyViolationError(GovernanceError):
    """A governance policy was violated."""

    def __init__(
        self,
        policy: str,
        detail: str,
        *,
        block_response: str | None = None,
    ) -> None:
        self.policy = policy
        self.detail = detail
        self.block_response = block_response
        super().__init__(f"Policy '{policy}' violated: {detail}")


class GuardrailBlockedError(GovernanceError):
    """A guardrail blocked execution.

    When ``block_response`` is set, the governance layer returns this
    canned message to the user instead of propagating the exception.
    """

    def __init__(
        self,
        guardrail: str,
        reason: str,
        *,
        block_response: str | None = None,
    ) -> None:
        self.guardrail = guardrail
        self.reason = reason
        self.block_response = block_response
        super().__init__(f"Guardrail '{guardrail}' blocked: {reason}")


class BudgetExceededError(GovernanceError):
    """Token or cost budget exceeded."""

    def __init__(self, message: str, *, block_response: str | None = None) -> None:
        self.block_response = block_response
        super().__init__(message)


class RateLimitExceededError(GovernanceError):
    """Per-agent or per-user rate limit exceeded."""

    def __init__(self, message: str, *, block_response: str | None = None) -> None:
        self.block_response = block_response
        super().__init__(message)


class TimeoutExceededError(GovernanceError):
    """Agent execution exceeded the configured timeout."""

    def __init__(self, message: str, *, block_response: str | None = None) -> None:
        self.block_response = block_response
        super().__init__(message)


# -- Tools ------------------------------------------------------


class ToolExecutionError(AgenticBlueprintPlatformError):
    """A tool invocation failed."""


# -- Tracing ----------------------------------------------------


class TracingError(AgenticBlueprintPlatformError):
    """Error in the tracing / Langfuse subsystem (non-fatal by design)."""


# -- Graph execution (re-exported from LangGraph) --------------
#
# These are the errors developers need to catch when running graphs.
# Re-exported so ``from agentic_blueprint.exceptions import GraphRecursionError``
# works without a direct ``langgraph`` import.

try:
    from langgraph.errors import (  # noqa: E402
        GraphInterrupt,
        GraphRecursionError,
        NodeInterrupt,
    )
except ImportError:  # langgraph not installed
    class GraphInterrupt(AgenticBlueprintPlatformError):  # type: ignore[no-redef]
        """Stub for when langgraph is not installed."""

    class GraphRecursionError(AgenticBlueprintPlatformError):  # type: ignore[no-redef]
        """Stub for when langgraph is not installed."""

    class NodeInterrupt(AgenticBlueprintPlatformError):  # type: ignore[no-redef]
        """Stub for when langgraph is not installed."""
