"""Agentic Blueprint -- Native-first governance middleware for agentic AI.

Wrap any LangGraph graph (or standalone async agent) with enterprise
guardrails, tracing, and audit -- without modifying the developer's
code, state, or graph structure.

Quick start (native-first API)::

    from langgraph.graph import StateGraph, START, END
    from agentic_blueprint import init_blueprint, wrap, get_llm
    from agentic_blueprint.governance.policies import ModelAllowlistPolicy
    from agentic_blueprint.governance.audit import AuditGuard

    settings = init_blueprint()
    llm = get_llm(model="gpt-5-mini")

    class MyState(TypedDict):
        messages: Annotated[list, add_messages]
        answer: str

    builder = StateGraph(MyState)
    builder.add_node("chat", chat_fn)
    builder.add_edge(START, "chat")
    builder.add_edge("chat", END)
    graph = builder.compile()

    governed = wrap(
        graph,
        name="my-agent",
        guards=[ModelAllowlistPolicy(), AuditGuard()],
    )
    result = await governed.ainvoke({"messages": [...]})

For standalone async agents (no graph)::

    from agentic_blueprint import guard

    governed_fn = guard(planner.ainvoke, name="planner", guards=[...])
    result = await governed_fn(state)

Multi-agent pipelines (single unified Langfuse trace)::

    from agentic_blueprint import pipeline, wrap

    researcher = wrap(create_deep_agent(...), guards=[...])
    writer     = wrap(create_deep_agent(...), guards=[...])

    async with pipeline("research-pipeline") as pipe:
        r1 = await researcher.ainvoke(state, session_id=pipe.session_id)
        r2 = await writer.ainvoke(state, session_id=pipe.session_id)
        eval_state = pipe.build_eval_state(r2)

Governance context (available everywhere during execution)::

    from agentic_blueprint import governance_context

    ctx = governance_context()
    ctx.trace_id, ctx.user_id, ctx.node_history

"""

from __future__ import annotations

import logging
import os
import warnings

# Version is defined in _version.py — single source of truth, kept in sync
# with pyproject.toml via hatchling dynamic versioning.
# Always reflects the correct version for both editable and installed packages.
from agentic_blueprint._version import __version__

from agentic_blueprint.config.settings import AgenticBlueprintSettings, get_settings
from agentic_blueprint._internal.helpers import generate_id, extract_last_message
from agentic_blueprint.core.governance_context import (
    GovernanceCtx,
    governance_context,
    set_output,
    set_retrieval_context,
    build_eval_state,
)
from agentic_blueprint.core.wrap import wrap, guard, GovernedGraph, GovernedCallable, register_framework, GovernedBase
from agentic_blueprint.frameworks.base import GovernedBase as _GovernedBase  # noqa: F811  (also in wrap)
from agentic_blueprint.governance.risk import RiskClass
from agentic_blueprint.governance.risk import AutonomyLevel, ImpactClass, DataSensitivity, ExposureLevel, AgentLifecycleState
from agentic_blueprint.governance.identity import IdentityMode, ShadowTokenProvider, PermissionModel
from agentic_blueprint.core.pipeline import pipeline, PipelineCtx
from agentic_blueprint.core.image import ImageModel, get_image_model
from agentic_blueprint.core.models import ChatModel, FallbackChatModel, get_llm, get_llm_with_fallback
from agentic_blueprint.core.ocr import OCRClient, get_ocr_client
from agentic_blueprint.core.realtime import RealtimeClient, get_realtime_client
from agentic_blueprint.frameworks.langchain import LLMChatModel
from agentic_blueprint.exceptions import (
    AgenticBlueprintPlatformError,
    ConfigurationError,
    GovernanceError,
    GraphInterrupt,
    GraphRecursionError,
    GuardrailBlockedError,
    NodeInterrupt,
    PolicyViolationError,
)
from agentic_blueprint.governance.guards import GovernanceGuard, GuardsPipeline
from agentic_blueprint.governance.pipeline import GovernancePipeline
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.project_registry import (
    get_default_user_id,
    get_platform_project_id,
    set_default_user_id,
    mark_platform_initialized,
    require_platform_init,
)
from agentic_blueprint.observability.logging import setup_logging
from agentic_blueprint.observability.tracing import is_langfuse_configured, setup_langfuse
from agentic_blueprint.core.langfuse_client import get_langfuse_client
from agentic_blueprint.governance.profile import load_profile
from agentic_blueprint.governance.auto_patch import install_patch

# MCP -- lazy import (requires agentic_blueprint[mcp])
try:
    from agentic_blueprint.mcp import MCPToolkit
except ImportError:
    MCPToolkit = None  # type: ignore[assignment,misc]

logger = logging.getLogger(__name__)


def init_blueprint(*, settings: AgenticBlueprintSettings | None = None) -> AgenticBlueprintSettings:
    """Initialise logging, tracing, and return the resolved settings.

    Call this once at application startup::

        from agentic_blueprint import init_blueprint, wrap, get_llm
        settings = init_blueprint()

    What happens:

    1. Logging is configured (structlog, JSON in production).
    2. **LLMaaS credentials are validated** -- ``LLMAAS_API_KEY`` must be
       present in the developer's ``.env``.
    3. **Langfuse is auto-detected** -- if ``LANGFUSE_PUBLIC_KEY`` and
       ``LANGFUSE_SECRET_KEY`` are present tracing is enabled automatically.
    4. If ``AGENTIC_BLUEPRINT_PROJECT_ID`` or ``AGENTIC_BLUEPRINT_WORKFLOW_ID``
       are set, they are propagated into Langfuse traces as metadata.
    5. Mandate guards are loaded and the auto-governance patch is installed.
    6. Platform is marked as initialised, unlocking all factory functions.

    Returns:
        The resolved :class:`AgenticBlueprintSettings` instance.

    Raises:
        ConfigurationError: If ``LLMAAS_API_KEY`` is not set.
    """
    s = settings or get_settings()

    # 1. Logging -- always first
    setup_logging()

    # -- 2. Validate LLMaaS credentials ------------------------------------
    if not s.llmaas.is_configured:
        raise ConfigurationError(
            "\n"
            "x  LLMAAS_API_KEY is not set.\n"
            "\n"
            "   The Agentic Blueprint SDK requires an LLMaaS API key.\n"
            "   Set it in your .env:\n"
            "\n"
            "       LLMAAS_API_KEY=sk-your-virtual-key\n"
            "\n"
            "   Your LLMaaS virtual key is available in the LLMaaS portal.\n"
        )

    # -- 3. Langfuse -- graceful auto-detection -----------------------------
    setup_langfuse(s)

    # -- 4. Warn when LLM is ready but tracing is missing ------------------
    if s.llmaas.is_configured and not is_langfuse_configured() and s.enable_tracing:
        warnings.warn(
            "\n"
            "[WARNING] Langfuse tracing is NOT configured.\n"
            "\n"
            "   Your LLM calls will execute normally, but you won't be able\n"
            "   to monitor or debug them in the Langfuse dashboard.\n"
            "\n"
            "   Set these in your .env to enable tracing:\n"
            "       LANGFUSE_PUBLIC_KEY=pk-lf-...\n"
            "       LANGFUSE_SECRET_KEY=sk-lf-...\n"
            "\n"
            "   To suppress this warning, set:\n"
            "       AGENTIC_BLUEPRINT_ENABLE_TRACING=false\n",
            stacklevel=2,
        )

    # -- 5. Propagate project_id / workflow_id into Langfuse traces ---------
    resolved_project_id = s.project_id
    resolved_workflow_id = s.workflow_id

    if resolved_project_id:
        os.environ.setdefault("LANGFUSE_PROJECT_ID", resolved_project_id)
    if resolved_workflow_id:
        os.environ.setdefault("LANGFUSE_WORKFLOW_ID", resolved_workflow_id)

    # -- 6. Mark platform as initialised -----------------------------------
    mark_platform_initialized(resolved_project_id)

    # -- 7. Load governance profile (mandate guards) -----------------------
    load_profile(project_mandate_guardrails="")

    # -- 8. Install auto-governance patch on LangGraph ---------------------
    install_patch()

    # -- 9. Log resolved configuration summary -----------------------------
    logger.info(
        "agentic_blueprint initialised (env=%s, llmaas=%s, langfuse=%s, "
        "project_id=%s, workflow_id=%s)",
        s.environment.value,
        "ready" if s.llmaas.is_configured else "not configured",
        "enabled" if is_langfuse_configured() else "disabled",
        resolved_project_id or "(not set)",
        resolved_workflow_id or "(not set)",
    )

    return s

    return s


__all__ = [
    # Version
    "__version__",
    # Bootstrap
    "init_blueprint",
    "AgenticBlueprintSettings",
    "get_settings",
    # ── Native-first API (v0.3+) ──────────────────────────────
    "wrap",
    "guard",
    "GovernedGraph",
    "GovernedCallable",
    "GovernedBase",
    "RiskClass",
    "pipeline",
    "PipelineCtx",
    "GovernanceCtx",
    "governance_context",
    "set_output",
    "set_retrieval_context",
    "build_eval_state",
    "extract_last_message",
    # Core -- LLM (Chat Completions + Responses API)
    "ChatModel",
    "FallbackChatModel",
    "get_llm",
    "get_llm_with_fallback",
    "get_langfuse_client",
    # Core -- Image Generation
    "ImageModel",
    "get_image_model",
    # Core -- OCR
    "OCRClient",
    "get_ocr_client",
    # Core -- Realtime Voice
    "RealtimeClient",
    "get_realtime_client",
    # Governance
    "GovernanceGuard",
    "GovernancePipeline",
    "GuardsPipeline",
    "ExecutionContext",
    "get_default_user_id",
    "set_default_user_id",
    # Taxonomy & Classification (VW Agentic Standards §1)
    "AutonomyLevel",
    "ImpactClass",
    "DataSensitivity",
    "ExposureLevel",
    "AgentLifecycleState",
    # Identity (VW Agentic Standards §3)
    "IdentityMode",
    "ShadowTokenProvider",
    "PermissionModel",
    # MCP
    "MCPToolkit",
    # Observability
    "is_langfuse_configured",
    # Exceptions
    "AgenticBlueprintPlatformError",
    "ConfigurationError",
    "GovernanceError",
    "PolicyViolationError",
    "GuardrailBlockedError",
    # Graph errors (re-exported from LangGraph)
    "GraphRecursionError",
    "NodeInterrupt",
    "GraphInterrupt",
]
