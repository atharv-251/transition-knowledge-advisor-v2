"""RealtimeClient -- VW LLMaaS realtime voice via ``/v1/realtime`` (WebSocket).

Low-latency, multi-modal conversations with ``gpt-realtime``.  Accepts text,
audio, and image input; produces text and audio output.

Requires the optional ``websockets`` dependency::

    pip install agentic_blueprint[realtime]

Quick start::

    from agentic_blueprint.core.realtime import get_realtime_client

    async with get_realtime_client() as rt:
        await rt.send_text("Say hello in one sentence.")
        async for event in rt.events():
            if event["type"] == "response.done":
                break
            print(event)
"""

from __future__ import annotations

import asyncio
import json
import logging
import ssl
from typing import Any, AsyncGenerator

from agentic_blueprint._internal.token_manager import TokenManager
from agentic_blueprint.config.settings import LLMaaSSettings, get_settings
from agentic_blueprint.governance.project_registry import require_platform_init

logger = logging.getLogger(__name__)

DEFAULT_REALTIME_MODEL = "gpt-realtime"


def get_realtime_client(
    model: str = DEFAULT_REALTIME_MODEL,
    *,
    llmaas_settings: LLMaaSSettings | None = None,
) -> "RealtimeClient":
    """Create a realtime voice client backed by VW LLMaaS.

    ::

        async with get_realtime_client() as rt:
            await rt.send_text("Hello!")
            async for event in rt.events():
                print(event)

    Raises:
        ConfigurationError: If ``init_blueprint()`` was not called.
    """
    require_platform_init()
    return RealtimeClient(model=model, llmaas_settings=llmaas_settings)


class RealtimeClient:
    """WebSocket client for VW LLMaaS Realtime API (``/v1/realtime``).

    Use as an async context manager::

        async with RealtimeClient() as rt:
            await rt.send_text("Hello")
            async for event in rt.events():
                if event["type"] == "response.done":
                    break
    """

    def __init__(
        self,
        model: str = DEFAULT_REALTIME_MODEL,
        *,
        llmaas_settings: LLMaaSSettings | None = None,
    ) -> None:
        self._settings = llmaas_settings or get_settings().llmaas
        self.model = model
        self._token_manager = TokenManager(self._settings)
        self._ws: Any | None = None
        self._current_token: str | None = None

    async def connect(self) -> None:
        """Establish the WebSocket connection.

        Raises:
            ImportError: If the ``websockets`` package is not installed.
        """
        try:
            import websockets
        except ImportError:
            raise ImportError(
                "websockets is required for the Realtime API. "
                "Install it with: pip install agentic_blueprint[realtime]"
            ) from None

        token = await self._token_manager.get_token()
        self._current_token = token
        virtual_key = self._settings.api_key.get_secret_value()

        base = self._settings.base_url.rstrip("/")
        # Convert https:// to wss://
        ws_base = base.replace("https://", "wss://").replace("http://", "ws://")
        url = f"{ws_base}/v1/realtime?model={self.model}"

        headers = {
            "Authorization": f"Bearer {token}",
            "X-LLM-API-CLIENT-ID": f"Bearer {virtual_key}",
            "OpenAI-Beta": "realtime=v1",
        }

        ssl_context = ssl.create_default_context()

        self._ws = await websockets.connect(
            url,
            additional_headers=headers,
            ssl=ssl_context,
        )

        # Wait for session.created
        raw = await asyncio.wait_for(self._ws.recv(), timeout=15)
        event = json.loads(raw)
        if event.get("type") != "session.created":
            logger.warning("Expected session.created, got: %s", event.get("type"))
        logger.debug("Realtime session created")

    async def _reconnect_if_token_rotated(self) -> None:
        """Reconnect the WebSocket if the OAuth token has rotated.

        Long-lived sessions (audio streaming) can outlive the token TTL
        (~30 min).  This checks for a fresh token before each send and
        transparently reconnects when the token changes.
        """
        new_token = await self._token_manager.get_token()
        if new_token != self._current_token:
            logger.info("OAuth token rotated — reconnecting realtime WebSocket")
            await self.close()
            await self.connect()

    async def send_text(
        self,
        text: str,
        *,
        modalities: list[str] | None = None,
    ) -> None:
        """Send a text prompt and request a response.

        Args:
            text: The text instruction or prompt.
            modalities: Output modalities -- ``["text"]``, ``["audio"]``,
                        or ``["text", "audio"]``.  Defaults to ``["text"]``.
        """
        if self._ws is None:
            raise RuntimeError("Not connected. Use `async with` or call connect() first.")
        await self._reconnect_if_token_rotated()

        await self._ws.send(json.dumps({
            "type": "response.create",
            "response": {
                "modalities": modalities or ["text"],
                "instructions": text,
            },
        }))

    async def send_raw(self, event: dict[str, Any]) -> None:
        """Send a raw event dict over the WebSocket."""
        if self._ws is None:
            raise RuntimeError("Not connected.")
        await self._reconnect_if_token_rotated()
        await self._ws.send(json.dumps(event))

    async def events(
        self,
        *,
        timeout: float = 30.0,
        max_events: int = 200,
    ) -> AsyncGenerator[dict[str, Any], None]:
        """Yield events from the WebSocket until ``response.done`` or limits hit.

        Args:
            timeout: Per-message receive timeout in seconds.
            max_events: Safety limit on total events to prevent infinite loops.
        """
        if self._ws is None:
            raise RuntimeError("Not connected.")

        for _ in range(max_events):
            try:
                raw = await asyncio.wait_for(self._ws.recv(), timeout=timeout)
            except asyncio.TimeoutError:
                logger.debug("Realtime event receive timed out")
                return

            event = json.loads(raw)
            yield event

            if event.get("type") == "response.done":
                return

    async def close(self) -> None:
        """Close the WebSocket and release resources."""
        if self._ws is not None:
            try:
                await self._ws.close()
            except Exception:
                logger.debug("error closing WebSocket connection", exc_info=True)
            self._ws = None
        await self._token_manager.close()

    async def __aenter__(self) -> "RealtimeClient":
        await self.connect()
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()

    def __repr__(self) -> str:
        connected = "connected" if self._ws is not None else "disconnected"
        return f"RealtimeClient(model={self.model!r}, {connected})"
