"""Pipeline context manager for multi-agent orchestrations.

When an orchestrator runs several governed agents sequentially (e.g.
researcher → critic → writer), each ``ainvoke()`` normally creates its
own Langfuse trace.  The ``pipeline()`` context manager unifies them:

1. **Single parent trace** -- all sub-agent invocations appear as
   child spans under one trace in Langfuse.
2. **Shared session** -- ``session_id`` is generated once and reused.
3. **Aggregated node history** -- ``build_eval_state()`` merges
   node histories from every sub-agent automatically.
4. **One-line eval** -- ``pipe.build_eval_state(result)`` includes
   identity, trace, and node history without manual extraction.

Usage
-----
::

    import agentic_blueprint
    from agentic_blueprint import pipeline, wrap, build_eval_state

    researcher = wrap(create_deep_agent(...), name="researcher", guards=[...])
    writer     = wrap(create_deep_agent(...), name="writer",     guards=[...])

    async with pipeline("deep-research", tags=["research"]) as pipe:
        r1 = await researcher.ainvoke(
            {"messages": [...]},
            session_id=pipe.session_id,
        )
        r2 = await writer.ainvoke(
            {"messages": [...]},
            session_id=pipe.session_id,
        )
        eval_state = pipe.build_eval_state(r2)

The ``eval_state`` automatically contains ``ab_trace_id``,
``ab_session_id``, ``ab_user_id``, ``ab_project_id``,
``ab_workflow_id``, and the merged ``ab_node_history`` from
all sub-agents.
"""

from __future__ import annotations

import contextvars
import logging
import re
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Sequence

from agentic_blueprint._internal.helpers import generate_id
from agentic_blueprint.config.settings import get_settings
from agentic_blueprint.core.governance_context import (
    GovernanceCtx,
    _get_governance_ctx,
    _set_governance_ctx,
)
from agentic_blueprint.governance.project_registry import (
    get_default_user_id,
    get_platform_project_id,
    require_platform_init,
)
from agentic_blueprint.observability.context import (
    set_current_trace_id,
    set_project_id,
    set_session_id,
    set_user_id,
    set_workflow_id,
    _trace_id_var,
    _session_id_var,
    _user_id_var,
    _project_id_var,
    _workflow_id_var,
)

from langfuse import propagate_attributes as _propagate_attributes
from langfuse.langchain import CallbackHandler as _LfCbHandler

try:
    from opentelemetry import context as _otel_context
except ImportError:  # pragma: no cover
    _otel_context = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Pipeline context -- task-local via contextvars
# ---------------------------------------------------------------------------

@dataclass
class PipelineCtx:
    """Active pipeline coordination state.

    Created by ``pipeline().__aenter__()`` and stored in a contextvar
    so that ``GovernedGraph.ainvoke()`` and ``GovernedCallable.__call__()``
    can detect an active pipeline and nest under its parent trace.
    """

    name: str
    trace_id: str
    session_id: str
    user_id: str
    project_id: str
    workflow_id: str
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    # Aggregated across all sub-agent invocations
    node_history: list[str] = field(default_factory=list)
    sub_trace_ids: list[str] = field(default_factory=list)
    agent_names: list[str] = field(default_factory=list)

    # Langfuse root span ID for nesting child spans
    root_span_id: str | None = None
    otel_parent_ctx: Any = None

    # Governance context snapshots from sub-agents
    _last_gov_ctx: GovernanceCtx | None = None

    # Pipeline-level graph visualisation (CHAIN observations)
    # so Langfuse graph view renders agent names as nodes + edges.
    _pipeline_cb: Any = None
    _pipeline_lg_run_id: Any = None
    _prev_chain_label: str | None = None

    # -- helpers for pipeline graph CHAINs --------------------------

    @staticmethod
    def _chain_safe_name(name: str) -> str:
        """Strip ``agent`` so Langfuse classifies the observation as CHAIN.

        The Langfuse ``CallbackHandler`` heuristic:
            ``if 'agent' in name.lower(): type = AGENT``
        Only CHAIN observations render in the Langfuse graph view, so
        we need to remove the word *agent* from the serialized name.
        The full original name is still kept in ``langgraph_node`` metadata.
        """
        if "agent" not in name.lower():
            return name
        cleaned = re.sub(r"[-_]?agent[-_]?", "-", name, flags=re.IGNORECASE)
        return cleaned.strip("-") or name

    def _start_agent_chain(
        self, agent_name: str, input_state: Any = None,
    ) -> Any:
        """Emit ``on_chain_start`` for *agent_name* in the pipeline graph.

        Returns the ``run_id`` (UUID) to pass to :meth:`_end_agent_chain`.
        """
        if self._pipeline_cb is None:
            return None

        run_id = uuid.uuid4()
        chain_label = self._chain_safe_name(agent_name)
        triggers = [self._prev_chain_label or "__start__"]
        step = len(self.agent_names) + 1
        try:
            self._pipeline_cb.on_chain_start(
                serialized={
                    "name": chain_label,
                    "id": ["langgraph", "utils", "runnable", "RunnableCallable"],
                },
                inputs=input_state or {},
                run_id=run_id,
                parent_run_id=self._pipeline_lg_run_id,
                metadata={
                    "langgraph_node": chain_label,
                    "langgraph_triggers": triggers,
                    "langgraph_step": step,
                },
            )
        except Exception:
            logger.debug("Failed to emit pipeline agent chain start", exc_info=True)
            return None
        return run_id

    def _end_agent_chain(
        self, run_id: Any, agent_name: str, output: Any = None,
    ) -> None:
        """Close the CHAIN observation for *agent_name* in the pipeline graph."""
        if self._pipeline_cb is None or run_id is None:
            return
        chain_label = self._chain_safe_name(agent_name)
        try:
            self._pipeline_cb.on_chain_end(
                outputs=output if isinstance(output, dict) else {},
                run_id=run_id,
            )
        except Exception:
            logger.debug("Failed to emit pipeline agent chain end", exc_info=True)
        self._prev_chain_label = chain_label


_pipeline_ctx_var: contextvars.ContextVar[PipelineCtx | None] = (
    contextvars.ContextVar("agentic_blueprint_pipeline_ctx", default=None)
)


def get_active_pipeline() -> PipelineCtx | None:
    """Return the active pipeline context, or ``None``.

    Used by ``GovernedGraph.ainvoke()`` to detect whether to nest
    under a parent pipeline trace.
    """
    return _pipeline_ctx_var.get()


# ---------------------------------------------------------------------------
# pipeline() -- async context manager
# ---------------------------------------------------------------------------

class pipeline:
    """Async context manager that unifies multi-agent orchestrations.

    Parameters
    ----------
    name:
        Pipeline name (appears as the parent trace name in Langfuse).
    session_id:
        Explicit session ID.  Auto-generated if not provided.
    user_id:
        User identity override.
    project_id:
        Project identity override.
    workflow_id:
        Workflow identity override.  Defaults to *name*.
    tags:
        Tags for the Langfuse parent trace.
    metadata:
        Extra metadata for the Langfuse parent trace.
    input:
        Pipeline input (shown on the parent trace in Langfuse).

    Example
    -------
    ::

        async with agentic_blueprint.pipeline("research-pipeline") as pipe:
            r1 = await agent1.ainvoke(state, session_id=pipe.session_id)
            r2 = await agent2.ainvoke(state, session_id=pipe.session_id)
            eval_state = pipe.build_eval_state(r2)
    """

    def __init__(
        self,
        name: str,
        *,
        session_id: str | None = None,
        user_id: str | None = None,
        project_id: str | None = None,
        workflow_id: str | None = None,
        tags: Sequence[str] = (),
        metadata: dict[str, Any] | None = None,
        input: Any = None,
    ) -> None:
        self._name = name
        self._session_id = session_id
        self._user_id = user_id
        self._project_id = project_id
        self._workflow_id = workflow_id
        self._tags = list(tags)
        self._metadata = metadata or {}
        self._input = input

        # Internal state
        self._ctx: PipelineCtx | None = None
        self._token: contextvars.Token[PipelineCtx | None] | None = None
        self._lf: Any = None
        self._root_span: Any = None
        self._propagate_cm: Any = None
        self._start_time: float = 0.0

    # -- Properties for developer access --------------------------------

    @property
    def session_id(self) -> str:
        """The shared session ID for this pipeline."""
        if self._ctx is None:
            raise RuntimeError("pipeline() not yet entered")
        return self._ctx.session_id

    @property
    def trace_id(self) -> str:
        """The parent trace ID for this pipeline."""
        if self._ctx is None:
            raise RuntimeError("pipeline() not yet entered")
        return self._ctx.trace_id

    @property
    def node_history(self) -> list[str]:
        """Aggregated node history from all sub-agents."""
        if self._ctx is None:
            return []
        return list(self._ctx.node_history)

    @property
    def agent_names(self) -> list[str]:
        """Names of agents that have run in this pipeline."""
        if self._ctx is None:
            return []
        return list(self._ctx.agent_names)

    # -- async context manager ------------------------------------------

    async def __aenter__(self) -> "pipeline":
        require_platform_init()

        # Resolve identities
        resolved_session = self._session_id or generate_id("sess-")
        resolved_user = self._user_id or get_default_user_id()
        resolved_project = (
            self._project_id
            or get_settings().project_id
            or get_platform_project_id()
        )
        resolved_workflow = self._workflow_id or self._name

        # Create Langfuse parent trace
        lf = self._get_langfuse()
        trace_id = lf.create_trace_id() if lf else generate_id("tr-")

        # Build pipeline context
        self._ctx = PipelineCtx(
            name=self._name,
            trace_id=trace_id,
            session_id=resolved_session,
            user_id=resolved_user or "",
            project_id=resolved_project or "",
            workflow_id=resolved_workflow,
            tags=self._tags,
            metadata=self._metadata,
        )

        # Set as active pipeline context
        self._token = _pipeline_ctx_var.set(self._ctx)

        # Set observability contextvars (save tokens for proper restoration)
        self._tk_trace = set_current_trace_id(trace_id)
        self._tk_session = set_session_id(resolved_session)
        self._tk_user = set_user_id(resolved_user)
        self._tk_project = set_project_id(resolved_project)
        self._tk_workflow = set_workflow_id(resolved_workflow)

        self._start_time = time.perf_counter()

        # Open Langfuse parent span (wrapped in try to prevent contextvar leaks on failure)
        try:
            if lf is not None:
                self._lf = lf
                settings = get_settings()
                env_tag = settings.environment.value

                self._root_span = lf.start_as_current_span(
                    trace_context={"trace_id": trace_id},
                    name=self._name,
                    input=self._input,
                )
                self._root_span.__enter__()

                lf.update_current_trace(
                    name=self._name,
                    user_id=resolved_user,
                    session_id=resolved_session,
                    tags=self._tags + [env_tag],
                    metadata={
                        "project_id": resolved_project,
                        "workflow_id": resolved_workflow,
                        "environment": env_tag,
                        **self._metadata,
                    },
                    input=self._input,
                )

                # Capture root span ID and OTEL context for child nesting
                self._ctx.root_span_id = lf.get_current_observation_id()
                if _otel_context is not None:
                    self._ctx.otel_parent_ctx = _otel_context.get_current()

                # Create pipeline-level graph so Langfuse graph view
                # renders agent names as CHAIN nodes with edges.
                try:
                    self._ctx._pipeline_cb = _LfCbHandler(
                        trace_context={
                            "trace_id": trace_id,
                            "parent_span_id": self._ctx.root_span_id,
                        }
                    )
                    self._ctx._pipeline_lg_run_id = uuid.uuid4()
                    self._ctx._pipeline_cb.on_chain_start(
                        serialized={
                            "name": "LangGraph",
                            "id": [
                                "langchain",
                                "schema",
                                "runnable",
                                "RunnableSequence",
                            ],
                        },
                        inputs=self._input or {},
                        run_id=self._ctx._pipeline_lg_run_id,
                        metadata={"langgraph_step": 0},
                    )
                except Exception:
                    logger.debug(
                        "Pipeline-level graph CB creation failed",
                        exc_info=True,
                    )

                # propagate_attributes for downstream auto-instrumented calls
                try:
                    self._propagate_cm = _propagate_attributes(
                        trace_name=self._name,
                        user_id=resolved_user,
                        session_id=resolved_session,
                        tags=self._tags + [env_tag],
                    )
                    self._propagate_cm.__enter__()
                except (ImportError, AttributeError):
                    pass
        except Exception:
            # Reset contextvars to prevent leaks if Langfuse setup failed
            if self._token is not None:
                _pipeline_ctx_var.reset(self._token)
                self._token = None
            _trace_id_var.reset(self._tk_trace)
            _session_id_var.reset(self._tk_session)
            _user_id_var.reset(self._tk_user)
            _project_id_var.reset(self._tk_project)
            _workflow_id_var.reset(self._tk_workflow)
            raise

        logger.debug(
            "Pipeline entered: name=%s trace_id=%s session_id=%s",
            self._name, trace_id, resolved_session,
        )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        ctx = self._ctx
        if ctx is None:
            return

        elapsed_ms = (time.perf_counter() - self._start_time) * 1000

        # Close Langfuse spans
        if self._propagate_cm is not None:
            try:
                self._propagate_cm.__exit__(exc_type, exc_val, exc_tb)
            except Exception:
                logger.debug("pipeline propagation context exit failed", exc_info=True)

        # Close pipeline-level graph CHAIN before closing root span
        if ctx._pipeline_cb is not None:
            try:
                ctx._pipeline_cb.on_chain_end(
                    outputs={"agents_run": ctx.agent_names},
                    run_id=ctx._pipeline_lg_run_id,
                )
            except Exception:
                logger.debug("pipeline chain end callback failed", exc_info=True)

        if self._root_span is not None:
            try:
                self._root_span.update(
                    output={
                        "agents_run": ctx.agent_names,
                        "node_count": len(ctx.node_history),
                        "sub_traces": ctx.sub_trace_ids,
                        "elapsed_ms": round(elapsed_ms, 1),
                    },
                )
            except Exception:
                logger.debug("pipeline root span update failed", exc_info=True)
            try:
                self._root_span.__exit__(exc_type, exc_val, exc_tb)
            except Exception:
                logger.debug("pipeline root span exit failed", exc_info=True)

        # Flush and fix trace name
        if self._lf is not None:
            try:
                self._lf.flush()
            except Exception:
                logger.debug("Langfuse flush failed in pipeline", exc_info=True)
            self._fix_trace_name(self._lf, ctx.trace_id, self._name)

        # Tear down contextvars (restore previous values via tokens)
        if self._token is not None:
            _pipeline_ctx_var.reset(self._token)
        if hasattr(self, '_tk_trace'):
            _trace_id_var.reset(self._tk_trace)
            _session_id_var.reset(self._tk_session)
            _user_id_var.reset(self._tk_user)
            _project_id_var.reset(self._tk_project)
            _workflow_id_var.reset(self._tk_workflow)

        logger.debug(
            "Pipeline exited: name=%s agents=%s nodes=%d %.1fms",
            self._name, ctx.agent_names, len(ctx.node_history), elapsed_ms,
        )

    # -- Eval helper ---------------------------------------------------

    def build_eval_state(
        self,
        result: dict[str, Any] | None = None,
        *,
        output: str | None = None,
        retrieval_context: list[str] | None = None,
    ) -> dict[str, Any]:
        """Build an evaluation-ready dict with pipeline identity merged in.

        This is the pipeline-aware version of
        :func:`agentic_blueprint.build_eval_state`.  It automatically includes
        identity, trace, and aggregated node history from all sub-agents
        that ran in this pipeline.

        Parameters
        ----------
        result:
            The result dict from the last agent invocation.
        output:
            Explicit output text for eval.  If ``None``, attempts to
            auto-extract from the last sub-agent's GovernanceCtx.
        retrieval_context:
            Explicit retrieval context for grounding eval.

        Returns
        -------
        dict
            A dict with ``ab_*`` fields populated from the pipeline.
        """
        ctx = self._ctx
        if ctx is None:
            raise RuntimeError("pipeline.build_eval_state() called outside pipeline scope")

        out = dict(result or {})

        # Output: explicit > last governance ctx > auto-extract from result
        resolved_output = output
        if resolved_output is None and ctx._last_gov_ctx is not None:
            resolved_output = ctx._last_gov_ctx.output
        if resolved_output is None and isinstance(result, dict):
            for key in ("answer", "response", "output", "report", "final_report"):
                if key in result and isinstance(result[key], str):
                    resolved_output = result[key]
                    break
        # Also try extracting from messages
        if resolved_output is None and isinstance(result, dict):
            msgs = result.get("messages", [])
            if msgs:
                last = msgs[-1] if isinstance(msgs, list) else msgs
                resolved_output = getattr(last, "content", None) or (
                    last.get("content") if isinstance(last, dict) else str(last)
                )

        # Retrieval context: explicit > last governance ctx
        resolved_retrieval = retrieval_context
        if resolved_retrieval is None and ctx._last_gov_ctx is not None:
            resolved_retrieval = ctx._last_gov_ctx.retrieval_context

        out.setdefault("ab_output", resolved_output or "")
        out.setdefault("ab_retrieval_context", resolved_retrieval or [])
        out.setdefault("ab_trace_id", ctx.trace_id)
        out.setdefault("ab_session_id", ctx.session_id)
        out.setdefault("ab_user_id", ctx.user_id)
        out.setdefault("ab_project_id", ctx.project_id)
        out.setdefault("ab_workflow_id", ctx.workflow_id)
        # Use agent-level names for pipeline eval (not internal SDK nodes)
        out.setdefault("ab_node_history", list(ctx.agent_names))
        out.setdefault("ab_detailed_node_history", list(ctx.node_history))
        out.setdefault("ab_governance_metadata", {})

        # Merge guard metadata from last gov ctx if available
        if ctx._last_gov_ctx is not None and ctx._last_gov_ctx.metadata:
            existing = out.get("ab_governance_metadata", {})
            existing.update(ctx._last_gov_ctx.metadata)
            out["ab_governance_metadata"] = existing

        return out

    async def run_parallel(
        self,
        *invocations: tuple[Any, dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Run multiple governed agents concurrently within this pipeline.

        Each invocation is a tuple of ``(governed_agent, input_state)``::

            async with pipeline("research-pipeline") as pipe:
                results = await pipe.run_parallel(
                    (researcher, {"messages": [...]}),
                    (analyst,   {"messages": [...]}),
                )
                # Both run concurrently, both trace under this pipeline

        The agents share the pipeline's session_id and trace context.
        Results are returned in the same order as the invocations.

        Parameters
        ----------
        invocations :
            Variable number of ``(governed_agent, input_state)`` tuples.
            Each agent must have an ``ainvoke()`` method.

        Returns
        -------
        list[dict]
            Results from each agent, in order.
        """
        import asyncio as _aio

        ctx = self._ctx
        if ctx is None:
            raise RuntimeError("run_parallel() called outside pipeline scope")

        async def _run_one(agent: Any, state: dict[str, Any]) -> dict[str, Any]:
            return await agent.ainvoke(
                state,
                session_id=ctx.session_id,
            )

        tasks = [_run_one(agent, state) for agent, state in invocations]
        return await _aio.gather(*tasks)

    # -- Internal helpers -----------------------------------------------

    @staticmethod
    def _get_langfuse() -> Any | None:
        """Return shared Langfuse client (uses the process-wide singleton)."""
        from agentic_blueprint.core.langfuse_client import get_langfuse_client
        return get_langfuse_client()

    @staticmethod
    def _fix_trace_name(lf: Any, trace_id: str, name: str) -> None:
        """Override trace name via ingestion API."""
        from agentic_blueprint.core.langfuse_client import _fix_trace_name
        _fix_trace_name(lf, trace_id, name)
