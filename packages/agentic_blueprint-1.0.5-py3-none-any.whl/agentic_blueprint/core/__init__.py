"""Core module -- LLMaaS clients, governance context, and wrap/guard API."""

from agentic_blueprint.core.governance_context import (
    GovernanceCtx,
    build_eval_state,
    governance_context,
    set_output,
    set_retrieval_context,
)
from agentic_blueprint.core.image import ImageModel, get_image_model
from agentic_blueprint.core.models import ChatModel, get_llm
from agentic_blueprint.core.ocr import OCRClient, get_ocr_client
from agentic_blueprint.core.realtime import RealtimeClient, get_realtime_client
from agentic_blueprint.core.governed_callable import GovernedCallable
from agentic_blueprint.frameworks.langgraph.governed_graph import GovernedGraph
from agentic_blueprint.core.wrap import guard, wrap
# from agentic_blueprint.frameworks.crewai.governed_crew import GovernedCrew  # Temporarily disabled

__all__ = [
    # Native-first governance API
    "wrap",
    "guard",
    "GovernedGraph",
    "GovernedCallable",
    "GovernanceCtx",
    "governance_context",
    "set_output",
    "set_retrieval_context",
    "build_eval_state",
    # LLMaaS -- Chat / Completions / Responses
    "ChatModel",
    "get_llm",
    # LLMaaS -- Image Generation
    "ImageModel",
    "get_image_model",
    # LLMaaS -- OCR
    "OCRClient",
    "get_ocr_client",
    # LLMaaS -- Realtime Voice
    "RealtimeClient",
    "get_realtime_client",
]
