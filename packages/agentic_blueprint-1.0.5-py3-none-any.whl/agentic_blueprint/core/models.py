"""ChatModel -- production VW LLMaaS wrapper with governed LLM access.

Provides a single interface to VW LLMaaS that transparently handles:

- **Zero-config setup** -- set ``LLMAAS_API_KEY`` and call ``get_llm()``
- **OAuth token lifecycle** -- automatic refresh via VW Cloud IDP
- **API auto-selection** -- ``chat.completions`` for standard models,
  ``responses.create()`` for the entire GPT-5 family
- **Langfuse auto-tracing** -- via ``langfuse.openai.AsyncOpenAI`` drop-in;
  reads ``LANGFUSE_PUBLIC_KEY``, ``LANGFUSE_SECRET_KEY``, ``LANGFUSE_HOST``
  from env vars automatically.  Gracefully degrades to plain ``openai``
  when Langfuse is not configured
- **Smart client caching** -- recreates only when the token rotates
- **Streaming** -- ``astream()`` for token-by-token output
- **Tool binding** -- ``bind_tools()`` for function-calling agents

Supported model families & API routing::

    Chat Completions (/v1/chat/completions)
        gpt-4o, gpt-4o-mini, gpt-4.1, gpt-4.1-mini, gpt-4.1-nano, ...

    Responses API (/v1/responses)
        gpt-5, gpt-5-mini, gpt-5-nano, gpt-5-chat,
        gpt-5.1, gpt-5.1-chat, gpt-5.2, ...

For image generation, OCR, and realtime voice see the dedicated modules:
:mod:`agentic_blueprint.core.image`, :mod:`agentic_blueprint.core.ocr`,
:mod:`agentic_blueprint.core.realtime`.

Quick start::

    from agentic_blueprint import get_llm

    llm = get_llm()                       # default model (LLMAAS_MODEL)
    llm = get_llm(model="gpt-4o")        # Chat Completions API
    llm = get_llm(model="gpt-5-mini")    # Responses API (auto-detected)
    llm = get_llm(model="gpt-5.1")       # Responses API (auto-detected)

    # Inside a LangGraph node:
    async def chat(state):
        response = await llm.ainvoke(state["messages"])
        return {"messages": [response]}
"""

from __future__ import annotations

import asyncio
import contextvars
import json as _json
import logging
import re
from typing import Any, AsyncGenerator

from agentic_blueprint._internal.token_manager import TokenManager
from agentic_blueprint._internal.resilience import CircuitBreaker, CircuitOpenError, is_transient_error
from agentic_blueprint.config.settings import LLMaaSSettings, get_settings
from agentic_blueprint.exceptions import ConfigurationError
from agentic_blueprint.governance.project_registry import require_platform_init
from agentic_blueprint.observability.tracing import is_langfuse_configured
from langchain_core.utils.function_calling import (
    convert_to_openai_function as _lc_convert,
)

logger = logging.getLogger(__name__)


def _is_responses_api_model(model: str) -> bool:
    """Whether *model* uses the Responses API (``/v1/responses``).

    The entire GPT-5 family uses ``responses.create(input=...)``:
    gpt-5, gpt-5-mini, gpt-5-nano, gpt-5-chat, gpt-5.1, gpt-5.1-chat, gpt-5.2, ...

    All other text models (gpt-4o, gpt-4.1-mini, etc.) use the standard
    ``chat.completions.create(messages=...)`` endpoint.
    """
    return model.lower().startswith("gpt-5")


# -- Public factory ---------------------------------------------


def get_llm(
    model: str | None = None,
    *,
    temperature: float = 0.0,
    max_tokens: int | None = None,
    enable_cache: bool = False,
    cache_maxsize: int = 128,
    llmaas_settings: LLMaaSSettings | None = None,
) -> "ChatModel":
    """Create a governed LLM instance backed by VW LLMaaS.

    This is the recommended entry point.  Just pick a model::

        llm = get_llm()                       # default from LLMAAS_MODEL env
        llm = get_llm(model="gpt-4o")         # Chat Completions
        llm = get_llm(model="gpt-4.1-mini")   # Chat Completions
        llm = get_llm(model="gpt-5-mini")     # Responses API (auto-detected)
        llm = get_llm(model="gpt-5.1")        # Responses API (auto-detected)
        llm = get_llm(model="gpt-5.2")        # Responses API (auto-detected)

    The returned :class:`ChatModel` handles OAuth, token refresh, API
    selection, and Langfuse tracing automatically.

    Zero-config usage -- just set your virtual API key::

        export LLMAAS_API_KEY="your-virtual-key"

        # Then in Python:
        from agentic_blueprint import get_llm
        llm = get_llm()  # OAuth, IDP, base URL are SDK defaults

    Raises:
        ConfigurationError: If required ``LLMAAS_*`` env vars are missing
            or ``init_blueprint()`` was not called.

    For image generation use :func:`~agentic_blueprint.core.image.get_image_model`.
    For OCR use :func:`~agentic_blueprint.core.ocr.get_ocr_client`.
    For realtime voice use :func:`~agentic_blueprint.core.realtime.get_realtime_client`.
    """
    require_platform_init()

    resolved = llmaas_settings or get_settings().llmaas

    # Validate credentials are present -- give a clear error message
    if not resolved.is_configured:
        missing = resolved.missing_fields
        raise ConfigurationError(
            f"LLMaaS credentials not configured. Missing: {', '.join(missing)}. "
            f"Set your virtual API key from the LLMaaS portal:\n"
            f"  export LLMAAS_API_KEY='your-virtual-key'"
        )

    cm = ChatModel(
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        llmaas_settings=resolved,
    )
    # Enable response cache if requested.
    if enable_cache:
        cm._cache = {}
        cm._cache_maxsize = cache_maxsize
    return cm


def get_llm_with_fallback(
    models: list[str],
    *,
    temperature: float = 0.0,
    max_tokens: int | None = None,
    enable_cache: bool = False,
    llmaas_settings: LLMaaSSettings | None = None,
) -> "FallbackChatModel":
    """Create an LLM with automatic fallback across models.

    If the primary model fails (timeout, rate limit, error), the next
    model in the list is tried automatically::

        llm = get_llm_with_fallback(["gpt-5-mini", "gpt-4.1-mini"])
        response = await llm.ainvoke(messages)
        # Tries gpt-5-mini first; if it fails, tries gpt-4.1-mini

    Parameters
    ----------
    models : list[str]
        Ordered list of model names. First is primary, rest are fallbacks.
    temperature : float
        Temperature for all models.
    max_tokens : int, optional
        Max tokens for all models.
    enable_cache : bool
        Enable response caching.
    llmaas_settings : LLMaaSSettings, optional
        Override LLMaaS settings.

    Returns
    -------
    FallbackChatModel
        A ChatModel-compatible object that tries models in order.
    """
    require_platform_init()
    if not models:
        raise ConfigurationError("get_llm_with_fallback() requires at least one model.")

    resolved = llmaas_settings or get_settings().llmaas
    instances = []
    for m in models:
        cm = ChatModel(
            model=m,
            temperature=temperature,
            max_tokens=max_tokens,
            llmaas_settings=resolved,
        )
        if enable_cache:
            cm._cache = {}
            cm._cache_maxsize = 128
        instances.append(cm)

    return FallbackChatModel(instances)


class FallbackChatModel:
    """LLM wrapper that tries models in order until one succeeds.

    Created by :func:`get_llm_with_fallback`. Has the same interface as
    :class:`ChatModel` -- ``ainvoke()``, ``astream()``, ``bind_tools()``.
    """

    def __init__(self, models: list[ChatModel]) -> None:
        self._models = models
        self.model = models[0].model
        self.temperature = models[0].temperature

    async def ainvoke(
        self, messages: list[dict[str, Any]], **kwargs: Any
    ) -> Any:
        """Try each model in order; return the first success."""
        last_exc: Exception | None = None
        for i, cm in enumerate(self._models):
            try:
                result = await cm.ainvoke(messages, **kwargs)
                if i > 0:
                    logger.info(
                        "Fallback succeeded: %s (after %d failure(s))",
                        cm.model, i,
                    )
                    self.model = cm.model
                return result
            except Exception as exc:
                last_exc = exc
                logger.warning(
                    "Model %s failed (%s: %s), trying next fallback...",
                    cm.model, type(exc).__name__, exc,
                )
        raise last_exc  # type: ignore[misc]

    def bind_tools(self, tools: list[Any]) -> "FallbackChatModel":
        """Bind tools to all fallback models."""
        self._models = [cm.bind_tools(tools) for cm in self._models]
        return self

    async def astream(
        self, messages: list[dict[str, Any]], **kwargs: Any
    ) -> AsyncGenerator[Any, None]:
        """Stream from the first available model."""
        last_exc: Exception | None = None
        for cm in self._models:
            try:
                async for chunk in cm.astream(messages, **kwargs):
                    yield chunk
                return
            except Exception as exc:
                last_exc = exc
                logger.warning(
                    "Stream from %s failed, trying next fallback...",
                    cm.model,
                )
        raise last_exc  # type: ignore[misc]

    async def close(self) -> None:
        """Close all model clients."""
        for cm in self._models:
            await cm.close()

    def __repr__(self) -> str:
        models = [cm.model for cm in self._models]
        return f"FallbackChatModel(models={models!r})"


# -- ChatModel --------------------------------------------------


class ChatModel:
    """Governed LLM client for VW LLMaaS.

    Wraps the OpenAI-compatible VW LLMaaS API with automatic OAuth,
    API pattern selection, Langfuse tracing, and smart client caching.

    Supports **two** API patterns:

    * **Chat Completions** -- gpt-4o, gpt-4o-mini, gpt-4.1, gpt-4.1-mini, gpt-4.1-nano
    * **Responses API** -- gpt-5, gpt-5-mini, gpt-5-nano, gpt-5-chat,
      gpt-5.1, gpt-5.1-chat, gpt-5.2

    The correct endpoint is selected automatically based on the model name.

    Use :func:`get_llm` for the simplest construction, or instantiate
    directly when you need fine-grained control::

        llm = ChatModel(model="gpt-4o", temperature=0.2, max_tokens=1024)
        response = await llm.ainvoke(messages)
    """

    # Class-level tracking for ModelAllowlistPolicy auto-detection.
    # Set by __init__; read by GovernedGraph to populate governance_config["model"].
    _last_created_model: str | None = None

    # Task-local token accumulator: reset before each governed node,
    # read after the node completes.  Ensures token tracking works even
    # when the node function discards the ChatCompletionMessage object.
    _node_token_usage: contextvars.ContextVar[int] = contextvars.ContextVar(
        "chatmodel_node_token_usage", default=0,
    )

    # Shared circuit breaker across all ChatModel instances.
    # Opens after 5 consecutive failures, recovers after 30s.
    _circuit_breaker = CircuitBreaker(
        name="llmaas", failure_threshold=5, recovery_timeout=30.0,
    )

    def __init__(
        self,
        model: str | None = None,
        *,
        temperature: float = 0.0,
        max_tokens: int | None = None,
        llmaas_settings: LLMaaSSettings | None = None,
    ) -> None:
        self._settings = llmaas_settings or get_settings().llmaas
        self.model = model or self._settings.model
        self.temperature = temperature
        self.max_tokens = max_tokens

        self._token_manager = TokenManager(self._settings)
        self._client: Any | None = None
        self._client_token: str | None = None  # token the current client was built with
        self._lock = asyncio.Lock()
        self._bound_tools: list[dict[str, Any]] | None = None

        # Response cache (opt-in via enable_cache=True on get_llm)
        self._cache: dict[str, Any] | None = None
        self._cache_maxsize: int = 128

        # Track last created model for ModelAllowlistPolicy auto-detection.
        ChatModel._last_created_model = self.model

    # -- Properties ---------------------------------------------

    @property
    def _uses_responses_api(self) -> bool:
        """Whether this model uses ``/v1/responses`` instead of ``/v1/chat/completions``."""
        return _is_responses_api_model(self.model)

    # -- Client lifecycle ---------------------------------------

    async def _get_client(self) -> Any:
        """Return an ``AsyncOpenAI`` client, recreating only when the token rotates.

        Uses ``langfuse.openai.AsyncOpenAI`` for automatic tracing when Langfuse
        is configured.  Falls back to plain ``openai.AsyncOpenAI`` otherwise.
        """
        token = await self._token_manager.get_token()

        # Fast path -- client exists and token hasn't changed
        if self._client is not None and self._client_token == token:
            return self._client

        async with self._lock:
            # Double-check after acquiring lock
            if self._client is not None and self._client_token == token:
                return self._client

            # Close stale client
            if self._client is not None:
                try:
                    await self._client.close()
                except Exception:
                    logger.debug("Error closing stale LLMaaS client", exc_info=True)

            virtual_key = self._settings.api_key.get_secret_value()

            # Langfuse-aware: use drop-in only when tracing is actually configured
            if is_langfuse_configured():
                try:
                    from langfuse.openai import AsyncOpenAI
                except ImportError:
                    from openai import AsyncOpenAI
            else:
                from openai import AsyncOpenAI

            # Auth pattern per official VW LLMaaS docs:
            #   api_key  = access_token  (SDK auto-adds "Authorization: Bearer {api_key}")
            #   X-LLM-API-CLIENT-ID: Bearer {virtual_key}
            self._client = AsyncOpenAI(
                api_key=token,
                base_url=self._settings.base_url,
                default_headers={
                    "X-LLM-API-CLIENT-ID": f"Bearer {virtual_key}",
                },
                timeout=self._settings.timeout,
                max_retries=self._settings.max_retries,
            )
            self._client_token = token
            logger.debug(
                "AsyncOpenAI client created (model=%s, api=%s, langfuse=%s)",
                self.model,
                "responses" if self._uses_responses_api else "chat.completions",
                is_langfuse_configured(),
            )
            return self._client

    # -- Invoke -------------------------------------------------

    async def ainvoke(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> Any:
        """Send messages to the LLM and return the assistant response.

        Automatically selects the correct VW LLMaaS API:

        - ``chat.completions.create()`` for gpt-4o, gpt-4.1-*, ...
        - ``responses.create()`` for gpt-5, gpt-5-mini, gpt-5.1, gpt-5.2, ...

        Returns:
            For ``chat.completions``: the ``ChatCompletionMessage`` object
            For ``responses``: ``dict(role="assistant", content=...)``

        Both return types are directly appendable to a LangGraph messages list.
        """
        # Response cache: check for a cached response
        cache_key: str | None = None
        if self._cache is not None:
            import hashlib
            raw = _json.dumps(
                {"model": self.model, "messages": messages,
                 "temperature": self.temperature,
                 "max_tokens": self.max_tokens, **kwargs},
                sort_keys=True, default=str,
            )
            cache_key = hashlib.sha256(raw.encode()).hexdigest()
            cached = self._cache.get(cache_key)
            if cached is not None:
                logger.debug("Cache hit for %s (key=%s...)", self.model, cache_key[:8])
                return cached

        client = await self._get_client()

        # Circuit breaker: fail-fast if LLMaaS is unhealthy
        self._circuit_breaker.check()

        try:
            if self._uses_responses_api:
                result = await self._invoke_responses(client, messages, **kwargs)
            else:
                result = await self._invoke_chat(client, messages, **kwargs)
            self._circuit_breaker.record_success()
        except CircuitOpenError:
            raise
        except Exception as exc:
            if is_transient_error(exc):
                self._circuit_breaker.record_failure()
            raise

        # Store in cache
        if self._cache is not None and cache_key is not None:
            if len(self._cache) >= self._cache_maxsize:
                # Evict oldest entry (FIFO)
                oldest = next(iter(self._cache))
                del self._cache[oldest]
            self._cache[cache_key] = result

        return result

    async def _invoke_chat(
        self,
        client: Any,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> Any:
        """Standard ``/v1/chat/completions`` path (gpt-4o, gpt-4.1-*, etc.)."""
        call_kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": self.temperature,
            **kwargs,
        }
        if self.max_tokens is not None:
            call_kwargs["max_tokens"] = self.max_tokens
        if self._bound_tools:
            call_kwargs.setdefault("tools", self._bound_tools)

        response = await client.chat.completions.create(**call_kwargs)
        msg = response.choices[0].message
        # Attach token usage so governance (BudgetPolicy) can track it.
        # The msg may be a Pydantic model that doesn't allow arbitrary attrs,
        # so we also try object.__setattr__ as a fallback.
        usage = getattr(response, "usage", None)
        if usage is not None:
            usage_dict = {
                "prompt_tokens": getattr(usage, "prompt_tokens", 0) or 0,
                "completion_tokens": getattr(usage, "completion_tokens", 0) or 0,
                "total_tokens": getattr(usage, "total_tokens", 0) or 0,
            }
            try:
                msg._ab_usage = usage_dict  # type: ignore[attr-defined]
            except (AttributeError, ValueError):
                try:
                    object.__setattr__(msg, "_ab_usage", usage_dict)
                except Exception:
                    logger.debug("Cannot attach _ab_usage to message object")
            # Accumulate into task-local counter for governed graph
            ChatModel._node_token_usage.set(
                ChatModel._node_token_usage.get(0) + usage_dict["total_tokens"]
            )
        return msg

    async def _invoke_responses(
        self,
        client: Any,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """GPT-5 family ``/v1/responses`` path.

        The Responses API accepts ``input`` as either a string or a list of
        message-like items.  When tools are bound we send structured items so
        that function_call / function_call_output round-trips work correctly.

        Note: Langfuse kwargs (``langfuse_trace_id``, etc.) are **not** passed
        to ``responses.create()`` because the Langfuse drop-in wrapper does
        not yet intercept the Responses API.  Tracing for GPT-5 family models
        is handled at the graph/node level via the LangGraph callback system.
        """
        # Build input -- structured when tool messages are present or tools
        # are bound, flat text otherwise.
        input_data = self._build_responses_input(messages)

        call_kwargs: dict[str, Any] = {
            "model": self.model,
            "input": input_data,
            **kwargs,
        }
        # Note: GPT-5 family via VW LLMaaS does not support the temperature
        # parameter. Omitting it intentionally to avoid 400 errors.
        if self.max_tokens is not None:
            call_kwargs["max_output_tokens"] = self.max_tokens

        # Pass tools when bound (converted to Responses API format)
        if self._bound_tools:
            call_kwargs["tools"] = self._tools_to_responses_format(
                self._bound_tools
            )

        response = await client.responses.create(**call_kwargs)

        # Check for function_call items first (tool calling)
        tool_calls = self._extract_responses_tool_calls(response)
        if tool_calls:
            return {
                "role": "assistant",
                "content": "",
                "tool_calls": tool_calls,
            }

        content = self._extract_responses_text(response)

        # Attach token usage if available so governance can track it.
        result: dict[str, Any] = {"role": "assistant", "content": content}
        usage = getattr(response, "usage", None)
        if usage is not None:
            result["_ab_usage"] = {
                "prompt_tokens": getattr(usage, "input_tokens", 0) or 0,
                "completion_tokens": getattr(usage, "output_tokens", 0) or 0,
                "total_tokens": (
                    (getattr(usage, "input_tokens", 0) or 0)
                    + (getattr(usage, "output_tokens", 0) or 0)
                ),
            }
            # Accumulate into task-local counter for governed graph
            ChatModel._node_token_usage.set(
                ChatModel._node_token_usage.get(0) + result["_ab_usage"]["total_tokens"]
            )
        return result

    # -- Streaming ----------------------------------------------

    async def astream(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> AsyncGenerator[str, None]:
        """Stream tokens from the LLM.

        Yields content strings as they arrive.

        Note: GPT-5 family models may not support streaming -- in that case
        the full response is yielded as a single chunk.
        """
        client = await self._get_client()

        # Circuit breaker: fail-fast if LLMaaS is unhealthy
        self._circuit_breaker.check()

        try:
            if self._uses_responses_api:
                logger.debug("Model %s: streaming not supported, yielding full response", self.model)
                result = await self._invoke_responses(client, messages, **kwargs)
                self._circuit_breaker.record_success()
                yield result["content"]
                return

            call_kwargs: dict[str, Any] = {
                "model": self.model,
                "messages": messages,
                "temperature": self.temperature,
                "stream": True,
                **kwargs,
            }
            if self.max_tokens is not None:
                call_kwargs["max_tokens"] = self.max_tokens
            if self._bound_tools:
                call_kwargs.setdefault("tools", self._bound_tools)

            response = await client.chat.completions.create(**call_kwargs)
            async for chunk in response:
                if chunk.choices and chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content
            self._circuit_breaker.record_success()
        except CircuitOpenError:
            raise
        except Exception as exc:
            if is_transient_error(exc):
                self._circuit_breaker.record_failure()
            raise

    # -- Tool binding -------------------------------------------

    def bind_tools(self, tools: list[Any]) -> "ChatModel":
        """Return a copy of this model with tools bound for function-calling agents.

        Usage::

            from agentic_blueprint import get_llm, tool

            @tool
            def get_weather(city: str) -> str:
                return f"Sunny in {city}"

            llm = get_llm(model="gpt-4o")
            llm_with_tools = llm.bind_tools([get_weather])
        """
        bound = ChatModel(
            model=self.model,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            llmaas_settings=self._settings,
        )
        # Share the token manager to avoid duplicate OAuth flows
        bound._token_manager = self._token_manager
        bound._bound_tools = self._convert_tools(tools)
        # Preserve cache settings from the original model
        bound._cache = self._cache
        bound._cache_maxsize = getattr(self, "_cache_maxsize", None)
        return bound

    @staticmethod
    def _convert_tools(tools: list[Any]) -> list[dict[str, Any]]:
        """Convert tool objects to OpenAI function-calling format.

        Uses ``langchain_core.utils.function_calling.convert_to_openai_function``
        when available for robust handling of LangChain ``BaseTool`` objects
        (including those with non-serialisable ``args_schema`` fields such as
        callables).  Falls back to manual ``model_json_schema()`` only when the
        LangChain utility is unavailable.
        """
        # Try LangChain's robust converter first (handles callables, etc.)
        converted: list[dict[str, Any]] = []
        for t in tools:
            # Already in OpenAI dict format
            if isinstance(t, dict):
                converted.append(t)
            # Use LangChain's converter if available (handles all edge cases)
            elif _lc_convert is not None and (
                hasattr(t, "name") or callable(t)
            ):
                fn_schema = _lc_convert(t)
                # Ensure wrapped in {"type": "function", "function": ...}
                if "type" not in fn_schema:
                    fn_schema = {"type": "function", "function": fn_schema}
                converted.append(fn_schema)
            # LangChain BaseTool fallback -- .name, .description, .args_schema
            elif hasattr(t, "name") and hasattr(t, "args_schema"):
                schema = t.args_schema.model_json_schema() if t.args_schema else {}
                converted.append({
                    "type": "function",
                    "function": {
                        "name": t.name,
                        "description": getattr(t, "description", ""),
                        "parameters": schema,
                    },
                })
            else:
                raise TypeError(
                    f"Cannot convert {type(t).__name__} to OpenAI tool format. "
                    "Pass a @tool-decorated function, a BaseTool, or a dict."
                )
        return converted

    # -- Response parsing ---------------------------------------

    @staticmethod
    def _messages_to_input(messages: list[dict[str, Any]]) -> str:
        """Convert a message list to a flat input string for the Responses API.

        Extracts the last user message content.  For multi-turn conversations
        the full history is concatenated with role labels.
        """
        # Single user message -- pass content directly
        if len(messages) == 1:
            content = messages[0].get("content", "")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                return " ".join(
                    p.get("text", "") for p in content if p.get("type") == "text"
                )

        # Multi-turn -- concatenate with role prefixes for context
        parts: list[str] = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if isinstance(content, list):
                content = " ".join(
                    p.get("text", "") for p in content if p.get("type") == "text"
                )
            if not content:
                continue
            if role == "system":
                parts.append(f"[System]: {content}")
            elif role == "assistant":
                parts.append(f"[Assistant]: {content}")
            else:
                parts.append(content)
        return "\n\n".join(parts)

    @staticmethod
    def _extract_responses_text(response: Any) -> str:
        """Extract text from the GPT-5 family Responses API structure.

        ``response.output`` is a list that may contain:
        - ``ResponseReasoningItem`` (thinking/reasoning -- gpt-5 extended thinking)
        - ``ResponseOutputMessage`` (actual answer)
          - ``output[-1].content[0].text``: The text response
        """
        try:
            if isinstance(response.output, list) and len(response.output) > 1:
                # Last item is the actual answer (ResponseOutputMessage)
                output_message = response.output[-1]
                if hasattr(output_message, "content") and output_message.content:
                    texts = [item.text for item in output_message.content
                             if hasattr(item, "text")]
                    if texts:
                        return "\n".join(texts).strip()

            # Fallback: single-item output
            if isinstance(response.output, list) and response.output:
                first = response.output[0]
                if hasattr(first, "content") and first.content:
                    texts = [item.text for item in first.content
                             if hasattr(item, "text")]
                    if texts:
                        return "\n".join(texts).strip()

            logger.warning("Unexpected Responses API structure, using str() fallback")
            return str(response.output).strip()

        except Exception as exc:
            logger.error("Failed to extract Responses API text: %s", exc)
            return str(response.output).strip()

    @staticmethod
    def _has_image_content(messages: list[dict[str, Any]]) -> bool:
        """Check whether any message contains image content parts."""
        for msg in messages:
            content = msg.get("content")
            if isinstance(content, list):
                for part in content:
                    if isinstance(part, dict) and part.get("type") in (
                        "image_url", "input_image",
                    ):
                        return True
        return False

    @staticmethod
    def _convert_content_to_responses_format(
        content: Any,
    ) -> list[dict[str, Any]] | str:
        """Convert message content to Responses API content format.

        Handles multimodal content lists containing ``image_url`` parts
        by converting them to Responses API ``input_image`` items.
        """
        if isinstance(content, str):
            return content
        if not isinstance(content, list):
            return str(content) if content else ""

        parts: list[dict[str, Any]] = []
        for item in content:
            if not isinstance(item, dict):
                continue
            item_type = item.get("type", "")
            if item_type == "text":
                parts.append({"type": "input_text", "text": item.get("text", "")})
            elif item_type == "input_text":
                parts.append(item)
            elif item_type == "image_url":
                # Convert Chat Completions image_url to Responses API input_image
                image_data = item.get("image_url", {})
                url = image_data.get("url", "") if isinstance(image_data, dict) else str(image_data)
                parts.append({"type": "input_image", "image_url": url})
            elif item_type == "input_image":
                parts.append(item)

        # If only text parts, return as plain string for simplicity
        has_non_text = any(p.get("type") != "input_text" for p in parts)
        if not has_non_text and parts:
            return " ".join(p.get("text", "") for p in parts)
        return parts

    @staticmethod
    def _build_responses_input(
        messages: list[dict[str, Any]],
    ) -> list[dict[str, Any]] | str:
        """Build Responses API ``input`` from message dicts.

        Returns a **structured list** when tool calls, tool results, or
        multimodal (image) content is present.  Falls back to a flat text
        string for simple text-only prompts.
        """
        has_tool_data = any(
            m.get("tool_calls") or m.get("role") == "tool"
            for m in messages
        )
        has_images = ChatModel._has_image_content(messages)

        if not has_tool_data and not has_images:
            return ChatModel._messages_to_input(messages)

        # Structured input for tool-augmented / multimodal conversations
        items: list[dict[str, Any]] = []
        for msg in messages:
            role = msg.get("role", "user")
            raw_content = msg.get("content", "")

            if role in ("system", "user"):
                content = ChatModel._convert_content_to_responses_format(raw_content)
                # Responses API uses "developer" instead of "system"
                api_role = "developer" if role == "system" else role
                items.append({"role": api_role, "content": content})
            elif role == "assistant":
                if msg.get("tool_calls"):
                    # Emit each tool call as a function_call item
                    for tc in msg["tool_calls"]:
                        fn = tc.get("function", {})
                        items.append({
                            "type": "function_call",
                            "call_id": tc.get("id", ""),
                            "name": fn.get("name", ""),
                            "arguments": fn.get("arguments", "{}"),
                        })
                elif raw_content:
                    items.append({"role": "assistant", "content": raw_content if isinstance(raw_content, str) else str(raw_content)})
            elif role == "tool":
                # ToolMessage -> function_call_output
                items.append({
                    "type": "function_call_output",
                    "call_id": msg.get("tool_call_id", ""),
                    "output": raw_content if isinstance(raw_content, str) else str(raw_content),
                })

        return items

    @staticmethod
    def _tools_to_responses_format(
        tools: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Convert Chat Completions tool schema to Responses API format.

        Chat Completions:
            ``{"type": "function", "function": {"name": ..., "parameters": ...}}``
        Responses API:
            ``{"type": "function", "name": ..., "parameters": ...}``

        Tool names are sanitised to match the API pattern
        ``^[a-zA-Z0-9_.-]+$`` (slashes replaced with dots).
        """
        _SAFE_NAME_RE = re.compile(r"[^a-zA-Z0-9_\-]")

        converted: list[dict[str, Any]] = []
        for tool in tools:
            if tool.get("type") == "function" and "function" in tool:
                fn = tool["function"]
                safe_name = _SAFE_NAME_RE.sub("_", fn["name"])
                converted.append({
                    "type": "function",
                    "name": safe_name,
                    "description": fn.get("description", ""),
                    "parameters": fn.get("parameters", {}),
                })
            else:
                converted.append(tool)
        return converted

    @staticmethod
    def _extract_responses_tool_calls(
        response: Any,
    ) -> list[dict[str, Any]] | None:
        """Extract ``function_call`` items from Responses API output.

        Returns a list of OpenAI-style tool_call dicts when function calls
        are present, otherwise ``None``.
        """
        if not hasattr(response, "output") or not response.output:
            return None

        tool_calls: list[dict[str, Any]] = []
        for item in response.output:
            if getattr(item, "type", None) == "function_call":
                tool_calls.append({
                    "id": getattr(item, "call_id", ""),
                    "type": "function",
                    "function": {
                        "name": getattr(item, "name", ""),
                        "arguments": getattr(item, "arguments", "{}"),
                    },
                })

        return tool_calls if tool_calls else None

    # -- Sync convenience ---------------------------------------

    def invoke(self, messages: list[dict[str, Any]], **kwargs: Any) -> Any:
        """Synchronous wrapper around :meth:`ainvoke`."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if loop is not None:
            import concurrent.futures
            ctx = contextvars.copy_context()
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(ctx.run, asyncio.run, self.ainvoke(messages, **kwargs)).result()
        return asyncio.run(self.ainvoke(messages, **kwargs))

    # -- Cleanup ------------------------------------------------

    async def close(self) -> None:
        """Release HTTP resources."""
        await self._token_manager.close()
        if self._client is not None:
            try:
                await self._client.close()
            except Exception:
                logger.debug("error closing AsyncOpenAI client in ChatModel", exc_info=True)
            self._client = None
            self._client_token = None

    def __repr__(self) -> str:
        api = "responses" if self._uses_responses_api else "chat.completions"
        return f"ChatModel(model={self.model!r}, api={api!r}, temperature={self.temperature})"

