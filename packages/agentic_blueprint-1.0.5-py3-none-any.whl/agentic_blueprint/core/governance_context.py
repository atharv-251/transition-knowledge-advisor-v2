"""Sidecar governance context -- framework-agnostic state via ``contextvars``.

This module replaces the ``GovernedState`` pattern.  Instead of polluting
the developer's ``TypedDict`` with ``af_*`` fields, governance metadata
lives in a thread-local / task-local ``GovernanceCtx`` that is:

* **invisible** to the developer's graph state,
* **framework-agnostic** -- works with LangGraph, CrewAI, plain async,
* **readable** from anywhere via :func:`governance_context`.

Lifecycle
---------
``wrap()`` and ``guard()`` create and tear down the context automatically::

    governed = agentic_blueprint.wrap(graph, guards=[...])
    result = await governed.ainvoke(state)

    # Inside any guard, tool, or node:
    ctx = agentic_blueprint.governance_context()
    ctx.trace_id     # current Langfuse trace
    ctx.user_id      # resolved user
    ctx.node_history  # ["plan", "search", "synthesise"]

Developer helpers
-----------------
Two explicit setters let the developer signal evaluation data without
touching the graph state::

    agentic_blueprint.set_output("The answer is 42.")
    agentic_blueprint.set_retrieval_context(["doc1", "doc2"])
"""

from __future__ import annotations

import contextvars
from dataclasses import dataclass, field
from typing import Any


@dataclass
class GovernanceCtx:
    """Snapshot of governance state for the current invocation.

    Created by ``wrap()``/``guard()`` at the start of an invocation.
    Guards, audit, and tracing components read from here instead of
    from the graph state.
    """

    # -- Identity (set by wrap/guard at invocation start) -------
    trace_id: str = ""
    session_id: str = ""
    user_id: str = ""
    project_id: str = ""
    workflow_id: str = ""
    agent_id: str = ""
    agent_version: str = ""

    # -- Execution tracking (updated per-node by wrap) ----------
    node_history: list[str] = field(default_factory=list)
    step_count: int = 0

    # -- Guard metadata (guards append here) --------------------
    metadata: dict[str, Any] = field(default_factory=dict)

    # -- Token / cost tracking (accumulated by wrap per-node) ----
    total_tokens: int = 0
    total_cost: float = 0.0

    # -- Block propagation (set by guardrail soft-block) ---------
    blocked_response: str | None = None

    # -- Evaluation contract (developer sets via helpers) --------
    output: str | None = None
    retrieval_context: list[str] = field(default_factory=list)

    # -- Graph-level input/output (set by wrap) -----------------
    input_state: dict[str, Any] = field(default_factory=dict)
    output_state: dict[str, Any] | None = None

    # -- HITL: checkpoint serialization -------------------------

    def to_checkpoint_data(self) -> dict[str, Any]:
        """Serialize governance state for LangGraph checkpoint persistence.

        Called automatically by the SDK when a ``NodeInterrupt`` pauses
        execution.  The serialized data is stored alongside the graph
        state in the checkpointer so governance context survives across
        process restarts.

        Returns
        -------
        dict
            JSON-serializable dict of governance state.
        """
        return {
            "trace_id": self.trace_id,
            "session_id": self.session_id,
            "user_id": self.user_id,
            "project_id": self.project_id,
            "workflow_id": self.workflow_id,
            "node_history": list(self.node_history),
            "step_count": self.step_count,
            "total_tokens": self.total_tokens,
            "total_cost": self.total_cost,
            "metadata": self.metadata,
            "blocked_response": self.blocked_response,
            "output": self.output,
            "retrieval_context": list(self.retrieval_context),
            "agent_id": self.agent_id,
            "agent_version": self.agent_version,
            "input_state": self.input_state,
            "output_state": self.output_state,
        }

    @classmethod
    def from_checkpoint_data(cls, data: dict[str, Any]) -> "GovernanceCtx":
        """Restore governance context from checkpoint data.

        Called automatically by the SDK when resuming from a
        ``NodeInterrupt``.  Restores budget tracking, step counters,
        and audit trail so governance is continuous across the pause.

        Parameters
        ----------
        data : dict
            The dict previously returned by :meth:`to_checkpoint_data`.

        Returns
        -------
        GovernanceCtx
            A new context with all governance state restored.
        """
        return cls(
            trace_id=data.get("trace_id", ""),
            session_id=data.get("session_id", ""),
            user_id=data.get("user_id", ""),
            project_id=data.get("project_id", ""),
            workflow_id=data.get("workflow_id", ""),
            node_history=list(data.get("node_history", [])),
            step_count=data.get("step_count", 0),
            total_tokens=data.get("total_tokens", 0),
            total_cost=data.get("total_cost", 0.0),
            metadata=dict(data.get("metadata", {})),
            blocked_response=data.get("blocked_response"),
            output=data.get("output"),
            retrieval_context=list(data.get("retrieval_context", [])),
            agent_id=data.get("agent_id", ""),
            agent_version=data.get("agent_version", ""),
            input_state=dict(data.get("input_state", {})),
            output_state=data.get("output_state"),
        )


# -- Context variable -------------------------------------------

_governance_ctx_var: contextvars.ContextVar[GovernanceCtx | None] = (
    contextvars.ContextVar("agentic_blueprint_governance_ctx", default=None)
)


# -- Internal management (used by wrap/guard) -------------------


def _set_governance_ctx(ctx: GovernanceCtx | None) -> contextvars.Token[GovernanceCtx | None]:
    """Set the active governance context.  Internal use only."""
    return _governance_ctx_var.set(ctx)


def _get_governance_ctx() -> GovernanceCtx | None:
    """Return the active governance context, or ``None``."""
    return _governance_ctx_var.get()


# -- Public API -------------------------------------------------


def governance_context() -> GovernanceCtx:
    """Return the active governance context for the current invocation.

    Call this from guards, tools, node functions, or anywhere during a
    governed execution to read identity, node history, guard metadata, etc.

    Raises:
        RuntimeError: If called outside a ``wrap()`` or ``guard()`` scope.

    Example::

        from agentic_blueprint import governance_context

        ctx = governance_context()
        print(ctx.trace_id, ctx.user_id, ctx.node_history)
    """
    ctx = _governance_ctx_var.get()
    if ctx is None:
        raise RuntimeError(
            "governance_context() called outside a governed execution scope. "
            "Ensure your code is running inside agentic_blueprint.wrap() or "
            "agentic_blueprint.guard()."
        )
    return ctx


def set_output(text: str) -> None:
    """Record the agent's final output for evaluation metrics.

    Call this in your final node or at the end of your orchestrator::

        async def synthesise(state):
            answer = await llm.ainvoke(state["messages"])
            agentic_blueprint.set_output(answer.content)
            return {"answer": answer.content}

    If not called, ``wrap()`` will attempt to auto-capture the output
    from the final node's return value.
    """
    ctx = _governance_ctx_var.get()
    if ctx is not None:
        ctx.output = text


def set_retrieval_context(documents: list[str]) -> None:
    """Record retrieved source passages for grounding evaluation.

    Call this in your retrieval node::

        async def search(state):
            results = [search_wikipedia(q) for q in state["queries"]]
            agentic_blueprint.set_retrieval_context(results)
            return {"search_results": results}
    """
    ctx = _governance_ctx_var.get()
    if ctx is not None:
        ctx.retrieval_context = list(documents)


def build_eval_state(
    result: dict[str, Any] | None = None,
    *,
    ctx: GovernanceCtx | None = None,
) -> dict[str, Any]:
    """Build an evaluation-ready dict by merging GovernanceCtx into a result.

    Call this after ``governed.ainvoke()`` to produce a dict compatible
    with ``AtlasTestCase.from_result()``::

        governed = agentic_blueprint.wrap(graph, guards=[...])
        result = await governed.ainvoke(state)
        eval_state = agentic_blueprint.build_eval_state(result, ctx=governed.last_governance_ctx)
        test_case = AtlasTestCase.from_result(eval_state, input=question)

    Parameters
    ----------
    result:
        The result dict from ``governed.ainvoke()`` or ``governed_fn(state)``.
        If ``None``, an empty dict is used.
    ctx:
        An explicit ``GovernanceCtx`` to read governance data from.
        If ``None``, reads from the active contextvar (works if called
        inside a ``wrap()``/``guard()`` scope).  When calling **after**
        ``ainvoke()`` returns (context is torn down), pass
        ``governed.last_governance_ctx``.

    Returns
    -------
    dict
        A **copy** of *result* with ``ab_*`` governance fields merged in.
    """
    # If caller accidentally passes GovernanceCtx as *result*, treat it as ctx.
    if isinstance(result, GovernanceCtx):
        if ctx is None:
            ctx = result
        result = None

    out = dict(result or {})
    ctx = ctx or _governance_ctx_var.get()
    if ctx is None:
        return out

    out.setdefault("ab_output", ctx.output or "")
    out.setdefault("ab_retrieval_context", ctx.retrieval_context)
    out.setdefault("ab_trace_id", ctx.trace_id)
    out.setdefault("ab_session_id", ctx.session_id)
    out.setdefault("ab_user_id", ctx.user_id)
    out.setdefault("ab_project_id", ctx.project_id)
    out.setdefault("ab_workflow_id", ctx.workflow_id)
    out.setdefault("ab_node_history", ctx.node_history)
    out.setdefault("ab_governance_metadata", ctx.metadata)
    return out
