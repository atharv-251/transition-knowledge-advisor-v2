"""Native-first governance middleware -- ``wrap()`` and ``guard()``.

This module provides the core public API for the Agentic Blueprint SDK.
Instead of requiring developers to use custom graph builders or state
schemas, governance is applied transparently to **native** framework
objects.

Quick start::

    import agentic_blueprint

    graph = builder.compile()
    governed = agentic_blueprint.wrap(graph, name="my-agent")
    result = await governed.ainvoke({"messages": [...]})
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Sequence

from agentic_blueprint.governance.guards import GovernanceGuard
from agentic_blueprint.governance.profile import (
    get_all_risk_guard_names,
    get_platform_defaults,
    get_risk_guards,
)
from agentic_blueprint.governance.risk import RiskClass
from agentic_blueprint.governance.project_registry import require_platform_init

# ---------------------------------------------------------------------------
# Re-exports for backward compatibility.
# External code may import directly from ``agentic_blueprint.core.wrap``.
# ---------------------------------------------------------------------------
from agentic_blueprint.frameworks.langgraph.governed_graph import GovernedGraph  # noqa: F401
from agentic_blueprint.core.langfuse_client import (  # noqa: F401
    get_langfuse_client as _get_langfuse_client,
)
from agentic_blueprint.core.governed_callable import GovernedCallable  # noqa: F401
from agentic_blueprint.frameworks.base import GovernedBase  # noqa: F401

logger = logging.getLogger(__name__)

__all__ = [
    "wrap", "guard", "register_framework",
    "GovernedGraph", "GovernedBase", "GovernedCallable",
]


# ---------------------------------------------------------------------------
# Framework registry — {detector_fn: adapter_class}
# ---------------------------------------------------------------------------
# Each entry is a (detector, adapter_class) tuple.  ``detector`` is a
# callable ``(obj) -> bool`` that duck-types whether ``obj`` is an
# instance of that framework.  ``adapter_class`` is the
# :class:`GovernedBase` subclass (or compatible) to wrap it with.
#
# Detectors are checked in insertion order.  The first match wins.
# LangGraph is always last as the default fallback.
# ---------------------------------------------------------------------------

_FRAMEWORK_REGISTRY: list[tuple[Callable[[Any], bool], type]] = []


def _is_langgraph_graph(obj: Any) -> bool:
    """Duck-type check for a compiled LangGraph graph (default fallback)."""
    return hasattr(obj, "nodes") and (
        hasattr(obj, "ainvoke") or hasattr(obj, "invoke")
    )


def _is_crewai_crew(obj: Any) -> bool:
    """Duck-type check for a CrewAI ``Crew`` instance."""
    return (
        hasattr(obj, "kickoff")
        and hasattr(obj, "agents")
        and hasattr(obj, "tasks")
        and callable(getattr(obj, "kickoff", None))
    )


def register_framework(
    detector: Callable[[Any], bool],
    adapter_class: type,
    *,
    priority: int | None = None,
) -> None:
    """Register a framework adapter for auto-detection in ``wrap()``.

    Parameters
    ----------
    detector:
        A callable ``(obj) -> bool`` that returns ``True`` if *obj*
        is an instance of the target framework.
    adapter_class:
        The adapter class (typically a :class:`GovernedBase` subclass)
        to instantiate when the detector matches.
    priority:
        Insertion index in the registry (``0`` = check first).
        ``None`` inserts before the LangGraph fallback.

    Example::

        from agentic_blueprint import register_framework
        from my_adapter import GovernedAutoGen, is_autogen_team

        register_framework(is_autogen_team, GovernedAutoGen)
    """
    entry = (detector, adapter_class)
    if priority is not None:
        _FRAMEWORK_REGISTRY.insert(priority, entry)
    else:
        # Insert before the last entry (LangGraph fallback)
        if _FRAMEWORK_REGISTRY:
            _FRAMEWORK_REGISTRY.insert(len(_FRAMEWORK_REGISTRY) - 1, entry)
        else:
            _FRAMEWORK_REGISTRY.append(entry)


def _detect_framework(obj: Any) -> tuple[str, type]:
    """Walk the registry and return (framework_name, adapter_class)."""
    for detector, adapter_cls in _FRAMEWORK_REGISTRY:
        try:
            if detector(obj):
                return adapter_cls.__name__, adapter_cls
        except Exception:
            logger.debug("framework detector %s raised an error", adapter_cls.__name__, exc_info=True)
            continue
    # Should not reach here — LangGraph fallback is always registered
    return "GovernedGraph", GovernedGraph


# Register built-in frameworks (order matters — checked first to last)
try:
    from agentic_blueprint.frameworks.crewai.governed_crew import GovernedCrew  # noqa: F401
    _FRAMEWORK_REGISTRY.append((_is_crewai_crew, GovernedCrew))
except ImportError:
    pass  # CrewAI not installed — skip

_FRAMEWORK_REGISTRY.append((_is_langgraph_graph, GovernedGraph))  # always last


# ---------------------------------------------------------------------------
# Public factory functions
# ---------------------------------------------------------------------------


def wrap(
    compiled_graph: Any,
    *,
    name: str | None = None,
    guards: Sequence[GovernanceGuard] = (),
    scoped_guards: dict[str, Sequence[GovernanceGuard]] | None = None,
    tags: Sequence[str] = (),
    project_id: str | None = None,
    workflow_id: str | None = None,
    risk_class: RiskClass | str = RiskClass.MEDIUM,
    autonomy: "AutonomyLevel | str" = "a1_assisted",
    impact: "ImpactClass | str" = "d1_advisory",
    data_sensitivity: "DataSensitivity | str" = "internal",
    exposure: "ExposureLevel | str" = "level_1_internal",
    identity_mode: "IdentityMode | str" = "service_account",
    agent_id: str | None = None,
    agent_version: str | None = None,
    lifecycle: "AgentLifecycleState | str" = "active",
    block_responses: dict[str, str] | None = None,
    hitl_managed: bool = False,
) -> "GovernedBase | GovernedGraph":
    """Wrap a compiled framework object with transparent governance.

    Auto-detects the framework (LangGraph, CrewAI, or any registered
    adapter) and returns the appropriate governed wrapper.

    Third-party frameworks can be registered via
    :func:`register_framework`.

    Parameters
    ----------
    compiled_graph:
        A compiled LangGraph, CrewAI Crew, or any registered framework
        object.  Auto-detected at runtime via the framework registry.
    name:
        Agent / workflow name (appears in Langfuse traces).
    guards:
        Global guards that run on **every** execution unit.
    scoped_guards:
        Guards scoped to a named execution unit (additive on top of global).
        Keys are node names (LangGraph) or step names.
    tags:
        Tags for Langfuse traces.
    project_id:
        Override project identity.
    workflow_id:
        Override workflow identity.
    risk_class:
        Risk classification (``LOW``, ``MEDIUM``, ``HIGH``).
    autonomy:
        Autonomy level (``A1_ASSISTED`` .. ``A4_AUTONOMOUS``).
        Default: ``A1_ASSISTED``.
        When combined with ``impact=D3_IRREVERSIBLE``, the SDK enforces
        the Safety Valve rule: autonomy must be ≤ A3.
    impact:
        Business impact class (``D1_ADVISORY``, ``D2_REVERSIBLE``,
        ``D3_IRREVERSIBLE``).  Default: ``D1_ADVISORY``.
        D3 auto-injects ``HumanReviewGuard``.
    data_sensitivity:
        Data sensitivity (``PUBLIC`` .. ``PII_GDPR``).
        Default: ``INTERNAL``.  SECRET/PII_GDPR
        warns when ``identity_mode`` is not OBO (Privacy Guard rule).
    exposure:
        Environmental exposure level.  Default: ``LEVEL_1_INTERNAL``.
        LEVEL_3_EXTERNAL auto-escalates audit level to FULL
        (Screenshot Defense rule).
    identity_mode:
        Identity mode (``SERVICE_ACCOUNT`` or ``ON_BEHALF_OF``).
        Default: ``SERVICE_ACCOUNT``.
        OBO is the recommended mode for PII/Secret workloads.
    agent_id:
        A stable unique identifier for this agent
        (e.g. ``urn:vw:agent:procurement:abc-123``).
        Propagated into Langfuse trace metadata for discoverability.
    agent_version:
        Semantic version string for this agent (e.g. ``"2.3.0"``).
        Propagated into Langfuse trace metadata.
    lifecycle:
        Agent lifecycle state (``ACTIVE``, ``DEPRECATED``, ``RETIRED``).
        Default: ``ACTIVE``.
        ``DEPRECATED`` emits a runtime warning; ``RETIRED`` raises
        ``GovernanceError`` at ``wrap()`` time.
    block_responses:
        Custom user-facing messages for mandate guardrails that block.
    hitl_managed:
        If ``True``, the SDK will **not** auto-inject ``HumanReviewGuard``
        when ``impact=D3_IRREVERSIBLE``.  Set this when the developer
        handles HITL natively (e.g. via LangGraph ``interrupt()`` inside
        node functions).  The Safety Valve enforcement (A4+D3 blocked)
        still applies.  Default: ``False``.

    Returns
    -------
    GovernedBase | GovernedGraph
        A governed wrapper with ``ainvoke()``, ``invoke()``, and
        framework-specific methods.
        The concrete type depends on the detected framework.
    """
    require_platform_init()

    if isinstance(risk_class, str):
        risk_class = RiskClass(risk_class.lower())

    # --- Resolve taxonomy enums from strings ---
    from agentic_blueprint.governance.risk import (
        AutonomyLevel,
        ImpactClass,
        DataSensitivity,
        ExposureLevel,
        AgentLifecycleState,
    )
    from agentic_blueprint.governance.identity import IdentityMode

    resolved_lifecycle = AgentLifecycleState(lifecycle) if isinstance(lifecycle, str) else lifecycle

    # --- Lifecycle enforcement ---
    if resolved_lifecycle == AgentLifecycleState.RETIRED:
        from agentic_blueprint.exceptions import GovernanceError
        raise GovernanceError(
            f"Agent '{name or 'agent'}' has lifecycle=RETIRED and is "
            f"decommissioned.  Retired agents cannot be wrapped or executed.  "
            f"Remove this agent or set lifecycle='active'."
        )
    if resolved_lifecycle == AgentLifecycleState.DEPRECATED:
        import warnings
        warnings.warn(
            f"Agent '{name or 'agent'}' has lifecycle=DEPRECATED.  "
            f"This agent is scheduled for retirement.  "
            f"Migrate to the replacement agent before the sunset date.",
            stacklevel=2,
        )

    resolved_autonomy = AutonomyLevel(autonomy) if isinstance(autonomy, str) else autonomy
    resolved_impact = ImpactClass(impact) if isinstance(impact, str) else impact
    resolved_sensitivity = DataSensitivity(data_sensitivity) if isinstance(data_sensitivity, str) else data_sensitivity
    resolved_exposure = ExposureLevel(exposure) if isinstance(exposure, str) else exposure
    resolved_identity = IdentityMode(identity_mode) if isinstance(identity_mode, str) else identity_mode

    # --- Safety Valve: D3 (Irreversible) → max A3 (HITL) ---
    if resolved_impact == ImpactClass.D3_IRREVERSIBLE:
        if resolved_autonomy.value == AutonomyLevel.A4_AUTONOMOUS.value:
            from agentic_blueprint.exceptions import GovernanceError
            raise GovernanceError(
                "Safety Valve violation: impact=D3_IRREVERSIBLE requires "
                "autonomy ≤ A3_DELEGATED (Human-in-the-Loop).  "
                "An A4_AUTONOMOUS agent MUST NOT perform irreversible actions "
                "without human approval.  Either set autonomy=A3_DELEGATED "
                "or lower impact to D2_REVERSIBLE."
            )

    # --- Privacy Guard: SECRET/PII data → warn if not OBO ---
    if resolved_sensitivity in (DataSensitivity.SECRET, DataSensitivity.PII_GDPR):
        if resolved_identity == IdentityMode.SERVICE_ACCOUNT:
            import warnings
            warnings.warn(
                f"Privacy Guard: data_sensitivity={resolved_sensitivity.value} "
                f"requires identity_mode=ON_BEHALF_OF (OBO).  "
                f"Using SERVICE_ACCOUNT with Secret/PII data violates "
                f"VW Agentic Standards §1.  Set identity_mode='on_behalf_of' "
                f"when OBO integration is available.",
                stacklevel=2,
            )

    # --- Screenshot Defense: External exposure → full audit ---
    if resolved_exposure == ExposureLevel.LEVEL_3_EXTERNAL:
        from agentic_blueprint.config.settings import get_settings
        s = get_settings()
        from agentic_blueprint.config.settings import AuditLevel
        if s.audit_level != AuditLevel.FULL:
            logger.warning(
                "Screenshot Defense: exposure=LEVEL_3_EXTERNAL requires "
                "audit_level=FULL for payload logging.  Current: %s.  "
                "Auto-escalating to FULL for this agent.",
                s.audit_level.value,
            )
            # Note: We don't mutate global settings; instead the
            # AuditGuard will check exposure on the ExecutionContext.

    # --- D3 auto-injects HumanReviewGuard if missing ---
    if resolved_impact == ImpactClass.D3_IRREVERSIBLE and not hitl_managed:
        has_hitl = any(
            type(g).__name__ == "HumanReviewGuard"
            for g in guards
        )
        has_scoped_hitl = False
        if scoped_guards:
            for _node_guards in scoped_guards.values():
                if any(type(g).__name__ == "HumanReviewGuard" for g in _node_guards):
                    has_scoped_hitl = True
                    break
        if not has_hitl and not has_scoped_hitl:
            from agentic_blueprint.governance.guardrails.human_review import HumanReviewGuard
            logger.info(
                "wrap(%s): impact=D3_IRREVERSIBLE — auto-injecting "
                "HumanReviewGuard (Safety Valve enforcement)",
                name or "agent",
            )
            guards = [*guards, HumanReviewGuard(
                instructions="Safety Valve: This agent performs irreversible actions. "
                             "Human approval is required before execution.",
            )]

    # Log taxonomy (always present — all params are required)
    logger.info(
        "wrap(%s): taxonomy: autonomy=%s, impact=%s, data_sensitivity=%s, "
        "exposure=%s, identity_mode=%s, lifecycle=%s, agent_id=%s, "
        "agent_version=%s",
        name or "agent",
        resolved_autonomy.value,
        resolved_impact.value,
        resolved_sensitivity.value,
        resolved_exposure.value,
        resolved_identity.value,
        resolved_lifecycle.value,
        agent_id or "(not set)",
        agent_version or "(not set)",
    )

    # Collision detection
    mandate_names = get_all_risk_guard_names(risk_class)
    dev_guard_names = {g.name for g in guards}
    collisions = dev_guard_names & mandate_names
    if collisions:
        from agentic_blueprint.exceptions import GovernanceError

        names = ", ".join(sorted(collisions))
        raise GovernanceError(
            f"Cannot override mandate guardrail(s): {names}. "
            f"Mandate guards are non-removable. To customise the block "
            f'message, use: wrap(..., block_responses={{"<GuardrailName>": '
            f'"your message"}}) instead of passing the guard in guards=[].',
        )

    # Build risk guards (mandate + risk-level), then append dev guards
    risk_guards = get_risk_guards(risk_class, block_responses=block_responses)
    all_guards: list[GovernanceGuard] = [*risk_guards, *guards]

    # Inject platform defaults (safety nets) where developer hasn't
    # provided their own.  Unlike mandates, defaults are replaceable —
    # if the developer passes their own MaxStepsPolicy / BudgetPolicy /
    # TimeoutPolicy in guards=[], it takes priority over the platform default.
    all_guard_names = {g.name for g in all_guards}
    defaults_injected = 0
    for default_guard in get_platform_defaults():
        if default_guard.name not in all_guard_names:
            all_guards.append(default_guard)
            defaults_injected += 1
        else:
            logger.info(
                "wrap(%s): developer provided %s — using their configuration",
                name or "agent", default_guard.name,
            )

    resolved_name = name or getattr(compiled_graph, "name", None) or "agent"

    logger.info(
        "wrap(%s): risk_class=%s, guards=%d (risk=%d + dev=%d + defaults=%d)",
        resolved_name, risk_class.value,
        len(all_guards), len(risk_guards), len(guards), defaults_injected,
    )

    # Auto-detect framework via registry
    adapter_name, adapter_cls = _detect_framework(compiled_graph)
    logger.info("wrap(%s): detected %s", resolved_name, adapter_name)

    return adapter_cls(
        compiled_graph,
        name=resolved_name,
        guards=all_guards,
        scoped_guards=scoped_guards,
        tags=tags,
        project_id=project_id,
        workflow_id=workflow_id,
        risk_class=risk_class,
        agent_id=agent_id,
        agent_version=agent_version,
        lifecycle=resolved_lifecycle.value,
    )


def guard(
    fn: Callable,
    *,
    name: str | None = None,
    guards: Sequence[GovernanceGuard] = (),
    tags: Sequence[str] = (),
    project_id: str | None = None,
    workflow_id: str | None = None,
) -> GovernedCallable:
    """Wrap any async callable with governance guards.

    Parameters
    ----------
    fn:
        An async or sync callable with signature ``(state, ...) -> result``.
    name:
        Name for tracing spans.  Defaults to ``fn.__name__``.
    guards:
        Guards that run before/after the callable.
    tags:
        Tags for Langfuse traces.

    Returns
    -------
    GovernedCallable
        An async callable with the same interface as *fn*.
    """
    resolved_name = name or getattr(fn, "__name__", "callable")

    return GovernedCallable(
        fn,
        name=resolved_name,
        guards=guards,
        tags=tags,
        project_id=project_id,
        workflow_id=workflow_id,
    )
