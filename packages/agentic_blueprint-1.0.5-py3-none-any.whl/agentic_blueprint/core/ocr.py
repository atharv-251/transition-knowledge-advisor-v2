"""OCRClient -- VW LLMaaS document OCR via ``/v1/ocr``.

Extract text from PDFs and images using ``mistral-document-ai-2505``.

The ``/v1/ocr`` endpoint is **not** part of the standard OpenAI API, so this
client uses ``httpx`` directly instead of the OpenAI SDK.

Quick start::

    from agentic_blueprint.core.ocr import get_ocr_client

    ocr = get_ocr_client()
    result = await ocr.aextract("/path/to/document.pdf")
    print(result)  # extracted text

Or use it as a tool inside an agent::

    from agentic_blueprint import tool
    from agentic_blueprint.core.ocr import get_ocr_client

    ocr = get_ocr_client()

    @tool
    async def extract_text(file_path: str) -> str:
        return await ocr.aextract(file_path)
"""

from __future__ import annotations

import asyncio
import base64
import logging
import mimetypes
from pathlib import Path
from typing import Any

import httpx

from agentic_blueprint._internal.token_manager import TokenManager
from agentic_blueprint.config.settings import LLMaaSSettings, get_settings
from agentic_blueprint.governance.project_registry import require_platform_init

logger = logging.getLogger(__name__)

DEFAULT_OCR_MODEL = "mistral-document-ai-2505"

# Supported input MIME types
_MIME_MAP: dict[str, str] = {
    ".pdf": "application/pdf",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
}


def get_ocr_client(
    model: str = DEFAULT_OCR_MODEL,
    *,
    llmaas_settings: LLMaaSSettings | None = None,
) -> "OCRClient":
    """Create an OCR client backed by VW LLMaaS.

    ::

        ocr = get_ocr_client()
        text = await ocr.aextract("/path/to/document.pdf")

    Raises:
        ConfigurationError: If ``init_blueprint()`` was not called.
    """
    require_platform_init()
    return OCRClient(model=model, llmaas_settings=llmaas_settings)


class OCRClient:
    """Extract text from documents and images via VW LLMaaS ``/v1/ocr``.

    Uses ``mistral-document-ai-2505``.  Supports PDF and image files (PNG, JPG)
    as base64-encoded input.
    """

    def __init__(
        self,
        model: str = DEFAULT_OCR_MODEL,
        *,
        llmaas_settings: LLMaaSSettings | None = None,
    ) -> None:
        self._settings = llmaas_settings or get_settings().llmaas
        self.model = model
        self._token_manager = TokenManager(self._settings)
        self._http: httpx.AsyncClient | None = None

    @property
    def _client(self) -> httpx.AsyncClient:
        if self._http is None or self._http.is_closed:
            self._http = httpx.AsyncClient(timeout=self._settings.timeout)
        return self._http

    async def _headers(self) -> dict[str, str]:
        """Build auth headers."""
        token = await self._token_manager.get_token()
        virtual_key = self._settings.api_key.get_secret_value()
        return {
            "Authorization": f"Bearer {token}",
            "X-LLM-API-CLIENT-ID": f"Bearer {virtual_key}",
            "Content-Type": "application/json",
        }

    async def aextract(
        self,
        source: str | Path | bytes,
        *,
        mime_type: str | None = None,
        include_image_base64: bool = False,
    ) -> dict[str, Any]:
        """Extract text from a document or image.

        Args:
            source: File path (str/Path) or raw bytes of the document.
            mime_type: MIME type override.  Auto-detected from file extension
                       when *source* is a path.
            include_image_base64: Whether to include base64 of detected images
                                  in the response.

        Returns:
            The raw JSON response from the OCR endpoint (contains pages,
            text blocks, and optionally image data).
        """
        # Read and encode the file
        if isinstance(source, (str, Path)):
            path = Path(source)
            if mime_type is None:
                ext = path.suffix.lower()
                mime_type = _MIME_MAP.get(ext)
                if mime_type is None:
                    mime_type = mimetypes.guess_type(str(path))[0] or "application/pdf"
            data_bytes = path.read_bytes()
        elif isinstance(source, bytes):
            data_bytes = source
            mime_type = mime_type or "application/pdf"
        else:
            raise TypeError(f"source must be str, Path, or bytes, got {type(source).__name__}")

        data_b64 = base64.b64encode(data_bytes).decode()
        document_url = f"data:{mime_type};base64,{data_b64}"

        headers = await self._headers()
        url = f"{self._settings.base_url.rstrip('/')}/v1/ocr"

        response = await self._client.post(
            url,
            headers=headers,
            json={
                "model": self.model,
                "document": {
                    "type": "document_url",
                    "document_url": document_url,
                },
                "include_image_base64": include_image_base64,
            },
        )
        response.raise_for_status()
        return response.json()

    async def aextract_text(
        self,
        source: str | Path | bytes,
        **kwargs: Any,
    ) -> str:
        """Extract and return only the plain text from a document.

        Convenience wrapper around :meth:`aextract` that concatenates all
        text content from the response.
        """
        result = await self.aextract(source, **kwargs)

        # Extract text from the OCR response pages
        pages = result.get("pages", [])
        text_parts: list[str] = []
        for page in pages:
            if isinstance(page, dict):
                text = page.get("markdown") or page.get("text", "")
                if text:
                    text_parts.append(text)

        return "\n\n".join(text_parts) if text_parts else str(result)

    def extract(self, source: str | Path | bytes, **kwargs: Any) -> dict[str, Any]:
        """Synchronous wrapper around :meth:`aextract`."""
        import contextvars

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if loop is not None:
            import concurrent.futures
            ctx = contextvars.copy_context()
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(ctx.run, asyncio.run, self.aextract(source, **kwargs)).result()
        return asyncio.run(self.aextract(source, **kwargs))

    async def close(self) -> None:
        """Release HTTP resources."""
        await self._token_manager.close()
        if self._http and not self._http.is_closed:
            await self._http.aclose()

    def __repr__(self) -> str:
        return f"OCRClient(model={self.model!r})"
