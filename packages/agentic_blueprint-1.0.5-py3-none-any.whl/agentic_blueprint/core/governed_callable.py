"""GovernedCallable — governance wrapper for standalone async callables.

Wraps any async (or sync) callable with the same guardrail/policy/audit
pipeline used by :class:`~agentic_blueprint.frameworks.langgraph.governed_graph.GovernedGraph`,
but without requiring a LangGraph graph.

Created by :func:`~agentic_blueprint.core.wrap.guard`.  Prefer using
``guard()`` rather than constructing ``GovernedCallable`` directly.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable, Sequence

from agentic_blueprint._internal.helpers import generate_id
from agentic_blueprint.config.settings import get_settings
from agentic_blueprint.core.governance_context import (
    GovernanceCtx,
    _get_governance_ctx,
    _set_governance_ctx,
)
from agentic_blueprint.core.langfuse_client import get_langfuse_client
from agentic_blueprint.core.pipeline import get_active_pipeline
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guards import GovernanceGuard, GuardsPipeline
from agentic_blueprint.governance.risk import RiskClass
from agentic_blueprint.governance.project_registry import (
    get_default_user_id,
    get_platform_project_id,
    require_platform_init,
)
from agentic_blueprint.observability.context import (
    get_current_trace_id,
    get_project_id,
    get_session_id,
    get_user_id,
    get_workflow_id,
    set_current_trace_id,
    set_project_id,
    set_session_id,
    set_user_id,
    set_workflow_id,
)

logger = logging.getLogger(__name__)

__all__ = ["GovernedCallable"]


class GovernedCallable:
    """A governed async callable.  Created by :func:`guard`."""

    def __init__(
        self,
        fn: Callable,
        *,
        name: str,
        guards: Sequence[GovernanceGuard] = (),
        tags: Sequence[str] = (),
        project_id: str | None = None,
        workflow_id: str | None = None,
    ) -> None:
        self._fn = fn
        self.name = name
        self.tags = list(tags)
        self._pipeline = GuardsPipeline(guards)

        settings = get_settings()
        self.project_id = (
            project_id or settings.project_id or get_platform_project_id()
        )
        self.workflow_id = workflow_id or settings.workflow_id or name
        self.last_governance_ctx: GovernanceCtx | None = None

    async def __call__(
        self,
        state: dict[str, Any],
        *args: Any,
        session_id: str | None = None,
        user_id: str | None = None,
        **kwargs: Any,
    ) -> Any:
        """Invoke the wrapped callable with governance."""
        require_platform_init()

        # Detect active pipeline context
        pipe_ctx = get_active_pipeline()
        is_pipeline_child = pipe_ctx is not None

        resolved_session = (
            session_id
            or (pipe_ctx.session_id if pipe_ctx else None)
            or get_session_id()
            or generate_id("sess-")
        )
        resolved_user = (
            user_id
            or (pipe_ctx.user_id if pipe_ctx else None)
            or get_user_id()
            or get_default_user_id()
        )
        resolved_project = self.project_id
        resolved_workflow = self.workflow_id

        lf = get_langfuse_client()
        trace_id = get_current_trace_id()
        is_nested = trace_id is not None

        if not is_nested:
            if is_pipeline_child:
                trace_id = pipe_ctx.trace_id
            else:
                trace_id = (
                    lf.create_trace_id() if lf else generate_id("tr-")
                )
            set_current_trace_id(trace_id)
            set_session_id(resolved_session)
            set_user_id(resolved_user)
            set_project_id(resolved_project)
            set_workflow_id(resolved_workflow)

        # Create or extend sidecar context
        gov_ctx = _get_governance_ctx()
        created_ctx = False
        if gov_ctx is None:
            gov_ctx = GovernanceCtx(
                trace_id=trace_id or "",
                session_id=resolved_session,
                user_id=resolved_user or "",
                project_id=resolved_project or "",
                workflow_id=resolved_workflow or "",
                agent_id=getattr(self, "agent_id", None) or "",
                agent_version=getattr(self, "agent_version", None) or "",
                input_state=state,
            )
            _set_governance_ctx(gov_ctx)
            created_ctx = True

        gov_ctx.node_history.append(self.name)

        exec_ctx = ExecutionContext(
            agent_name=self.name,
            node_name=self.name,
            trace_id=trace_id or "",
            session_id=resolved_session,
            user_id=resolved_user,
            workflow_id=resolved_workflow,
            project_id=resolved_project,
            risk_class=(
                getattr(self, "risk_class", RiskClass.MEDIUM).value
                if hasattr(self, "risk_class") else "medium"
            ),
            input_state=state,
            step_count=len(gov_ctx.node_history),
            node_step_count=gov_ctx.node_history.count(self.name),
            tags=self.tags,
        )

        # Pipeline-level graph CHAIN
        _pipe_chain_run_id = None
        if is_pipeline_child and pipe_ctx is not None:
            _pipe_chain_run_id = pipe_ctx._start_agent_chain(
                self.name, state,
            )

        try:
            if lf is not None and trace_id:
                with lf.start_as_current_span(
                    trace_context={"trace_id": trace_id},
                    name=self.name,
                    input=state,
                ) as span:
                    if not is_nested:
                        lf.update_current_trace(
                            name=self.name,
                            user_id=resolved_user,
                            session_id=resolved_session,
                            tags=list(self.tags or []),
                        )

                    exec_ctx = await self._pipeline.run_before(exec_ctx)

                    if asyncio.iscoroutinefunction(self._fn):
                        result = await self._fn(state, *args, **kwargs)
                    else:
                        result = self._fn(state, *args, **kwargs)

                    exec_ctx.output_state = result
                    await self._pipeline.run_after(exec_ctx)

                    try:
                        span.update(output=result)
                    except Exception:
                        logger.debug("tracing span update failed", exc_info=True)
            else:
                exec_ctx = await self._pipeline.run_before(exec_ctx)

                if asyncio.iscoroutinefunction(self._fn):
                    result = await self._fn(state, *args, **kwargs)
                else:
                    result = self._fn(state, *args, **kwargs)

                exec_ctx.output_state = result
                await self._pipeline.run_after(exec_ctx)

            return result

        except Exception as exc:
            exec_ctx.error = exc
            try:
                await self._pipeline.run_after(exec_ctx)
            except Exception:
                logger.warning("governance after-node callback failed during error handling", exc_info=True)
            raise
        finally:
            if created_ctx:
                self.last_governance_ctx = gov_ctx
                if is_pipeline_child and pipe_ctx is not None:
                    pipe_ctx.node_history.extend(gov_ctx.node_history)
                    pipe_ctx.agent_names.append(self.name)
                    pipe_ctx.sub_trace_ids.append(trace_id or "")
                    pipe_ctx._last_gov_ctx = gov_ctx
            if _pipe_chain_run_id is not None and pipe_ctx is not None:
                pipe_ctx._end_agent_chain(
                    _pipe_chain_run_id, self.name,
                )
            if not is_nested and not is_pipeline_child:
                if lf is not None:
                    try:
                        lf.flush()
                    except Exception:
                        logger.debug("Langfuse flush failed", exc_info=True)
                set_current_trace_id(None)
                set_session_id(None)
                set_user_id(None)
                set_project_id(None)
                set_workflow_id(None)
            if created_ctx:
                _set_governance_ctx(None)
