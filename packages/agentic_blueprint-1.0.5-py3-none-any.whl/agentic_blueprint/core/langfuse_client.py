"""Shared Langfuse client singleton.

Used by all governance wrappers (``GovernedGraph``, ``GovernedCrew``,
``GovernedCallable``) so the Langfuse client is created at most once
per process.

The client automatically attaches ``project_id`` and ``workflow_id``
as default metadata on every trace when those values are available
(set by ``init_blueprint()`` via ``LANGFUSE_PROJECT_ID`` /
``LANGFUSE_WORKFLOW_ID`` environment variables).
"""

from __future__ import annotations

import datetime as _dt
import logging
import os
from typing import Any

from langfuse import Langfuse as _Langfuse

try:
    from langfuse.api import TraceBody as _TraceBody
except ImportError:
    from langfuse.api.types import TraceBody as _TraceBody  # type: ignore[no-redef]

from agentic_blueprint.observability.tracing import is_langfuse_configured

logger = logging.getLogger(__name__)

__all__ = ["get_langfuse_client", "_fix_trace_name", "get_trace_metadata"]


# ---------------------------------------------------------------------------
# Langfuse client singleton
# ---------------------------------------------------------------------------

_langfuse_client: Any | None = None


def get_langfuse_client() -> Any | None:
    """Return a shared ``Langfuse()`` client, or ``None`` if tracing is off.

    This is the canonical singleton used by all governance wrappers
    (``GovernedGraph``, ``GovernedCrew``, ``GovernedCallable``).
    """
    global _langfuse_client  # noqa: PLW0603
    if not is_langfuse_configured():
        return None
    if _langfuse_client is not None:
        return _langfuse_client
    try:
        _langfuse_client = _Langfuse()
        return _langfuse_client
    except Exception:
        logger.debug("Failed to create Langfuse client", exc_info=True)
        return None


def _fix_trace_name(lf: Any, trace_id: str, name: str) -> None:
    """Override the trace name via a lightweight ingestion event."""
    try:
        body = _TraceBody(id=trace_id, name=name)
        event = {
            "id": lf.create_trace_id(),
            "type": "trace-create",
            "timestamp": _dt.datetime.now(_dt.timezone.utc).isoformat(),
            "body": body,
        }
        if hasattr(lf, "_resources") and lf._resources is not None:
            lf._resources.add_trace_task(event)
            lf.flush()
    except Exception:
        logger.debug("Failed to fix trace name via ingestion API", exc_info=True)


def get_trace_metadata() -> dict[str, str]:
    """Return a dict of project/workflow identity for Langfuse trace metadata.

    Reads the values set by ``init_blueprint()`` via environment variables.
    Governance wrappers should merge this dict into the ``metadata`` kwarg
    of every ``langfuse.trace()`` / ``langfuse.span()`` call so that every
    trace carries the correct project and workflow identity.

    Returns an empty dict when no identity is configured (e.g. tests).
    """
    meta: dict[str, str] = {}
    _pid = os.environ.get("LANGFUSE_PROJECT_ID") or os.environ.get(
        "AGENTIC_BLUEPRINT_PROJECT_ID", ""
    )
    _wid = os.environ.get("LANGFUSE_WORKFLOW_ID") or os.environ.get(
        "AGENTIC_BLUEPRINT_WORKFLOW_ID", ""
    )
    if _pid:
        meta["project_id"] = _pid
    if _wid:
        meta["workflow_id"] = _wid
    return meta
