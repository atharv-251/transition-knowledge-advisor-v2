"""ImageModel -- VW LLMaaS image generation via ``/v1/images/generations``.

Supports ``gpt-image-1`` and ``gpt-image-1-mini``.  Returns base64-encoded
images from text prompts.

Quick start::

    from agentic_blueprint.core.image import get_image_model

    image_model = get_image_model()
    result = await image_model.agenerate("A futuristic electric car in a neon-lit city")
    b64 = result.b64_json          # base64-encoded image data
    revised = result.revised_prompt # prompt that was actually used

Or use it as a tool inside an agent::

    from agentic_blueprint import tool
    from agentic_blueprint.core.image import get_image_model

    image_model = get_image_model()

    @tool
    async def generate_image(prompt: str) -> str:
        result = await image_model.agenerate(prompt)
        return result.b64_json
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any

from agentic_blueprint._internal.token_manager import TokenManager
from agentic_blueprint.config.settings import LLMaaSSettings, get_settings
from agentic_blueprint.governance.project_registry import require_platform_init

logger = logging.getLogger(__name__)

# Default models
DEFAULT_IMAGE_MODEL = "gpt-image-1"


@dataclass(frozen=True)
class ImageResult:
    """Result of an image generation request."""

    b64_json: str
    """Base64-encoded image data."""

    revised_prompt: str | None = None
    """The prompt the model actually used (may differ from input)."""


def get_image_model(
    model: str = DEFAULT_IMAGE_MODEL,
    *,
    llmaas_settings: LLMaaSSettings | None = None,
) -> "ImageModel":
    """Create an image generation client backed by VW LLMaaS.

    ::

        image_model = get_image_model()                   # gpt-image-1
        image_model = get_image_model("gpt-image-1-mini") # smaller/faster

    Raises:
        ConfigurationError: If ``init_blueprint()`` was not called.
    """
    require_platform_init()
    return ImageModel(model=model, llmaas_settings=llmaas_settings)


class ImageModel:
    """Generate images from text prompts via VW LLMaaS ``/v1/images/generations``.

    Uses ``gpt-image-1`` or ``gpt-image-1-mini``.  Responses are returned
    as base64-encoded images.
    """

    def __init__(
        self,
        model: str = DEFAULT_IMAGE_MODEL,
        *,
        llmaas_settings: LLMaaSSettings | None = None,
    ) -> None:
        self._settings = llmaas_settings or get_settings().llmaas
        self.model = model
        self._token_manager = TokenManager(self._settings)
        self._client: Any | None = None
        self._client_token: str | None = None
        self._lock = asyncio.Lock()

    async def _get_client(self) -> Any:
        """Return an ``AsyncOpenAI`` client with a valid token."""
        token = await self._token_manager.get_token()

        if self._client is not None and self._client_token == token:
            return self._client

        async with self._lock:
            if self._client is not None and self._client_token == token:
                return self._client

            if self._client is not None:
                try:
                    await self._client.close()
                except Exception:
                    logger.debug("error closing previous AsyncOpenAI client", exc_info=True)

            from openai import AsyncOpenAI

            virtual_key = self._settings.api_key.get_secret_value()

            self._client = AsyncOpenAI(
                api_key=token,
                base_url=self._settings.base_url,
                default_headers={
                    "X-LLM-API-CLIENT-ID": f"Bearer {virtual_key}",
                },
                timeout=self._settings.timeout,
                max_retries=self._settings.max_retries,
            )
            self._client_token = token
            return self._client

    async def agenerate(
        self,
        prompt: str,
        *,
        size: str = "1024x1024",
        n: int = 1,
        **kwargs: Any,
    ) -> ImageResult:
        """Generate an image from a text prompt.

        Args:
            prompt: Text description of the desired image.
            size: Image dimensions (``"1024x1024"``, ``"1792x1024"``, ``"1024x1792"``).
            n: Number of images to generate (currently only 1 is supported).
            **kwargs: Additional parameters passed to ``images.generate()``.

        Returns:
            :class:`ImageResult` containing base64-encoded image data.
        """
        client = await self._get_client()

        response = await client.images.generate(
            model=self.model,
            prompt=prompt,
            size=size,
            n=n,
            **kwargs,
        )

        image_data = response.data[0]
        return ImageResult(
            b64_json=image_data.b64_json or "",
            revised_prompt=getattr(image_data, "revised_prompt", None),
        )

    def generate(self, prompt: str, **kwargs: Any) -> ImageResult:
        """Synchronous wrapper around :meth:`agenerate`."""
        import contextvars

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if loop is not None:
            import concurrent.futures
            ctx = contextvars.copy_context()
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                result = pool.submit(ctx.run, asyncio.run, self.agenerate(prompt, **kwargs)).result()
            # Invalidate shared client created on the temporary event loop
            # to prevent "Event loop is closed" errors on subsequent async calls
            self._client = None
            self._client_token = None
            return result
        return asyncio.run(self.agenerate(prompt, **kwargs))

    async def close(self) -> None:
        """Release HTTP resources."""
        await self._token_manager.close()
        if self._client is not None:
            try:
                await self._client.close()
            except Exception:
                logger.debug("error closing AsyncOpenAI client in ImageModel", exc_info=True)
            self._client = None

    def __repr__(self) -> str:
        return f"ImageModel(model={self.model!r})"
