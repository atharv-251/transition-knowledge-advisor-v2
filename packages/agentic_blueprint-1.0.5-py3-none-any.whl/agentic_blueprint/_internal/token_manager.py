"""OAuth token lifecycle manager for VW LLMaaS.

Handles client-credentials flow against VW Cloud IDP, automatic refresh
before expiry, and thread/async-safe token access.

Resilience: ``_refresh()`` retries transient IDP failures (connect errors,
timeouts, 5xx) up to 3 times with exponential backoff.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field

import httpx
from tenacity import (
    retry,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential,
)

from agentic_blueprint._internal.resilience import is_transient_error
from agentic_blueprint.config.settings import LLMaaSSettings
from agentic_blueprint.exceptions import AuthenticationError

logger = logging.getLogger(__name__)


@dataclass
class _TokenState:
    access_token: str = ""
    expires_at: float = 0.0  # epoch seconds


class TokenManager:
    """Async-safe OAuth token manager with automatic refresh."""

    def __init__(self, settings: LLMaaSSettings) -> None:
        self._settings = settings
        self._state = _TokenState()
        self._lock = asyncio.Lock()
        self._http: httpx.AsyncClient | None = None

    @property
    def _client(self) -> httpx.AsyncClient:
        if self._http is None or self._http.is_closed:
            self._http = httpx.AsyncClient(timeout=30)
        return self._http

    def _is_expired(self) -> bool:
        return time.time() >= (
            self._state.expires_at - self._settings.token_refresh_buffer
        )

    async def get_token(self) -> str:
        """Return a valid access token, refreshing if needed."""
        if not self._is_expired() and self._state.access_token:
            return self._state.access_token

        async with self._lock:
            # Double-check after acquiring the lock
            if not self._is_expired() and self._state.access_token:
                return self._state.access_token
            return await self._refresh()

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, max=5),
        retry=retry_if_exception(is_transient_error),
        reraise=True,
    )
    async def _refresh(self) -> str:
        """Fetch a new token from VW Cloud IDP."""
        client_secret = self._settings.client_secret.get_secret_value()
        if not self._settings.client_id or not client_secret:
            raise AuthenticationError(
                "LLMAAS_CLIENT_ID and LLMAAS_CLIENT_SECRET must be set"
            )

        try:
            response = await self._client.post(
                self._settings.idp_url,
                data={
                    "grant_type": "client_credentials",
                    "client_id": self._settings.client_id,
                    "client_secret": client_secret,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise AuthenticationError(
                f"Failed to obtain OAuth token from IDP: {exc}"
            ) from exc

        data = response.json()
        access_token: str = data["access_token"]
        expires_in: int = data.get("expires_in", 1800)

        self._state = _TokenState(
            access_token=access_token,
            expires_at=time.time() + expires_in,
        )
        logger.debug(
            "OAuth token refreshed, expires in %d seconds", expires_in
        )
        return access_token

    async def close(self) -> None:
        if self._http and not self._http.is_closed:
            await self._http.aclose()
