"""Shared internal helpers."""

from __future__ import annotations

import uuid
from typing import Any


def generate_id(prefix: str = "") -> str:
    """Generate a short unique ID, optionally prefixed."""
    short = uuid.uuid4().hex[:12]
    return f"{prefix}{short}" if prefix else short


def extract_last_message(result: dict[str, Any] | Any) -> str:
    """Extract the last assistant content from a graph result.

    Eliminates the boilerplate pattern repeated across all examples::

        msgs = result.get("messages", [])
        last = msgs[-1]
        content = last.content if hasattr(last, "content") else str(last)

    Lookup order:

    1. ``result["response"]`` (direct response key)
    2. ``result["answer"]``   (wikipedia/research agents)
    3. ``result["output"]``   (generic output key)
    4. Last message in ``result["messages"]`` with ``role="assistant"``
    5. Empty string if nothing found.

    Works with LangChain ``AIMessage`` objects, plain dicts, and
    the SDK's ``ChatModel`` response format.

    Parameters
    ----------
    result : dict
        The result dict from ``governed.ainvoke()`` or a raw graph invocation.

    Returns
    -------
    str
        The extracted text content, or ``""`` if nothing was found.
    """
    if not isinstance(result, dict):
        return str(result) if result else ""

    # Direct keys
    for key in ("response", "answer", "output"):
        val = result.get(key)
        if val and isinstance(val, str):
            return val

    # Messages list
    messages = result.get("messages")
    if not messages or not isinstance(messages, list):
        return ""

    for msg in reversed(messages):
        # LangChain AIMessage
        content = getattr(msg, "content", None)
        role = getattr(msg, "role", None) or getattr(msg, "type", None)
        if content is None and isinstance(msg, dict):
            content = msg.get("content")
            role = msg.get("role")
        if content and isinstance(content, str) and role in (
            "assistant", "ai", "AIMessage",
        ):
            return content

    # Fallback: any last message with content
    last = messages[-1]
    content = getattr(last, "content", None)
    if content is None and isinstance(last, dict):
        content = last.get("content")
    return content if isinstance(content, str) else str(last)
