"""Resilience primitives -- circuit breaker and retry helpers.

Circuit breaker
---------------
Prevents cascading failures by temporarily blocking calls to unhealthy
services.  Three states:

  CLOSED   -- traffic flows normally; failures are counted.
  OPEN     -- all calls are immediately rejected; a recovery timer runs.
  HALF_OPEN -- a single probe call is allowed; success resets, failure re-opens.

Usage::

    from agentic_blueprint._internal.resilience import CircuitBreaker

    cb = CircuitBreaker(failure_threshold=5, recovery_timeout=30.0)

    # Before making a call:
    cb.check()          # raises CircuitOpenError if OPEN

    # After a call:
    cb.record_success()
    # or
    cb.record_failure()

The circuit breaker is thread-safe via a threading lock.

Retry
-----
``retry_async()`` provides a lightweight async retry with exponential backoff
for transient errors (connect timeouts, 429s, 502/503/504).  Uses ``tenacity``
which is already a project dependency.
"""

from __future__ import annotations

import logging
import threading
import time
from enum import Enum
from typing import Collection

from agentic_blueprint.exceptions import AgenticBlueprintPlatformError

logger = logging.getLogger(__name__)


class CircuitState(Enum):
    CLOSED = "CLOSED"
    OPEN = "OPEN"
    HALF_OPEN = "HALF_OPEN"


class CircuitOpenError(AgenticBlueprintPlatformError):
    """Raised when a call is attempted while the circuit is OPEN."""

    def __init__(self, name: str, remaining_seconds: float) -> None:
        self.name = name
        self.remaining_seconds = remaining_seconds
        super().__init__(
            f"Circuit breaker '{name}' is OPEN. "
            f"Retry after {remaining_seconds:.0f}s."
        )


class CircuitBreaker:
    """Simple thread-safe circuit breaker.

    Parameters
    ----------
    name:
        Identifier for logging (e.g. ``"llmaas"`` or ``"idp"``).
    failure_threshold:
        Number of consecutive failures before opening the circuit.
    recovery_timeout:
        Seconds to wait in OPEN state before allowing a probe.
    """

    def __init__(
        self,
        name: str = "default",
        failure_threshold: int = 5,
        recovery_timeout: float = 30.0,
    ) -> None:
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout

        self._state = CircuitState.CLOSED
        self._failures = 0
        self._last_failure_time: float = 0.0
        self._lock = threading.Lock()

    @property
    def state(self) -> CircuitState:
        with self._lock:
            if self._state == CircuitState.OPEN:
                if time.monotonic() - self._last_failure_time >= self.recovery_timeout:
                    self._state = CircuitState.HALF_OPEN
                    logger.info(
                        "Circuit breaker '%s' transitioning OPEN -> HALF_OPEN",
                        self.name,
                    )
            return self._state

    def check(self) -> None:
        """Raise ``CircuitOpenError`` if the circuit is OPEN."""
        current = self.state
        if current == CircuitState.OPEN:
            remaining = self.recovery_timeout - (
                time.monotonic() - self._last_failure_time
            )
            raise CircuitOpenError(self.name, max(0, remaining))

    def record_success(self) -> None:
        """Record a successful call -- resets the circuit to CLOSED."""
        with self._lock:
            if self._state in (CircuitState.HALF_OPEN, CircuitState.CLOSED):
                if self._failures > 0:
                    logger.info(
                        "Circuit breaker '%s' -> CLOSED (success after %d failures)",
                        self.name, self._failures,
                    )
                self._failures = 0
                self._state = CircuitState.CLOSED

    def record_failure(self) -> None:
        """Record a failed call -- may trip the circuit to OPEN."""
        with self._lock:
            self._failures += 1
            self._last_failure_time = time.monotonic()

            if self._state == CircuitState.HALF_OPEN:
                self._state = CircuitState.OPEN
                logger.warning(
                    "Circuit breaker '%s' -> OPEN (probe failed)",
                    self.name,
                )
            elif self._failures >= self.failure_threshold:
                self._state = CircuitState.OPEN
                logger.warning(
                    "Circuit breaker '%s' -> OPEN (threshold=%d reached)",
                    self.name, self.failure_threshold,
                )

    def reset(self) -> None:
        """Force-reset to CLOSED (for testing)."""
        with self._lock:
            self._state = CircuitState.CLOSED
            self._failures = 0
            self._last_failure_time = 0.0


# ---------------------------------------------------------------------------
# Retry helpers
# ---------------------------------------------------------------------------

#: HTTP status codes considered transient / retriable.
TRANSIENT_STATUS_CODES: frozenset[int] = frozenset({408, 429, 500, 502, 503, 504})


def is_transient_error(exc: BaseException) -> bool:
    """Return True if *exc* looks like a transient network/server error."""
    import httpx

    if isinstance(exc, (httpx.ConnectError, httpx.ReadTimeout, httpx.WriteTimeout, TimeoutError)):
        return True
    if isinstance(exc, httpx.HTTPStatusError):
        return exc.response.status_code in TRANSIENT_STATUS_CODES
    # OpenAI SDK wraps HTTP errors
    if hasattr(exc, "status_code"):
        return getattr(exc, "status_code", 0) in TRANSIENT_STATUS_CODES
    return False
