"""MCPToolkit -- connect to an MCP server and use its tools in Agentic Blueprint agents.

Supports two transport modes:

- **Streamable HTTP** (``server_url``): for remote MCP servers / VW registry
- **stdio** (``command`` + ``args``): for local dev / testing

Guideline compliance
--------------------
* Execution context binding  – every session carries a ``trace_id`` and a
  unique ``execution_id`` that are propagated to every tool call and error.
* Inbound / outbound size guards  – ``max_inbound_bytes`` /
  ``max_outbound_bytes`` (default 1 MB each) enforce transport-level limits.
* Per-session rate limiting  – ``max_calls_per_session`` (default 500) caps
  the total number of tool calls before the session must be recycled.
* Bounded retries  – ``max_retries`` (default 3) with exponential backoff;
  retries are only attempted for errors whose ``retriable`` flag is ``True``.
* Version metadata  – protocol, server and tool version information is
  attached to every error and log event.
* Session lifecycle guards  – the toolkit refuses to dispatch tool calls
  before ``initialize`` has completed (``_initialized`` flag).
* Discovery cache  – tool list is cached immutably for the session lifetime.

Usage::

    from agentic_blueprint.mcp import MCPToolkit

    # Remote (VW MCP registry)
    async with MCPToolkit(
        server_url="https://mcp-registry.vw.com",
        wrap_parameters=True,
    ) as toolkit:
        tools = toolkit.as_tools()
        llm_with_tools = llm.bind_tools(tools)

    # Local (stdio)
    async with MCPToolkit(
        command="python", args=["my_server.py"],
    ) as toolkit:
        tools = toolkit.as_tools()
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from typing import Any

from langchain_core.tools import BaseTool

from agentic_blueprint.mcp.errors import (
    MCPConnectionError,
    MCPProtocolError,
    MCPRateLimitError,
    MCPSizeLimitError,
    MCPSystemError,
    MCPToolCallError,
    is_retriable,
)
from agentic_blueprint.mcp.tool_adapter import MCPTool, _schema_to_pydantic
from agentic_blueprint.observability.context import get_current_trace_id

logger = logging.getLogger(__name__)

# The MCP SDK's streamable-HTTP client logs noisy tracebacks for every
# non-JSON-RPC SSE event (e.g. VW registry progress messages).  These are
# harmless -- suppress them so they don't clutter application output.
logging.getLogger("mcp.client.streamable_http").setLevel(logging.CRITICAL)

# ---------------------------------------------------------------------------
# Transport-level size defaults (bytes).  Set to 0 to disable.
# ---------------------------------------------------------------------------
_DEFAULT_MAX_INBOUND_BYTES = 1 * 1024 * 1024   # 1 MB
_DEFAULT_MAX_OUTBOUND_BYTES = 1 * 1024 * 1024  # 1 MB

# Retry defaults
_DEFAULT_MAX_RETRIES = 3
_BACKOFF_BASE_SECONDS = 0.5  # initial wait; doubles on each retry


class MCPToolkit:
    """Connect to an MCP server and expose its tools as LangChain tools.

    Parameters
    ----------
    server_url:
        URL for Streamable HTTP transport (e.g. ``https://mcp.vw.com``).
        The SDK appends ``/mcp`` if not already present.
    command:
        Executable for stdio transport (e.g. ``"python"``, ``"npx"``).
    args:
        Arguments for the stdio command (e.g. ``["my_server.py"]``).
    env:
        Extra environment variables for the stdio process.
    headers:
        Extra HTTP headers (e.g. ``{"Authorization": "Bearer ..."}``)
        for Streamable HTTP transport.
    timeout:
        Timeout in seconds for individual MCP operations.
    wrap_parameters:
        If ``True``, tool arguments are wrapped in ``{"parameters": {...}}``
        before sending to the MCP server.  Required for VW MCP registry.
    max_inbound_bytes:
        Maximum permitted size (bytes) for inbound messages.
        Requests exceeding this are rejected with ``MCPSizeLimitError``.
        Set to ``0`` to disable.
    max_outbound_bytes:
        Maximum permitted size (bytes) for outbound (response) messages.
        Set to ``0`` to disable.
    max_calls_per_session:
        Hard cap on total tool calls within a single session.
        Exceeding this raises ``MCPRateLimitError``.  Set to ``0`` to disable.
    max_retries:
        Maximum number of retry attempts for retriable errors.
        Must be ≥ 0.  Set to ``0`` to disable retries.
    server_version:
        Declared server SemVer (e.g. ``"1.4.2"``), attached to errors/logs.
    protocol_version:
        MCP protocol version date string (e.g. ``"2024-11-05"``).
    """

    def __init__(
        self,
        server_url: str | None = None,
        *,
        command: str | None = None,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
        wrap_parameters: bool = False,
        max_inbound_bytes: int = _DEFAULT_MAX_INBOUND_BYTES,
        max_outbound_bytes: int = _DEFAULT_MAX_OUTBOUND_BYTES,
        max_calls_per_session: int = 500,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        server_version: str = "unknown",
        protocol_version: str = "2024-11-05",
    ) -> None:
        if not server_url and not command:
            raise ValueError("Provide either server_url (HTTP) or command (stdio)")

        self._server_url = server_url
        self._command = command
        self._args = args or []
        self._env = env
        self._headers = headers or {}
        self._timeout = timeout
        self._wrap_parameters = wrap_parameters
        self._max_inbound_bytes = max_inbound_bytes
        self._max_outbound_bytes = max_outbound_bytes
        self._max_calls_per_session = max_calls_per_session
        self._max_retries = max_retries
        self._server_version = server_version
        self._protocol_version = protocol_version

        # Execution context – bound once per session
        self._session_id: str = str(uuid.uuid4())
        self._trace_id: str | None = None  # resolved at connect() time

        # Set after connect()
        self._session: Any = None
        self._transport_cm: Any = None
        self._session_cm: Any = None
        self._tools: list[MCPTool] = []

        # Session state guards
        self._initialized: bool = False
        self._call_count: int = 0

    # -- Version metadata helper -------------------------------------------

    def _version_meta(self, tool_version: str = "unknown") -> dict[str, str]:
        return {
            "protocol": self._protocol_version,
            "server": self._server_version,
            "tool": tool_version,
        }

    # -- Identity header injection -----------------------------------------

    def _inject_identity_headers(self) -> None:
        """Auto-inject agent identity headers for MCP HTTP transport.

        Injects ``X-Agent-Id``, ``X-Agent-Version``, ``X-Trace-Id``,
        ``X-User-Id``, and ``X-Session-Id`` from the active governance
        context.  Developer-supplied headers always take precedence.
        """
        from agentic_blueprint.observability.context import (
            get_user_id,
            get_project_id,
            get_session_id,
        )
        from agentic_blueprint.core.governance_context import governance_context

        # Try to get agent_id from the active GovernanceCtx
        try:
            gov_ctx = governance_context()
        except RuntimeError:
            gov_ctx = None

        identity_headers: dict[str, str] = {}

        if self._trace_id:
            identity_headers["X-Trace-Id"] = self._trace_id
        identity_headers["X-Session-Id"] = self._session_id

        user_id = get_user_id()
        if user_id:
            identity_headers["X-User-Id"] = user_id

        project_id = get_project_id()
        if project_id:
            identity_headers["X-Project-Id"] = project_id

        # Agent identity from governance context metadata
        if gov_ctx is not None:
            for attr, header in [
                ("agent_id", "X-Agent-Id"),
                ("agent_version", "X-Agent-Version"),
            ]:
                val = getattr(gov_ctx, attr, None)
                if val:
                    identity_headers[header] = val

        # Developer-supplied headers always win
        for key, val in identity_headers.items():
            self._headers.setdefault(key, val)

        injected = {k: v for k, v in identity_headers.items() if self._headers.get(k) == v}
        if injected:
            logger.debug("MCP identity headers injected: %s", list(injected.keys()))

    # -- Connection -----------------------------------------------

    async def connect(self) -> None:
        """Open transport, initialize MCP session, discover tools."""
        # Bind execution context – prefer contextvar trace propagated from caller
        self._trace_id = get_current_trace_id() or str(uuid.uuid4())

        # Auto-inject agent identity headers for HTTP transport.
        # These allow the MCP registry / gateway to identify and
        # authorise the calling agent without developer boilerplate.
        if self._server_url:
            self._inject_identity_headers()

        try:
            from mcp import ClientSession
        except ImportError:
            raise ImportError(
                "MCP support requires the 'mcp' package. "
                "Install it with: pip install 'agentic_blueprint[mcp]'"
            ) from None

        if self._server_url:
            await self._connect_http(ClientSession)
        else:
            await self._connect_stdio(ClientSession)

        # Guard: session MUST be initialized before tool dispatch
        if not self._initialized:
            raise MCPProtocolError(
                "MCP session failed to complete initialization handshake",
                trace_id=self._trace_id,
                version_metadata=self._version_meta(),
            )

        # Discover tools – cache immutably for session lifetime
        import re
        result = await self._session.list_tools()
        self._tools = []
        for t in result.tools:
            schema = t.inputSchema if hasattr(t, "inputSchema") else {}
            args_model = _schema_to_pydantic(
                t.name,
                schema,
                description=t.description or "",
                unwrap_parameters=self._wrap_parameters,
            )
            # Sanitise the tool name for API compatibility
            # (OpenAI requires ^[a-zA-Z0-9_.-]+$).
            safe_name = re.sub(r"[^a-zA-Z0-9_\-]", "_", t.name)
            mcp_tool = MCPTool(
                name=safe_name,
                description=t.description or t.name,
                args_schema=args_model,
            )
            mcp_tool._mcp_name = t.name
            mcp_tool.set_session(
                self._session,
                wrap_parameters=self._wrap_parameters,
                trace_id=self._trace_id,
                session_id=self._session_id,
                max_inbound_bytes=self._max_inbound_bytes,
                max_outbound_bytes=self._max_outbound_bytes,
                version_metadata=self._version_meta(),
            )
            self._tools.append(mcp_tool)

        logger.info(
            "MCP connected: server=%s session_id=%s trace_id=%s tools=%d (%s) "
            "protocol=%s server_version=%s",
            self._server_url or self._command,
            self._session_id,
            self._trace_id,
            len(self._tools),
            [t.name for t in self._tools],
            self._protocol_version,
            self._server_version,
        )

    async def _connect_http(self, session_cls: type) -> None:
        """Connect via Streamable HTTP transport."""
        try:
            from mcp.client.streamable_http import streamablehttp_client
        except ImportError:
            raise MCPConnectionError(
                self._server_url or "",
                "streamablehttp_client not available in installed mcp version",
                trace_id=self._trace_id,
                version_metadata=self._version_meta(),
            ) from None

        url = self._server_url or ""
        if not url.endswith("/mcp"):
            url = url.rstrip("/") + "/mcp"

        try:
            self._transport_cm = streamablehttp_client(
                url=url,
                headers=self._headers,
                timeout=self._timeout,
            )
            transport = await self._transport_cm.__aenter__()
            read_stream, write_stream = transport[0], transport[1]

            self._session_cm = session_cls(read_stream, write_stream)
            self._session = await self._session_cm.__aenter__()
            await self._session.initialize()
            self._initialized = True
        except MCPConnectionError:
            await self._cleanup()
            raise
        except BaseException as exc:
            await self._cleanup()
            # Extract the root cause from anyio ExceptionGroups
            cause = exc
            if isinstance(exc, BaseExceptionGroup):
                for sub in exc.exceptions:
                    if isinstance(sub, (ConnectionError, OSError)):
                        cause = sub
                        break
            raise MCPConnectionError(
                url,
                f"Failed to connect to MCP server at {url}: {cause}",
                trace_id=self._trace_id,
                version_metadata=self._version_meta(),
            ) from cause

    async def _connect_stdio(self, session_cls: type) -> None:
        """Connect via stdio transport (local dev)."""
        try:
            from mcp.client.stdio import stdio_client, StdioServerParameters
        except ImportError:
            raise MCPConnectionError(
                self._command or "",
                "stdio_client not available in installed mcp version",
                trace_id=self._trace_id,
                version_metadata=self._version_meta(),
            ) from None

        try:
            server_params = StdioServerParameters(
                command=self._command or "",
                args=self._args,
                env=self._env,
            )
            self._transport_cm = stdio_client(server_params)
            transport = await self._transport_cm.__aenter__()
            read_stream, write_stream = transport[0], transport[1]

            self._session_cm = session_cls(read_stream, write_stream)
            self._session = await self._session_cm.__aenter__()
            await self._session.initialize()
            self._initialized = True
        except MCPConnectionError:
            await self._cleanup()
            raise
        except Exception as exc:
            await self._cleanup()
            raise MCPConnectionError(
                self._command or "",
                str(exc),
                trace_id=self._trace_id,
                version_metadata=self._version_meta(),
            ) from exc

    # -- Retry wrapper ------------------------------------------------

    async def call_tool_with_retry(
        self,
        tool: MCPTool,
        kwargs: dict[str, Any],
    ) -> str:
        """Invoke *tool* with bounded retries for retriable errors only.

        - Non-retriable errors (VALIDATION, AUTH, etc.) are raised immediately.
        - Retriable errors (SYSTEM_ERROR) are retried up to ``max_retries``
          times with exponential backoff.
        - Unbounded or implicit retries are explicitly forbidden.
        """
        if not self._initialized:
            raise MCPProtocolError(
                "Cannot call tools before session initialization",
                trace_id=self._trace_id,
                version_metadata=self._version_meta(),
            )

        # Per-session rate limit guard (applied before execution)
        if self._max_calls_per_session and self._call_count >= self._max_calls_per_session:
            logger.warning(
                "MCP session rate limit reached: session_id=%s count=%d limit=%d "
                "trace_id=%s event=RATE_LIMIT_EXCEEDED",
                self._session_id, self._call_count,
                self._max_calls_per_session, self._trace_id,
            )
            raise MCPRateLimitError(
                "Session call limit reached",
                trace_id=self._trace_id,
                hint=f"Limit is {self._max_calls_per_session} calls per session.",
                version_metadata=self._version_meta(),
            )

        last_exc: Exception | None = None
        for attempt in range(self._max_retries + 1):
            try:
                self._call_count += 1
                return await tool._arun(**kwargs)
            except MCPToolCallError as exc:
                last_exc = exc
                if not is_retriable(exc) or attempt >= self._max_retries:
                    raise
                wait = _BACKOFF_BASE_SECONDS * (2 ** attempt)
                logger.warning(
                    "MCP tool %s failed (attempt %d/%d), retrying in %.1fs: %s "
                    "trace_id=%s event=RETRY",
                    tool.name, attempt + 1, self._max_retries + 1,
                    wait, exc.safe_message, self._trace_id,
                )
                await asyncio.sleep(wait)
            except Exception as exc:
                # Non-MCPToolCallError exceptions are never retried
                raise

        # Should never reach here, but satisfy type checker
        raise last_exc  # type: ignore[misc]

    # -- Tool access ----------------------------------------------

    def as_tools(self) -> list[BaseTool]:
        """Return all discovered MCP tools as LangChain-compatible tools.

        The list is the cached discovery result and is immutable per session.
        """
        if not self._initialized:
            raise MCPProtocolError(
                "Cannot list tools before session initialization",
                trace_id=self._trace_id,
                version_metadata=self._version_meta(),
            )
        return list(self._tools)

    def get_tool(self, name: str) -> BaseTool:
        """Get a single tool by name.

        Raises ``MCPNotFoundError`` if not found.
        """
        from agentic_blueprint.mcp.errors import MCPNotFoundError

        for t in self._tools:
            if t.name == name:
                return t
        available = [t.name for t in self._tools]
        raise MCPNotFoundError(
            f"tool '{name}' (available: {available})",
            trace_id=self._trace_id,
            hint=f"Available tools: {', '.join(available)}",
            version_metadata=self._version_meta(),
        )

    @property
    def tool_names(self) -> list[str]:
        """Names of all discovered tools."""
        return [t.name for t in self._tools]

    @property
    def session_id(self) -> str:
        """Unique identifier for this MCP session."""
        return self._session_id

    @property
    def trace_id(self) -> str | None:
        """Propagated trace correlation identifier."""
        return self._trace_id

    # -- Lifecycle ------------------------------------------------

    async def close(self) -> None:
        """Shut down the MCP session and transport."""
        logger.info(
            "MCP session closing: session_id=%s trace_id=%s total_calls=%d",
            self._session_id, self._trace_id, self._call_count,
        )
        await self._cleanup()

    async def _cleanup(self) -> None:
        """Best-effort cleanup of session and transport context managers."""
        self._initialized = False

        if self._session_cm:
            try:
                await self._session_cm.__aexit__(None, None, None)
            except Exception:
                pass
            self._session_cm = None
            self._session = None

        if self._transport_cm:
            try:
                await self._transport_cm.__aexit__(None, None, None)
            except Exception:
                pass
            self._transport_cm = None

        self._tools = []

    async def __aenter__(self) -> MCPToolkit:
        await self.connect()
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()
