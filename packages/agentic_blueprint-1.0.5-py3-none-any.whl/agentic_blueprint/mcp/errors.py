"""MCP-specific exceptions conforming to the VW MCP Guideline error model.

Error envelope
--------------
Every ``MCPError`` subclass carries a structured envelope with:

  error.code     – stable, machine-readable identifier
  error.type     – canonical error category (closed set defined below)
  error.message  – short (≤200 bytes), deterministic, no user-input echo
  error.trace_id – propagated correlation identifier

Canonical error types (MUST be exhaustive; tools MUST NOT add new ones):

  VALIDATION_ERROR
  AUTHENTICATION_ERROR
  AUTHORIZATION_ERROR
  NOT_FOUND_ERROR
  CONFLICT_ERROR
  RATE_LIMIT_ERROR
  SYSTEM_ERROR

Retry semantics (per guideline):
  - VALIDATION_ERROR, AUTHENTICATION_ERROR, AUTHORIZATION_ERROR  → non-retriable
  - CONFLICT_ERROR, RATE_LIMIT_ERROR                             → non-retriable
  - SYSTEM_ERROR                                                 → retriable (MAY)
  - NOT_FOUND_ERROR                                              → non-retriable

Hierarchy::

    AgenticBlueprintPlatformError
    +-- MCPError                          (base; carries error envelope)
        +-- MCPValidationError            (VALIDATION_ERROR)
        +-- MCPAuthenticationError        (AUTHENTICATION_ERROR)
        +-- MCPAuthorizationError         (AUTHORIZATION_ERROR)
        +-- MCPNotFoundError              (NOT_FOUND_ERROR)
        +-- MCPConflictError              (CONFLICT_ERROR)
        +-- MCPRateLimitError             (RATE_LIMIT_ERROR)
        +-- MCPSystemError                (SYSTEM_ERROR – retriable)
        +-- MCPConnectionError            (SYSTEM_ERROR, connection variant)
        +-- MCPToolCallError              (SYSTEM_ERROR, tool-call variant)
        +-- MCPProtocolError              (SYSTEM_ERROR, protocol-level variant)
        +-- MCPSizeLimitError             (VALIDATION_ERROR, size variant)
        +-- MCPTenantError                (AUTHORIZATION_ERROR, tenant variant)
"""

from __future__ import annotations

from typing import Any

from agentic_blueprint.exceptions import AgenticBlueprintPlatformError

# ---------------------------------------------------------------------------
# Canonical error types (closed set – MUST NOT be extended by tools)
# ---------------------------------------------------------------------------

VALIDATION_ERROR = "VALIDATION_ERROR"
AUTHENTICATION_ERROR = "AUTHENTICATION_ERROR"
AUTHORIZATION_ERROR = "AUTHORIZATION_ERROR"
NOT_FOUND_ERROR = "NOT_FOUND_ERROR"
CONFLICT_ERROR = "CONFLICT_ERROR"
RATE_LIMIT_ERROR = "RATE_LIMIT_ERROR"
SYSTEM_ERROR = "SYSTEM_ERROR"

_CANONICAL_TYPES = frozenset(
    {
        VALIDATION_ERROR,
        AUTHENTICATION_ERROR,
        AUTHORIZATION_ERROR,
        NOT_FOUND_ERROR,
        CONFLICT_ERROR,
        RATE_LIMIT_ERROR,
        SYSTEM_ERROR,
    }
)

# Retry semantics map: error_type → is_retriable
_RETRY_SEMANTICS: dict[str, bool] = {
    VALIDATION_ERROR: False,
    AUTHENTICATION_ERROR: False,
    AUTHORIZATION_ERROR: False,
    NOT_FOUND_ERROR: False,
    CONFLICT_ERROR: False,
    RATE_LIMIT_ERROR: False,
    SYSTEM_ERROR: True,
}

_MAX_MESSAGE_BYTES = 200  # guideline: error messages MUST be ≤ 200 bytes


def _truncate_message(msg: str) -> str:
    """Ensure the error message stays within the 200-byte guideline limit."""
    encoded = msg.encode("utf-8")
    if len(encoded) <= _MAX_MESSAGE_BYTES:
        return msg
    return encoded[:_MAX_MESSAGE_BYTES].decode("utf-8", errors="ignore").rstrip() + "…"


# ---------------------------------------------------------------------------
# Base MCP error with structured envelope
# ---------------------------------------------------------------------------


class MCPError(AgenticBlueprintPlatformError):
    """Base exception for all MCP-related errors.

    Every subclass exposes a structured ``envelope`` dict compatible with
    the VW MCP error model::

        {
            "error": {
                "code":     "MCP_SYSTEM_ERROR",
                "type":     "SYSTEM_ERROR",
                "message":  "MCP connection failed for 'https://...'",
                "trace_id": "trace-abc123",
                "retriable": true,
            }
        }

    Parameters
    ----------
    message:
        Short, deterministic, human-readable description.
        MUST NOT echo user input; MUST be ≤ 200 bytes.
    code:
        Stable machine-readable identifier (e.g. ``"MCP_CONNECTION_ERROR"``).
    error_type:
        One of the canonical error types defined in this module.
    trace_id:
        Propagated correlation identifier from the calling context.
    hint:
        Optional LLM-friendly, action-oriented correction hint.
        MUST be concise, MUST NOT include user input or internal details.
    retriable:
        Whether the caller MAY safely retry.  Defaults to the canonical
        retry semantics for *error_type*.
    version_metadata:
        Optional dict with ``protocol``, ``server``, and ``tool`` version keys
        for inclusion in logs and error responses.
    """

    def __init__(
        self,
        message: str,
        *,
        code: str = "MCP_ERROR",
        error_type: str = SYSTEM_ERROR,
        trace_id: str | None = None,
        hint: str | None = None,
        retriable: bool | None = None,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        if error_type not in _CANONICAL_TYPES:
            raise ValueError(
                f"error_type must be one of {sorted(_CANONICAL_TYPES)}, "
                f"got '{error_type}'"
            )

        self.code: str = code
        self.error_type: str = error_type
        self.trace_id: str | None = trace_id
        self.hint: str | None = hint
        self.version_metadata: dict[str, str] = version_metadata or {}

        # Resolve retry semantics
        if retriable is None:
            self.retriable: bool = _RETRY_SEMANTICS.get(error_type, False)
        else:
            self.retriable = retriable

        safe_message = _truncate_message(message)
        self.safe_message: str = safe_message
        super().__init__(safe_message)

    @property
    def envelope(self) -> dict[str, Any]:
        """Return the structured VW MCP error envelope."""
        inner: dict[str, Any] = {
            "code": self.code,
            "type": self.error_type,
            "message": self.safe_message,
            "trace_id": self.trace_id,
            "retriable": self.retriable,
        }
        if self.hint:
            inner["hint"] = self.hint
        if self.version_metadata:
            inner["version_metadata"] = self.version_metadata
        return {"error": inner}

    def __str__(self) -> str:  # noqa: D105
        parts = [f"[{self.code}]", self.safe_message]
        if self.trace_id:
            parts.append(f"(trace_id={self.trace_id})")
        return " ".join(parts)


# ---------------------------------------------------------------------------
# Canonical error subclasses
# ---------------------------------------------------------------------------


class MCPValidationError(MCPError):
    """Input schema or semantic validation failed (VALIDATION_ERROR).

    Non-retriable.  Callers must fix the request before retrying.
    """

    def __init__(
        self,
        detail: str,
        *,
        code: str = "MCP_VALIDATION_ERROR",
        trace_id: str | None = None,
        hint: str | None = None,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        super().__init__(
            detail,
            code=code,
            error_type=VALIDATION_ERROR,
            trace_id=trace_id,
            hint=hint,
            retriable=False,
            version_metadata=version_metadata,
        )


class MCPAuthenticationError(MCPError):
    """Authentication failed (AUTHENTICATION_ERROR).

    Non-retriable.  The caller must obtain valid credentials.
    """

    def __init__(
        self,
        detail: str = "Authentication required",
        *,
        code: str = "MCP_AUTHENTICATION_ERROR",
        trace_id: str | None = None,
        hint: str | None = None,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        super().__init__(
            detail,
            code=code,
            error_type=AUTHENTICATION_ERROR,
            trace_id=trace_id,
            hint=hint,
            retriable=False,
            version_metadata=version_metadata,
        )


class MCPAuthorizationError(MCPError):
    """Authorization denied (AUTHORIZATION_ERROR).

    Non-retriable.  The caller lacks the required permission.
    """

    def __init__(
        self,
        detail: str = "Authorization denied",
        *,
        code: str = "MCP_AUTHORIZATION_ERROR",
        trace_id: str | None = None,
        hint: str | None = None,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        super().__init__(
            detail,
            code=code,
            error_type=AUTHORIZATION_ERROR,
            trace_id=trace_id,
            hint=hint,
            retriable=False,
            version_metadata=version_metadata,
        )


class MCPNotFoundError(MCPError):
    """Requested tool or resource not found (NOT_FOUND_ERROR).

    Non-retriable.  The resource does not exist on this server.
    """

    def __init__(
        self,
        resource: str,
        *,
        code: str = "MCP_NOT_FOUND_ERROR",
        trace_id: str | None = None,
        hint: str | None = None,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        super().__init__(
            f"Resource not found: {resource}",
            code=code,
            error_type=NOT_FOUND_ERROR,
            trace_id=trace_id,
            hint=hint,
            retriable=False,
            version_metadata=version_metadata,
        )


class MCPConflictError(MCPError):
    """Concurrent access or duplicate execution conflict (CONFLICT_ERROR).

    Non-retriable unless an idempotency key is provided and the operation
    is designed for deduplication.
    """

    def __init__(
        self,
        detail: str,
        *,
        code: str = "MCP_CONFLICT_ERROR",
        trace_id: str | None = None,
        hint: str | None = None,
        idempotency_key: str | None = None,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        self.idempotency_key = idempotency_key
        super().__init__(
            detail,
            code=code,
            error_type=CONFLICT_ERROR,
            trace_id=trace_id,
            hint=hint,
            retriable=False,
            version_metadata=version_metadata,
        )


class MCPRateLimitError(MCPError):
    """Rate limit exceeded (RATE_LIMIT_ERROR).

    Non-retriable immediately; callers should wait and respect backoff.
    Includes ``retry_after_seconds`` when available from the server.
    """

    def __init__(
        self,
        detail: str = "Rate limit exceeded",
        *,
        code: str = "MCP_RATE_LIMIT_ERROR",
        retry_after_seconds: float | None = None,
        trace_id: str | None = None,
        hint: str | None = None,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        self.retry_after_seconds = retry_after_seconds
        _hint = hint or (
            f"Retry after {retry_after_seconds}s" if retry_after_seconds else "Wait before retrying."
        )
        super().__init__(
            detail,
            code=code,
            error_type=RATE_LIMIT_ERROR,
            trace_id=trace_id,
            hint=_hint,
            retriable=False,
            version_metadata=version_metadata,
        )

    @property
    def envelope(self) -> dict[str, Any]:
        env = super().envelope
        if self.retry_after_seconds is not None:
            env["error"]["retry_after_seconds"] = self.retry_after_seconds
        return env


class MCPSystemError(MCPError):
    """Generic system or dependency failure (SYSTEM_ERROR).

    MAY be retriable.  Used for transient infrastructure failures.
    """

    def __init__(
        self,
        detail: str,
        *,
        code: str = "MCP_SYSTEM_ERROR",
        trace_id: str | None = None,
        hint: str | None = None,
        retriable: bool = True,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        super().__init__(
            detail,
            code=code,
            error_type=SYSTEM_ERROR,
            trace_id=trace_id,
            hint=hint,
            retriable=retriable,
            version_metadata=version_metadata,
        )


# ---------------------------------------------------------------------------
# Operational subclasses (specialisations of canonical types)
# ---------------------------------------------------------------------------


class MCPConnectionError(MCPSystemError):
    """Failed to connect to or initialize an MCP server (SYSTEM_ERROR).

    Inherits SYSTEM_ERROR retry semantics (retriable MAY).
    Server URL credentials are stripped before inclusion in the message.
    """

    def __init__(
        self,
        server: str,
        detail: str = "",
        *,
        trace_id: str | None = None,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        self.server = server
        # Strip query strings / fragments to avoid leaking embedded credentials
        safe_server = server.split("?")[0].split("#")[0]
        msg = f"MCP connection failed for '{safe_server}'"
        if detail:
            # Take only first line, max 80 chars, to avoid internal leakage
            safe_detail = detail[:80].splitlines()[0]
            msg = f"{msg}: {safe_detail}"
        super().__init__(
            msg,
            code="MCP_CONNECTION_ERROR",
            trace_id=trace_id,
            hint="Check server URL, network access, and credentials.",
            version_metadata=version_metadata,
        )


class MCPToolCallError(MCPSystemError):
    """A remote MCP tool call returned an error or failed unexpectedly.

    Non-retriable by default; set ``retriable=True`` only for transient errors.
    """

    def __init__(
        self,
        tool_name: str,
        detail: str = "",
        *,
        trace_id: str | None = None,
        retriable: bool = False,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        self.tool_name = tool_name
        msg = f"MCP tool '{tool_name}' call failed"
        if detail:
            safe_detail = detail[:80].splitlines()[0]
            msg = f"{msg}: {safe_detail}"
        super().__init__(
            msg,
            code="MCP_TOOL_CALL_ERROR",
            trace_id=trace_id,
            retriable=retriable,
            hint="Inspect tool arguments and server logs for the root cause.",
            version_metadata=version_metadata,
        )


class MCPProtocolError(MCPSystemError):
    """Malformed MCP request, unsupported protocol version, or framing error.

    Protocol-level errors MUST prevent tool execution entirely.
    Non-retriable without fixing the protocol issue first.
    """

    def __init__(
        self,
        detail: str,
        *,
        code: str = "MCP_PROTOCOL_ERROR",
        trace_id: str | None = None,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        super().__init__(
            detail,
            code=code,
            trace_id=trace_id,
            retriable=False,
            hint="Ensure client and server support compatible MCP protocol versions.",
            version_metadata=version_metadata,
        )


class MCPSizeLimitError(MCPValidationError):
    """Inbound or outbound message size limit exceeded (VALIDATION_ERROR).

    Non-retriable; caller must reduce payload size.
    """

    def __init__(
        self,
        direction: str,  # "inbound" | "outbound"
        actual_bytes: int,
        limit_bytes: int,
        *,
        trace_id: str | None = None,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        self.direction = direction
        self.actual_bytes = actual_bytes
        self.limit_bytes = limit_bytes
        super().__init__(
            f"{direction.capitalize()} message {actual_bytes}B exceeds limit {limit_bytes}B",
            code="MCP_SIZE_LIMIT_ERROR",
            trace_id=trace_id,
            hint=f"Reduce {direction} payload to ≤{limit_bytes} bytes.",
            version_metadata=version_metadata,
        )


class MCPTenantError(MCPAuthorizationError):
    """Tenant isolation violation or cross-tenant access attempt.

    Specialisation of AUTHORIZATION_ERROR for multi-tenant scenarios.
    Raw tenant identifiers are NEVER surfaced in the message.
    """

    def __init__(
        self,
        detail: str = "Tenant authorization failed",
        *,
        tenant_ref: str | None = None,  # opaque / hashed reference, never raw tenant ID
        trace_id: str | None = None,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        self.tenant_ref = tenant_ref
        super().__init__(
            detail,
            code="MCP_TENANT_ERROR",
            trace_id=trace_id,
            hint="Verify tenant identity and ensure the request targets the correct tenant.",
            version_metadata=version_metadata,
        )


class MCPTimeoutError(MCPSystemError):
    """Tool or session execution exceeded the configured timeout (SYSTEM_ERROR).

    MAY be retriable for transient overloads.
    """

    def __init__(
        self,
        tool_name: str,
        timeout_ms: float,
        *,
        trace_id: str | None = None,
        retriable: bool = True,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        self.tool_name = tool_name
        self.timeout_ms = timeout_ms
        super().__init__(
            f"Tool '{tool_name}' timed out after {timeout_ms:.0f}ms",
            code="MCP_TIMEOUT_ERROR",
            trace_id=trace_id,
            retriable=retriable,
            hint="The server may be overloaded. Retry with backoff.",
            version_metadata=version_metadata,
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def is_retriable(error: MCPError) -> bool:
    """Return ``True`` if *error* allows a retry attempt."""
    return error.retriable


def error_type_for(error: MCPError) -> str:
    """Return the canonical error type string for *error*."""
    return error.error_type
