"""MCPTool -- adapts a single MCP tool into a LangChain BaseTool.

Each tool discovered from an MCP server becomes an ``MCPTool`` instance
that can be passed to ``llm.bind_tools()`` like any local tool.
Langfuse tracing is attached automatically.

Guideline compliance
--------------------
* Inbound size validation  – rejects tool inputs whose JSON encoding exceeds
  ``max_inbound_bytes`` before the server is called.
* Outbound size validation  – truncates / rejects responses that exceed
  ``max_outbound_bytes``; logs the truncation as an observability event.
* Execution timeout  – ``timeout_seconds`` enforces a hard cap per invocation;
  raises ``MCPTimeoutError`` with ``event=TIMEOUT`` logged.
* Idempotency key support  – tools that carry ``idempotency_key`` in their
  arguments deduplicate retried calls via an in-memory cache on the tool
  instance.  Deduplicated retries return the original result without executing
  the tool again.
* Semantic observability  – structured log events are emitted for every
  execution outcome: TOOL_CALL_START, TOOL_CALL_SUCCESS, TOOL_CALL_FAILED,
  TIMEOUT, EXECUTION_DEDUPLICATED, OUTPUT_TRUNCATED.
* Execution context binding  – ``trace_id`` and ``session_id`` are propagated
  to every log event and error envelope.
* Version metadata  – protocol, server, and tool version are attached to
  every error and Langfuse span.
* Output sanitisation  – raw HTML / script tags are stripped before the
  result is returned to the agent.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from typing import Any, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, create_model

from agentic_blueprint.mcp.errors import (
    MCPSizeLimitError,
    MCPTimeoutError,
    MCPToolCallError,
)
from agentic_blueprint.observability.context import get_current_trace_id

logger = logging.getLogger(__name__)

# Default guardrail limits (bytes)
_DEFAULT_MAX_INBOUND_BYTES = 1 * 1024 * 1024   # 1 MB
_DEFAULT_MAX_OUTBOUND_BYTES = 1 * 1024 * 1024  # 1 MB
_DEFAULT_TIMEOUT_SECONDS = 30.0

# Strip only dangerous HTML tags (script, style, iframe, object, embed) while preserving content
_DANGEROUS_TAG_RE = re.compile(
    r"<\s*/?(script|style|iframe|object|embed)[^>]*>",
    re.DOTALL | re.IGNORECASE,
)


def _sanitize_output(text: str) -> str:
    """Strip dangerous HTML tags (script, style, iframe) from tool output.

    Preserves legitimate HTML content from web scrapers while removing
    tags that could enable XSS or code injection.
    """
    return _DANGEROUS_TAG_RE.sub("", text)


def _schema_to_pydantic(
    name: str,
    input_schema: dict[str, Any],
    *,
    description: str = "",
    unwrap_parameters: bool = False,
) -> Type[BaseModel]:
    """Convert a JSON Schema ``properties`` dict into a Pydantic model.

    Handles the common scalar types (string, number, integer, boolean, object,
    array).  Anything exotic falls back to ``Any``.

    When *unwrap_parameters* is ``True`` and the schema's only property is an
    opaque ``parameters`` object (``additionalProperties: true``, no inner
    ``properties``), the envelope is stripped so the LLM sees the real
    arguments.  If no inner schema exists, the tool *description* is parsed
    for ``Args:`` docstring to reconstruct the parameter list.
    """
    _TYPE_MAP: dict[str, type] = {
        "string": str,
        "number": float,
        "integer": int,
        "boolean": bool,
    }

    properties = input_schema.get("properties", {})
    required = set(input_schema.get("required", []))

    # -- Unwrap VW MCP registry envelope -------------------------
    if unwrap_parameters and list(properties.keys()) == ["parameters"]:
        param_schema = properties["parameters"]
        inner_props = param_schema.get("properties", {})
        if inner_props:
            properties = inner_props
            required = set(param_schema.get("required", []))
        else:
            properties = _parse_args_from_description(description)
            required = set()

    fields: dict[str, Any] = {}
    for field_name, field_schema in properties.items():
        json_type = field_schema.get("type", "string")
        py_type = _TYPE_MAP.get(json_type, Any)
        desc = field_schema.get("description", "")
        default = ... if field_name in required else field_schema.get("default")
        fields[field_name] = (py_type, Field(default=default, description=desc))

    model_name = name.replace("/", "_").replace("-", "_") + "_Args"
    return create_model(model_name, **fields)


def _parse_args_from_description(description: str) -> dict[str, dict[str, str]]:
    """Extract parameter definitions from a tool description's ``Args:`` block."""
    _DESC_TYPE_MAP = {
        "str": "string",
        "string": "string",
        "int": "integer",
        "integer": "integer",
        "float": "number",
        "number": "number",
        "bool": "boolean",
        "boolean": "boolean",
        "list": "array",
        "list[dict]": "array",
        "dict": "object",
    }

    result: dict[str, dict[str, str]] = {}
    in_args = False
    for line in description.splitlines():
        stripped = line.strip()
        if stripped.lower().startswith("args:"):
            in_args = True
            continue
        if in_args:
            if not stripped or (stripped.endswith(":") and "(" not in stripped):
                if stripped and not stripped[0].isspace() and stripped != "":
                    break
                if not stripped:
                    continue
            m = re.match(r"(\w+)\s*\(([^)]+)\)\s*:\s*(.*)", stripped)
            if m:
                pname = m.group(1)
                ptype_raw = m.group(2).split(",")[0].strip().lower()
                pdesc = m.group(3).strip()
                json_type = _DESC_TYPE_MAP.get(ptype_raw, "string")
                result[pname] = {"type": json_type, "description": pdesc}
    return result


class MCPTool(BaseTool):
    """LangChain tool that delegates to a remote MCP server.

    Guardrails enforced by this class (tool-level):
    - Inbound message size limit (JSON-encoded kwargs)
    - Outbound message size limit (response truncation)
    - Execution timeout
    - Idempotency key deduplication (in-memory, per tool instance)
    - Output sanitisation (HTML/script tag stripping)
    - Structured observability events for every outcome
    """

    name: str
    description: str
    args_schema: Type[BaseModel]

    # Internal -- set by MCPToolkit, not by the user
    _session: Any = None
    _wrap_parameters: bool = False
    _trace_id_override: str | None = None
    _session_id: str | None = None
    _mcp_name: str = ""
    _max_inbound_bytes: int = _DEFAULT_MAX_INBOUND_BYTES
    _max_outbound_bytes: int = _DEFAULT_MAX_OUTBOUND_BYTES
    _timeout_seconds: float = _DEFAULT_TIMEOUT_SECONDS
    _version_metadata: dict[str, str] = {}
    # Idempotency cache: idempotency_key -> prior result
    _idempotency_cache: dict[str, str] = {}

    model_config = {"arbitrary_types_allowed": True}

    def set_session(
        self,
        session: Any,
        *,
        wrap_parameters: bool = False,
        trace_id: str | None = None,
        session_id: str | None = None,
        max_inbound_bytes: int = _DEFAULT_MAX_INBOUND_BYTES,
        max_outbound_bytes: int = _DEFAULT_MAX_OUTBOUND_BYTES,
        timeout_seconds: float = _DEFAULT_TIMEOUT_SECONDS,
        version_metadata: dict[str, str] | None = None,
    ) -> None:
        """Attach the MCP ClientSession and guardrail config (called by MCPToolkit)."""
        self._session = session
        self._wrap_parameters = wrap_parameters
        self._trace_id_override = trace_id
        self._session_id = session_id
        self._max_inbound_bytes = max_inbound_bytes
        self._max_outbound_bytes = max_outbound_bytes
        self._timeout_seconds = timeout_seconds
        self._version_metadata = version_metadata or {}
        self._idempotency_cache = {}

    def set_trace_id(self, trace_id: str | None) -> None:
        """Pin the Langfuse trace ID for this tool.

        This bypasses ``contextvars`` which may not propagate through
        nested ``asyncio.create_task()`` boundaries inside LangGraph.
        """
        self._trace_id_override = trace_id

    # -- sync (not supported -- MCP is async-only) --------------------

    def _run(self, **kwargs: Any) -> str:
        raise NotImplementedError(
            "MCPTool is async-only. Use ainvoke() or pass to an async "
            "agent (e.g. create_react_agent)."
        )

    # -- async ---------------------------------------------------------

    async def _arun(self, **kwargs: Any) -> str:
        if self._session is None:
            raise MCPToolCallError(
                self.name,
                "MCP session not connected",
                trace_id=self._trace_id_override,
                version_metadata=self._version_metadata,
            )

        mcp_name = self._mcp_name or self.name
        trace_id = self._trace_id_override or get_current_trace_id()

        # Strip None values – avoid sending explicit nulls to the server
        clean_kwargs = {k: v for k, v in kwargs.items() if v is not None}
        arguments = {"parameters": clean_kwargs} if self._wrap_parameters else clean_kwargs

        # -- Idempotency deduplication --------------------------------
        idempotency_key: str | None = clean_kwargs.get("idempotency_key")  # type: ignore[assignment]
        if idempotency_key and idempotency_key in self._idempotency_cache:
            logger.info(
                "event=EXECUTION_DEDUPLICATED tool=%s idempotency_key=%s "
                "trace_id=%s session_id=%s",
                mcp_name, idempotency_key, trace_id, self._session_id,
            )
            return self._idempotency_cache[idempotency_key]

        # -- Inbound size guard (schema + payload) --------------------
        if self._max_inbound_bytes:
            payload_bytes = len(json.dumps(arguments).encode("utf-8"))
            if payload_bytes > self._max_inbound_bytes:
                raise MCPSizeLimitError(
                    "inbound",
                    payload_bytes,
                    self._max_inbound_bytes,
                    trace_id=trace_id,
                    version_metadata=self._version_metadata,
                )

        logger.debug(
            "event=TOOL_CALL_START tool=%s trace_id=%s session_id=%s wrap=%s",
            mcp_name, trace_id, self._session_id, self._wrap_parameters,
        )

        # -- Langfuse span setup ------------------------------------
        span = None
        if trace_id:
            try:
                from langfuse import Langfuse
                lf = Langfuse()
                span = lf.start_span(
                    trace_context={"trace_id": trace_id},
                    name=f"tool:mcp:{mcp_name}",
                    input={
                        "tool": mcp_name,
                        "arguments": arguments,
                        "session_id": self._session_id,
                        "version_metadata": self._version_metadata,
                    },
                )
            except Exception:
                logger.debug("MCP tracing span creation failed", exc_info=True)

        start = time.perf_counter()
        try:
            # -- Timeout enforcement ------------------------------------
            output = await asyncio.wait_for(
                self._call_tool_flexible(mcp_name, arguments),
                timeout=self._timeout_seconds,
            )

            elapsed_ms = (time.perf_counter() - start) * 1000

            # -- Outbound size guard & truncation ----------------------
            output_bytes = len(output.encode("utf-8"))
            if self._max_outbound_bytes and output_bytes > self._max_outbound_bytes:
                logger.warning(
                    "event=OUTPUT_TRUNCATED tool=%s original_bytes=%d "
                    "limit_bytes=%d trace_id=%s",
                    mcp_name, output_bytes, self._max_outbound_bytes, trace_id,
                )
                output = output.encode("utf-8")[: self._max_outbound_bytes].decode(
                    "utf-8", errors="ignore"
                )

            # -- Output sanitisation ------------------------------------
            output = _sanitize_output(output)

            # -- Idempotency cache store --------------------------------
            if idempotency_key:
                self._idempotency_cache[idempotency_key] = output

            logger.info(
                "event=TOOL_CALL_SUCCESS tool=%s duration_ms=%.1f "
                "output_bytes=%d trace_id=%s session_id=%s",
                mcp_name, elapsed_ms, len(output.encode("utf-8")),
                trace_id, self._session_id,
            )

            if span:
                span.update(
                    output={
                        "status": "ok",
                        "output_bytes": len(output.encode("utf-8")),
                        "duration_ms": round(elapsed_ms, 2),
                    }
                )
                span.end()

            return output

        except asyncio.TimeoutError:
            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.error(
                "event=TIMEOUT tool=%s after_ms=%.0f trace_id=%s session_id=%s",
                mcp_name, elapsed_ms, trace_id, self._session_id,
            )
            exc = MCPTimeoutError(
                mcp_name,
                elapsed_ms,
                trace_id=trace_id,
                version_metadata=self._version_metadata,
            )
            if span:
                span.update(output={"status": "timeout", "after_ms": elapsed_ms}, level="ERROR")
                span.end()
            raise exc

        except (MCPSizeLimitError, MCPToolCallError):
            # Already structured – re-raise after closing span
            elapsed_ms = (time.perf_counter() - start) * 1000
            if span:
                span.update(output={"status": "error"}, level="ERROR")
                span.end()
            raise

        except Exception as exc:
            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.error(
                "event=TOOL_CALL_FAILED tool=%s duration_ms=%.1f "
                "trace_id=%s session_id=%s error=%s",
                mcp_name, elapsed_ms, trace_id, self._session_id,
                type(exc).__name__,
            )
            if span:
                span.update(output={"status": "error"}, level="ERROR")
                span.end()
            raise MCPToolCallError(
                mcp_name,
                str(exc),
                trace_id=trace_id,
                version_metadata=self._version_metadata,
            ) from exc

        finally:
            elapsed_ms = (time.perf_counter() - start) * 1000
            if span:
                try:
                    span.update(metadata={"duration_ms": round(elapsed_ms, 2)})
                except Exception:
                    pass

    # -- flexible call_tool with response unwrapping -------------------

    @staticmethod
    def _extract_text_from_content(content: Any) -> str:
        """Extract text from MCP content blocks (list of dicts or objects)."""
        if not isinstance(content, list):
            return str(content)
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict):
                parts.append(block.get("text", str(block)))
            elif hasattr(block, "text"):
                parts.append(block.text)
            else:
                parts.append(str(block))
        return "\n".join(parts) if parts else str(content)

    async def _call_tool_flexible(self, mcp_name: str, arguments: dict[str, Any]) -> str:
        """Call an MCP tool, handling registries that wrap the response.

        First tries the SDK's ``session.call_tool()`` which validates the
        response as ``CallToolResult``.  If validation fails (e.g. the VW
        MCP registry wraps the JSON-RPC result), falls back to a raw
        ``send_request`` with a permissive Pydantic model.
        """
        try:
            from mcp.types import TextContent

            result = await self._session.call_tool(mcp_name, arguments)

            parts: list[str] = []
            for block in result.content:
                if isinstance(block, TextContent):
                    parts.append(block.text)
                else:
                    parts.append(str(block))
            return "\n".join(parts) if parts else str(result.content)

        except Exception as first_err:
            if "ValidationError" not in type(first_err).__name__ and \
               "ValidationError" not in str(type(first_err)):
                raise

            logger.debug(
                "MCP call_tool validation failed for %s, trying raw request: %s",
                mcp_name, first_err,
            )

        # Fallback: send_request with a permissive result type
        from mcp.types import (
            CallToolRequest,
            CallToolRequestParams,
            ClientRequest,
            Result,
        )

        class _FlexResult(Result):
            """Permissive result that accepts any shape."""
            content: Any = None
            isError: bool = False
            model_config = {"extra": "allow"}

        request = ClientRequest(
            root=CallToolRequest(
                params=CallToolRequestParams(
                    name=mcp_name, arguments=arguments,
                ),
            ),
        )
        raw_result = await self._session.send_request(request, _FlexResult)

        content = raw_result.content
        # Unwrap double-wrapped responses: {'content': [...], 'isError': ...}
        if isinstance(content, dict) and "content" in content:
            content = content["content"]

        return self._extract_text_from_content(content)
