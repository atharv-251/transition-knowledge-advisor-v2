"""MCP integration for Agentic Blueprint -- connect agents to remote MCP tool servers.

Quick start::

    from agentic_blueprint.mcp import MCPToolkit

    async with MCPToolkit(server_url="https://mcp-registry.vw.com") as toolkit:
        tools = toolkit.as_tools()
        llm_with_tools = llm.bind_tools(tools)

Requires ``agentic_blueprint[mcp]`` (``pip install 'agentic_blueprint[mcp]'``).

Error model
-----------
All MCP errors carry a structured envelope conforming to the VW MCP Guideline:

    error.code     – stable, machine-readable identifier
    error.type     – canonical type from the closed set below
    error.message  – short (≤200 bytes), safe, deterministic
    error.trace_id – propagated correlation identifier
    error.retriable – whether a retry is safe

Canonical error types (import from ``agentic_blueprint.mcp.errors``):
    VALIDATION_ERROR, AUTHENTICATION_ERROR, AUTHORIZATION_ERROR,
    NOT_FOUND_ERROR, CONFLICT_ERROR, RATE_LIMIT_ERROR, SYSTEM_ERROR
"""

from agentic_blueprint.mcp.client import MCPToolkit
from agentic_blueprint.mcp.errors import (
    # Canonical error type constants
    AUTHENTICATION_ERROR,
    AUTHORIZATION_ERROR,
    CONFLICT_ERROR,
    NOT_FOUND_ERROR,
    RATE_LIMIT_ERROR,
    SYSTEM_ERROR,
    VALIDATION_ERROR,
    # Base
    MCPError,
    # Canonical subclasses
    MCPAuthenticationError,
    MCPAuthorizationError,
    MCPConflictError,
    MCPNotFoundError,
    MCPRateLimitError,
    MCPSystemError,
    MCPValidationError,
    # Operational subclasses
    MCPConnectionError,
    MCPProtocolError,
    MCPSizeLimitError,
    MCPTenantError,
    MCPTimeoutError,
    MCPToolCallError,
    # Helpers
    error_type_for,
    is_retriable,
)
from agentic_blueprint.mcp.tool_adapter import MCPTool

__all__ = [
    # Toolkit
    "MCPToolkit",
    "MCPTool",
    # Base error
    "MCPError",
    # Canonical error type constants
    "VALIDATION_ERROR",
    "AUTHENTICATION_ERROR",
    "AUTHORIZATION_ERROR",
    "NOT_FOUND_ERROR",
    "CONFLICT_ERROR",
    "RATE_LIMIT_ERROR",
    "SYSTEM_ERROR",
    # Canonical error classes
    "MCPValidationError",
    "MCPAuthenticationError",
    "MCPAuthorizationError",
    "MCPNotFoundError",
    "MCPConflictError",
    "MCPRateLimitError",
    "MCPSystemError",
    # Operational error classes
    "MCPConnectionError",
    "MCPToolCallError",
    "MCPProtocolError",
    "MCPSizeLimitError",
    "MCPTenantError",
    "MCPTimeoutError",
    # Helpers
    "is_retriable",
    "error_type_for",
]
