# Single-source version string — keep in sync with pyproject.toml.
# hatchling reads this file via [tool.hatch.version] path setting.
# No type annotation so hatchling's default regex (__version__ = "x.y.z") matches.
__version__ = "1.0.5"  # multimodal GPT-5 support, 22 bug fixes (13 critical/high + 9 medium)
