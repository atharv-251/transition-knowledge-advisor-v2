"""Platform configuration via Pydantic settings.

All configuration is driven by environment variables::

    export LLMAAS_API_KEY="sk-your-virtual-key"

Then in Python::

    from agentic_blueprint import init_blueprint, get_llm
    init_blueprint()          # validates credentials, sets up logging & tracing
    llm = get_llm()          # ready to use

Optional metadata variables (used for Langfuse trace tagging)::

    export AGENTIC_BLUEPRINT_PROJECT_ID="my-project"
    export AGENTIC_BLUEPRINT_WORKFLOW_ID="my-workflow"
"""

from __future__ import annotations

import functools
from enum import Enum
from typing import Any

from pydantic import Field, SecretStr, field_validator  # SecretStr used for AGENTIC_BLUEPRINT_SECRET_KEY and LLMAAS_* keys
from pydantic_settings import BaseSettings, SettingsConfigDict




class Environment(str, Enum):
    """Deployment environment."""

    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"


class AuditLevel(str, Enum):
    """How much detail to capture in audit events."""

    MINIMAL = "minimal"
    STANDARD = "standard"
    FULL = "full"


class LLMaaSSettings(BaseSettings):
    """VW LLMaaS connection settings.

    All fields are populated from ``LLMAAS_*`` environment variables.
    In normal operation, ``init_blueprint()`` resolves every field from
    the Agentic Blueprint Control Plane via ``AGENTIC_BLUEPRINT_SECRET_KEY`` and injects them
    into ``os.environ`` -- developers never set them manually.

    Fields default to empty strings because the settings object is
    instantiated before ``init_blueprint()`` runs.  After the Control
    Plane call, the settings cache is cleared and rebuilt with the
    resolved values.
    """

    model_config = SettingsConfigDict(env_prefix="LLMAAS_")

    # -- Resolved from Agentic Blueprint Control Plane (via AGENTIC_BLUEPRINT_SECRET_KEY) --
    client_id: str = Field(default="", description="OAuth client ID")
    client_secret: SecretStr = Field(default=SecretStr(""), description="OAuth client secret")
    idp_url: str = Field(default="", description="VW Cloud IDP token endpoint")
    base_url: str = Field(default="", description="LLMaaS API base URL")
    api_key: SecretStr = Field(default=SecretStr(""), description="Virtual API key")

    model: str = Field(default="gpt-4o", description="Default model")
    timeout: int = Field(default=120, description="Request timeout in seconds")
    token_refresh_buffer: int = Field(
        default=900,
        description="Refresh OAuth token this many seconds before expiry",
    )
    max_retries: int = Field(default=3, description="Max retries for LLM calls")

    @property
    def is_configured(self) -> bool:
        """Whether the required ``LLMAAS_API_KEY`` is set."""
        return bool(self.api_key.get_secret_value())

    @property
    def missing_fields(self) -> list[str]:
        """Return names of required but unset env vars."""
        missing: list[str] = []
        if not self.api_key.get_secret_value():
            missing.append("LLMAAS_API_KEY")
        return missing


class LangfuseSettings(BaseSettings):
    """Langfuse tracing settings.

    Resolved automatically from the Agentic Blueprint Control Plane alongside
    LLMaaS credentials.  If keys are present, the SDK enables tracing.
    If absent, the SDK works without tracing -- no errors, no warnings.

    Fields default to empty strings for the same bootstrap reason as
    ``LLMaaSSettings`` (settings are created before Control Plane call).
    """

    model_config = SettingsConfigDict(env_prefix="LANGFUSE_")

    public_key: str = Field(default="", description="Langfuse public key")
    secret_key: SecretStr = Field(default=SecretStr(""), description="Langfuse secret key")
    host: str = Field(default="", description="Langfuse host URL")

    @property
    def is_configured(self) -> bool:
        """Whether Langfuse credentials are present (auto-detection)."""
        return bool(self.public_key and self.secret_key.get_secret_value())


class AgenticBlueprintSettings(BaseSettings):
    """Top-level Agentic Blueprint settings.

    Project identity is propagated through every trace, audit event,
    and governance check::

        export AGENTIC_BLUEPRINT_PROJECT_ID="project-alpha"
    """

    model_config = SettingsConfigDict(env_prefix="AGENTIC_BLUEPRINT_")

    environment: Environment = Field(
        default=Environment.DEVELOPMENT,
        description="Deployment environment",
    )

    @field_validator("environment", mode="before")
    @classmethod
    def _normalise_environment(cls, v: Any) -> str:
        """Accept shorthand aliases: 'dev' -> 'development', 'prod' -> 'production'."""
        if isinstance(v, Environment):
            return v.value
        _aliases: dict[str, str] = {"dev": "development", "prod": "production"}
        raw = str(v).strip().lower()
        return _aliases.get(raw, raw)
    log_level: str = Field(default="INFO", description="Log level")
    enable_tracing: bool = Field(
        default=True, description="Enable Langfuse tracing (auto-disabled when keys absent)"
    )
    enable_guardrails: bool = Field(
        default=True, description="Enable guardrails"
    )
    audit_level: AuditLevel = Field(
        default=AuditLevel.STANDARD, description="Audit detail level"
    )

    # -- Project identity (optional -- Langfuse tagging) ---------
    project_id: str = Field(
        default="",
        description="Optional logical project identifier. "
        "Propagated to Langfuse traces and audit events as metadata. "
        "Not required for SDK operation.",
    )

    # -- Workflow identity (optional -- Langfuse tagging) --------
    workflow_id: str = Field(
        default="",
        description="Optional workflow / agent-pipeline identifier. "
        "Propagated to Langfuse traces as metadata. "
        "Defaults to the AgentGraph name when not set.",
    )

    # -- Agentic Blueprint platform key (reserved for future use) --
    secret_key: SecretStr = Field(
        default=SecretStr(""),
        description="Agentic Blueprint platform secret key (AGENTIC_BLUEPRINT_SECRET_KEY). "
        "Reserved for future credential resolution.",
    )

    # Nested settings -- loaded independently from their own env prefixes
    llmaas: LLMaaSSettings = Field(default_factory=LLMaaSSettings)
    langfuse: LangfuseSettings = Field(default_factory=LangfuseSettings)

    @property
    def tracing_enabled(self) -> bool:
        """Resolved flag: tracing is on only when *both* the user asked for it
        *and* Langfuse credentials are actually present."""
        return self.enable_tracing and self.langfuse.is_configured


@functools.lru_cache(maxsize=1)
def get_settings() -> AgenticBlueprintSettings:
    """Return the singleton platform settings, cached after first load."""
    return AgenticBlueprintSettings()


def reset_settings() -> None:
    """Clear the cached settings so the next call rebuilds from env vars.

    Called by ``init_blueprint()`` after mutating environment variables
    (e.g. injecting LLMaaS credentials from the Control Plane).
    """
    get_settings.cache_clear()
