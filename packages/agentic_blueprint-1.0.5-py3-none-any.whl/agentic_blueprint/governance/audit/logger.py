"""Audit logger -- guard that emits structured audit events.

By default events are written to structlog (and therefore to stdout/JSON).
Teams can extend ``AuditLogger`` to push events to external systems
(Kafka, S3, Langfuse scores, etc.).

Every event carries the project identity (``project_id``, ``user_id``)
for downstream filtering and compliance.
"""

from __future__ import annotations

import functools
import logging
from typing import Any

import structlog

from agentic_blueprint.governance.audit.events import AuditEvent, AuditEventType
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guards import GovernanceGuard

logger = structlog.get_logger("agentic_blueprint.audit")

# Keys that carry payload content (redacted in minimal mode)
_PAYLOAD_KEYS = frozenset({
    "input", "output", "input_state", "output_state",
    "detail", "draft", "content", "messages", "response",
})


@functools.lru_cache(maxsize=1)
def _get_audit_level() -> str:
    """Resolve the current audit level from settings (cached for performance)."""
    try:
        from agentic_blueprint.config.settings import get_settings
        return get_settings().audit_level.value
    except Exception:
        logger.warning(
            "failed to resolve audit_level from settings, defaulting to 'standard'",
            exc_info=True,
        )
        return "standard"


def _filter_event_payload(event_dict: dict[str, Any], audit_level: str) -> dict[str, Any]:
    """Apply payload filtering based on audit level.

    - ``minimal``: Metadata-only.  All payload content is replaced with
      ``[REDACTED - metadata_only]`` and a character count.  GDPR-safe.
    - ``standard``: Structured data with payload summaries.  Default.
    - ``full``: Complete payloads logged.  Required for Screenshot Defense
      (Level 3 external exposure).
    """
    if audit_level == "full":
        return event_dict  # No filtering — everything logged

    if audit_level == "minimal":
        filtered = {}
        for k, v in event_dict.items():
            if k in _PAYLOAD_KEYS and v:
                # Redact payload but preserve length for diagnostics
                content_str = str(v)
                filtered[k] = f"[REDACTED - {len(content_str)} chars]"
            else:
                filtered[k] = v
        return filtered

    # standard — pass through (current default behaviour)
    return event_dict


class AuditLogger:
    """Emits :class:`AuditEvent` instances to structlog.

    Payload filtering is controlled by ``AGENTIC_BLUEPRINT_AUDIT_LEVEL``:

    - ``minimal``  — metadata-only (GDPR-safe, Privacy Guard compliant)
    - ``standard`` — structured data with payloads (default)
    - ``full``     — complete payloads (Screenshot Defense compliant)
    """

    async def emit(self, event: AuditEvent) -> None:
        """Write an audit event with payload filtering."""
        audit_level = _get_audit_level()
        raw = {k: v for k, v in event.to_dict().items() if k != "event_type"}
        filtered = _filter_event_payload(raw, audit_level)
        await logger.ainfo(
            event.event_type.value,
            **filtered,
        )


class AuditGuard(GovernanceGuard):
    """Guard that produces audit events around node execution."""

    def __init__(self, audit_logger: AuditLogger | None = None) -> None:
        self._logger = audit_logger or AuditLogger()

    async def before_node(self, ctx: ExecutionContext) -> ExecutionContext:
        await self._logger.emit(
            AuditEvent(
                event_type=AuditEventType.NODE_START,
                agent_name=ctx.agent_name,
                node_name=ctx.node_name,
                trace_id=ctx.trace_id,
                session_id=ctx.session_id,
                user_id=ctx.user_id,
                project_id=ctx.project_id,
                metadata={"step": ctx.step_count},
            )
        )
        return ctx

    async def after_node(self, ctx: ExecutionContext) -> ExecutionContext:
        # Emit guardrail results from this node, if any
        gr_results: list[Any] = ctx.metadata.get("guardrail_results", [])
        for gr in gr_results:
            event_type = {
                "pass": AuditEventType.GUARDRAIL_PASS,
                "redact": AuditEventType.GUARDRAIL_REDACT,
                "block": AuditEventType.GUARDRAIL_BLOCK,
            }.get(gr.action.value if hasattr(gr, "action") else "pass", AuditEventType.GUARDRAIL_PASS)

            await self._logger.emit(
                AuditEvent(
                    event_type=event_type,
                    agent_name=ctx.agent_name,
                    node_name=ctx.node_name,
                    trace_id=ctx.trace_id,
                    session_id=ctx.session_id,
                    user_id=ctx.user_id,
                    project_id=ctx.project_id,
                    detail=getattr(gr, "detail", ""),
                )
            )

        # Emit node end
        await self._logger.emit(
            AuditEvent(
                event_type=AuditEventType.NODE_END,
                agent_name=ctx.agent_name,
                node_name=ctx.node_name,
                trace_id=ctx.trace_id,
                session_id=ctx.session_id,
                user_id=ctx.user_id,
                project_id=ctx.project_id,
                metadata={
                    "step": ctx.step_count,
                    "elapsed_s": round(ctx.node_elapsed_seconds, 3),
                    "total_tokens": ctx.total_tokens,
                },
            )
        )
        return ctx
