"""Structured audit events.

Every governance-relevant action is captured as an ``AuditEvent`` for
compliance and post-mortem analysis.  The ``project_id`` field ensures
events can be partitioned by project for reporting.
"""

from __future__ import annotations

import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any


class AuditEventType(str, Enum):
    NODE_START = "node_start"
    NODE_END = "node_end"
    POLICY_PASS = "policy_pass"
    POLICY_VIOLATION = "policy_violation"
    GUARDRAIL_PASS = "guardrail_pass"
    GUARDRAIL_REDACT = "guardrail_redact"
    GUARDRAIL_BLOCK = "guardrail_block"
    ERROR = "error"


@dataclass(frozen=True)
class AuditEvent:
    event_type: AuditEventType
    agent_name: str
    node_name: str
    trace_id: str
    timestamp: float = field(default_factory=time.time)
    session_id: str | None = None
    user_id: str | None = None
    project_id: str | None = None
    detail: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
