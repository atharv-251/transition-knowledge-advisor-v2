"""Identity model — OBO (On-Behalf-Of) stubs and permission interfaces.

Implements the VW Agentic Standards §3 identity architecture as abstract
interfaces.  The SDK is a **consumer** of identity, not a provider —
authentication and authorisation are handled by the IDP (Keycloak,
Azure AD / Entra, etc.) and the API gateway.

The SDK's role:

1. **Declare** the identity mode (OBO vs Service Account) so auditors
   can verify compliance.
2. **Propagate** user identity through the agent pipeline (every LLM
   call, tool call, and audit event).
3. **Enforce rules** based on identity mode + data sensitivity:

   - Privacy Guard: ``SECRET``/``PII_GDPR`` data → must be OBO.
   - Shadow Token: effective permissions = MIN(user, agent, system).

4. **Provide interfaces** for Phase 2 IDP integration without
   breaking changes.

Current state (v0.4.6):
    ``IdentityMode`` enum + ``ShadowTokenProvider`` / ``PermissionModel``
    abstract interfaces.  Real OBO flows require IDP integration
    (Phase 2).

Usage::

    from agentic_blueprint import wrap
    from agentic_blueprint.governance.identity import IdentityMode

    # Explicitly declare — even SERVICE_ACCOUNT is better than implicit
    governed = wrap(
        graph,
        name="hr-salary-agent",
        identity_mode=IdentityMode.ON_BEHALF_OF,
        data_sensitivity="pii_gdpr",
    )

    # Phase 2 — custom OBO provider
    from agentic_blueprint.governance.identity import ShadowTokenProvider

    class MyOBOProvider(ShadowTokenProvider):
        async def create_shadow_token(self, user_token, agent_scope):
            # Call Keycloak token exchange endpoint
            return await keycloak.exchange(user_token, agent_scope)

    init_blueprint(shadow_token_provider=MyOBOProvider())
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


# ============================================================================
# Identity Mode
# ============================================================================


class IdentityMode(str, Enum):
    """Identity mode — whose credentials are used at runtime.

    Determines the authorization model for downstream API calls.
    """

    SERVICE_ACCOUNT = "service_account"
    """Type B: Agent acts as a standalone system identity.

    The agent uses its own client_id / client_secret (OAuth
    client-credentials flow).  The user's identity is NOT propagated
    to downstream systems.

    Use when:
    - Background / cron-triggered agents (no human at runtime).
    - Anonymous external customers.
    - Data sensitivity ≤ INTERNAL.

    Risk: Highest — no human "owner" at runtime.  Agent has full
    service-account permissions regardless of who triggered it.
    """

    ON_BEHALF_OF = "on_behalf_of"
    """Type A: Agent acts using the signed-in user's identity.

    A "Shadow Token" (short-lived JWT) is created combining:
    - User Principal (employee ID / sub claim from IDP).
    - Agent Application ID (LeanIX ID / service registration).
    - Effective permissions = MIN(user rights ∩ agent scope).

    Use when:
    - Data sensitivity = SECRET or PII/GDPR (mandatory).
    - Personalisation based on user role/department.
    - Audit trail must attribute actions to a specific human.

    Requires: IDP integration (Keycloak / Azure AD token exchange).
    """


# ============================================================================
# Shadow Token Provider (Phase 2 interface)
# ============================================================================


class ShadowTokenProvider(ABC):
    """Interface for creating scoped tokens combining user + agent identity.

    A Shadow Token is a short-lived JWT containing:

    - ``user_principal``: Who is the boss? (Employee ID from IDP)
    - ``agent_application_id``: Who is the worker? (LeanIX / registration ID)
    - ``effective_scope``: MIN(user permissions ∩ agent coded scope)

    Implementations should call the IDP's token exchange endpoint
    (e.g., Keycloak's token exchange, Azure AD's OBO flow).

    Example::

        class KeycloakShadowTokenProvider(ShadowTokenProvider):
            def __init__(self, keycloak_url: str):
                self._url = keycloak_url

            async def create_shadow_token(
                self, user_token: str, agent_scope: list[str]
            ) -> str:
                # POST to Keycloak token exchange endpoint
                async with httpx.AsyncClient() as client:
                    resp = await client.post(
                        f"{self._url}/realms/vw/protocol/openid-connect/token",
                        data={
                            "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
                            "subject_token": user_token,
                            "audience": "agent-procurement-app",
                            "scope": " ".join(agent_scope),
                        },
                    )
                return resp.json()["access_token"]
    """

    @abstractmethod
    async def create_shadow_token(
        self,
        user_token: str,
        agent_scope: list[str],
    ) -> str:
        """Create a scoped shadow token for the agent to use.

        Parameters
        ----------
        user_token:
            The user's JWT (from IDP via API gateway).
        agent_scope:
            The agent's declared capabilities/permissions.

        Returns
        -------
        str
            A short-lived JWT with effective permissions =
            MIN(user_token claims ∩ agent_scope).
        """
        ...

    @abstractmethod
    async def validate_shadow_token(self, shadow_token: str) -> dict[str, Any]:
        """Validate a shadow token and return its claims.

        Returns
        -------
        dict
            Decoded claims including ``user_principal``,
            ``agent_application_id``, ``effective_scope``,
            ``human_verified`` (if JIT approval was granted).
        """
        ...


class DefaultShadowTokenProvider(ShadowTokenProvider):
    """No-op provider for SERVICE_ACCOUNT mode.

    Logs a warning if called — real OBO requires an IDP-backed
    implementation.
    """

    async def create_shadow_token(
        self,
        user_token: str,
        agent_scope: list[str],
    ) -> str:
        logger.warning(
            "DefaultShadowTokenProvider.create_shadow_token() called — "
            "OBO is not configured.  "
            "Implement ShadowTokenProvider for production OBO."
        )
        raise NotImplementedError(
            "DefaultShadowTokenProvider does not issue real tokens. "
            "Implement ShadowTokenProvider for OBO support."
        )

    async def validate_shadow_token(self, shadow_token: str) -> dict[str, Any]:
        logger.warning(
            "DefaultShadowTokenProvider.validate_shadow_token() called — "
            "OBO is not configured."
        )
        return {}


# ============================================================================
# Permission Intersection Model
# ============================================================================


class PermissionModel:
    """Three-layer permission intersection (VW Agentic Standards §3).

    An action only executes if ALL THREE layers return True:

    1. **User Context** (Consent layer): Does the user allow this?
       → Derived from user's JWT claims / roles from the IDP.

    2. **Agent Manifest** (Capability layer): Is the agent coded to do this?
       → Declared at registration / in wrap() config.

    3. **System Policy** (Compliance layer): Does the target system enable
       agents to do this?
       → Target API's own RBAC for agent service accounts.

    Effective permissions = user_permissions ∩ agent_scope ∩ system_policy

    Example::

        perm = PermissionModel(
            user_permissions={"procurement:read", "procurement:write", "hr:read"},
            agent_scope={"procurement:read", "procurement:write"},
            system_policy={"procurement:read", "procurement:write", "finance:read"},
        )
        perm.effective
        # → {"procurement:read", "procurement:write"}
        perm.can("procurement:write")  # True
        perm.can("hr:read")            # False — agent doesn't have scope
        perm.can("finance:read")       # False — user doesn't have permission
    """

    def __init__(
        self,
        user_permissions: set[str] | None = None,
        agent_scope: set[str] | None = None,
        system_policy: set[str] | None = None,
    ) -> None:
        self.user_permissions = user_permissions or set()
        self.agent_scope = agent_scope or set()
        self.system_policy = system_policy or set()

    @property
    def effective(self) -> set[str]:
        """Compute effective permissions = intersection of all 3 layers."""
        return self.user_permissions & self.agent_scope & self.system_policy

    def can(self, permission: str) -> bool:
        """Check if a specific permission is granted across all layers."""
        return permission in self.effective

    def explain_denial(self, permission: str) -> str:
        """Explain why a permission is denied (which layer blocked it)."""
        denied_by: list[str] = []
        if permission not in self.user_permissions:
            denied_by.append("User Context (user does not have this permission)")
        if permission not in self.agent_scope:
            denied_by.append("Agent Manifest (agent is not coded for this)")
        if permission not in self.system_policy:
            denied_by.append("System Policy (target system does not allow agents)")
        if not denied_by:
            return f"Permission '{permission}' is GRANTED"
        return f"Permission '{permission}' DENIED by: {'; '.join(denied_by)}"
