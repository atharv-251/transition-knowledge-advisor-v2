"""Framework-agnostic governance pipeline.

``GovernancePipeline`` bundles guard collection, step tracking,
execution context creation, and before/after hook orchestration into
a single reusable component that **any** framework adapter can use.

LangGraph's ``AgentGraph`` already contains this logic inline.  This
class extracts it so the DeepAgents adapter, LangChain adapter, and
future integrations can enforce the same governance without duplicating
the plumbing.

Usage::

    from agentic_blueprint.governance.pipeline import GovernancePipeline
    from agentic_blueprint.governance.policies import MaxStepsPolicy
    from agentic_blueprint.governance.guardrails import OutputPIIGuardrail
    from agentic_blueprint.governance.audit import AuditGuard

    pipeline = GovernancePipeline()
    pipeline.add_guards(MaxStepsPolicy(max_steps=10))
    pipeline.add_guards(OutputPIIGuardrail())
    pipeline.add_guards(AuditGuard())

    # Inside a framework adapter:
    pipeline.reset()
    step = pipeline.next_step()
    ctx = pipeline.build_context(agent_name="my-agent", node_name="step_1", ...)
    result, ctx = await pipeline.execute_governed(fn, state, ctx)
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable

from agentic_blueprint._internal.helpers import generate_id
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guards import GovernanceGuard, GuardsPipeline
from agentic_blueprint.observability.context import (
    get_current_trace_id,
    get_project_id,
    get_session_id,
    get_user_id,
)

logger = logging.getLogger(__name__)


class GovernancePipeline:
    """Framework-agnostic governance orchestrator.

    Collects guards, tracks step counts, builds execution contexts,
    and runs before/after hooks.  Framework adapters delegate governance
    to this class rather than implementing it themselves.
    """

    def __init__(self) -> None:
        self._guards = GuardsPipeline()
        self._step_counter: int = 0

    # -- Guard management ---------------------------------------

    def add_guards(self, guard: GovernanceGuard) -> None:
        """Append a governance guard (policy, guardrail, audit logger)."""
        self._guards.add(guard)

    # -- Step tracking -----------------------------------------

    def reset(self) -> None:
        """Reset the step counter (call at the start of each invocation)."""
        self._step_counter = 0

    def next_step(self) -> int:
        """Increment and return the current step number."""
        self._step_counter += 1
        return self._step_counter

    @property
    def step_count(self) -> int:
        """Current step number within this invocation."""
        return self._step_counter

    # -- State helpers -----------------------------------------

    @staticmethod
    def build_governance_state(
        node_name: str,
        current_state: dict[str, Any],
        *,
        trace_id: str = "",
        project_id: str = "",
        user_id: str = "",
        session_id: str = "",
    ) -> dict[str, Any]:
        """Build the ``ab_*`` governance fields to inject into agent state.

        Returns a dict that should be merged into the state **before** the
        node function runs.
        """
        node_history = list(current_state.get("ab_node_history") or [])
        node_history.append(node_name)

        update: dict[str, Any] = {
            "ab_trace_id": trace_id,
            "ab_project_id": project_id,
            "ab_user_id": user_id,
            "ab_session_id": session_id,
            "ab_node_history": node_history,
        }
        if "ab_governance_metadata" not in current_state:
            update["ab_governance_metadata"] = {}
        return update

    def build_context(
        self,
        *,
        agent_name: str,
        node_name: str,
        trace_id: str | None = None,
        session_id: str | None = None,
        user_id: str | None = None,
        project_id: str | None = None,
        input_state: dict[str, Any] | None = None,
        tags: list[str] | None = None,
        governance_config: dict[str, Any] | None = None,
    ) -> ExecutionContext:
        """Create an :class:`ExecutionContext` for the current step.

        If identity fields are ``None``, they are read from the
        thread-local tracing context (set by the framework adapter's
        ``ainvoke``).
        """
        return ExecutionContext(
            agent_name=agent_name,
            node_name=node_name,
            trace_id=trace_id or get_current_trace_id() or generate_id("tr-"),
            session_id=session_id or get_session_id(),
            user_id=user_id or get_user_id(),
            project_id=project_id or get_project_id(),
            input_state=input_state or {},
            step_count=self._step_counter,
            tags=tags or [],
            governance_config=governance_config or {},
        )

    # -- Execution ---------------------------------------------

    async def run_before(self, ctx: ExecutionContext) -> ExecutionContext:
        """Run all ``before_node`` guard hooks."""
        return await self._guards.run_before(ctx)

    async def run_after(self, ctx: ExecutionContext) -> ExecutionContext:
        """Run all ``after_node`` guard hooks."""
        return await self._guards.run_after(ctx)

    async def execute_governed(
        self,
        fn: Callable[..., Any],
        state: dict[str, Any],
        ctx: ExecutionContext,
        *,
        is_async: bool = True,
    ) -> tuple[Any, ExecutionContext]:
        """Execute *fn* with governance before/after hooks.

        1. Runs ``before_node`` guards (policies can block here).
        2. Calls *fn(state)*.
        3. Runs ``after_node`` guards (guardrails can redact/block here).

        Returns:
            ``(result, ctx)`` -- the raw node result and the updated context.
        """
        ctx = await self.run_before(ctx)

        # Check if a before_node guard soft-blocked (set block_response
        # without raising).  If so, skip the node function entirely.
        if ctx.metadata.get("guardrail_blocked_response"):
            ctx.output_state = state  # preserve input state as output
            ctx = await self.run_after(ctx)
            return state, ctx

        try:
            if is_async:
                result = await fn(state)
            else:
                result = await asyncio.to_thread(fn, state)
        except Exception as exc:
            ctx.error = exc
            try:
                await self.run_after(ctx)
            except Exception:
                logger.debug("run_after failed during error handling", exc_info=True)
            raise

        ctx.output_state = result
        ctx = await self.run_after(ctx)
        return result, ctx
