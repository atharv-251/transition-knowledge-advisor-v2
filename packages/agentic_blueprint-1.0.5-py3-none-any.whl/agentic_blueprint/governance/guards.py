"""Governance guards pipeline.

The pipeline intercepts every node execution with ``before_node`` / ``after_node``
hooks.  Built-in guards handle tracing, policies, guardrails, and audit.
Teams can add custom guards via ``AgentGraph.add_guards()``.
"""


from __future__ import annotations

import abc
import logging
from typing import Sequence

from agentic_blueprint.exceptions import GovernanceError
from agentic_blueprint.governance.context import ExecutionContext

logger = logging.getLogger(__name__)


class GovernanceGuard(abc.ABC):
    """Abstract base for governance guards.

    Implement ``before_node`` and/or ``after_node`` to intercept execution.
    Return the (possibly mutated) ``ExecutionContext``.
    Raise any ``GovernanceError`` subclass to block execution.
    """

    @property
    def name(self) -> str:
        return self.__class__.__name__

    async def before_node(self, ctx: ExecutionContext) -> ExecutionContext:
        """Called before a node executes.  Override to inspect/block."""
        return ctx

    async def after_node(self, ctx: ExecutionContext) -> ExecutionContext:
        """Called after a node executes.  Override to inspect/log."""
        return ctx


class GuardsPipeline:
    """Ordered pipeline of :class:`GovernanceGuard` instances."""

    def __init__(self, guards: Sequence[GovernanceGuard] = ()) -> None:
        self._guards: list[GovernanceGuard] = list(guards)

    def add(self, guard: GovernanceGuard) -> None:
        self._guards.append(guard)
        logger.debug("Guard added: %s", guard.name)

    async def run_before(self, ctx: ExecutionContext) -> ExecutionContext:
        """Run all ``before_node`` hooks in order.

        When any guard raises an exception that carries a
        ``block_response`` attribute, the exception is caught and its
        response text is stored in ``ctx.metadata["guardrail_blocked_response"]``.
        The caller (``wrap.py``) can then inject that text as a user-facing
        reply instead of propagating an exception.

        This applies uniformly to **all** guardrails and policies -- any
        component that sets ``block_response`` participates in soft-blocking.

        If ``block_response`` is ``None``, the error propagates as before
        (fully backward-compatible).
        """
        for guard in self._guards:
            try:
                ctx = await guard.before_node(ctx)
            except GovernanceError as exc:
                block_response = getattr(exc, "block_response", None)
                if block_response:
                    logger.info(
                        "Guard %s.before_node soft-blocked (returning response)",
                        guard.name,
                    )
                    ctx.metadata["guardrail_blocked_response"] = block_response
                    ctx.metadata["guardrail_blocked_detail"] = str(exc)
                    return ctx
                logger.exception("Guard %s.before_node failed", guard.name)
                raise
        return ctx

    async def run_after(self, ctx: ExecutionContext) -> ExecutionContext:
        """Run all ``after_node`` hooks in order.

        GovernanceError subclasses (including GuardrailBlockedError) are
        **re-raised** so that blocking guardrails actually block.
        When a GovernanceError carries ``block_response``, it is stored
        in context metadata for soft-blocking (same as ``run_before``).
        Other unexpected exceptions are **re-raised** (fail-closed) to
        prevent silent security bypasses — a broken guardrail must not
        silently pass unscanned output to the caller.
        """
        for guard in self._guards:
            try:
                ctx = await guard.after_node(ctx)
            except GovernanceError as exc:
                block_response = getattr(exc, "block_response", None)
                if block_response:
                    logger.info(
                        "Guard %s.after_node soft-blocked (returning response)",
                        guard.name,
                    )
                    ctx.metadata["guardrail_blocked_response"] = block_response
                    ctx.metadata["guardrail_blocked_detail"] = str(exc)
                    return ctx
                # Governance errors without block_response MUST propagate.
                logger.warning("Guard %s.after_node raised GovernanceError", guard.name)
                raise
            except Exception as exc:
                # Let HITL interrupt exceptions propagate (control flow,
                # not errors).  Check by class name to avoid importing
                # framework-specific types in this generic module.
                if type(exc).__name__ in ("GraphInterrupt", "NodeInterrupt"):
                    raise
                # Fail-closed: unexpected errors in security guardrails
                # must propagate to prevent silent output leaks.
                logger.exception("Guard %s.after_node failed unexpectedly", guard.name)
                raise
        return ctx

