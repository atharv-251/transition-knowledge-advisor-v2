"""Auto-governance patch for LangGraph compiled graphs.

When :func:`install_patch` is called (by ``init_blueprint()``), it
monkey-patches LangGraph's ``CompiledStateGraph`` so that **any**
``ainvoke()`` / ``invoke()`` / ``astream()`` on an *unwrapped* graph
automatically applies mandate guards.

Detection mechanism
-------------------
:func:`~agentic_blueprint.core.wrap.wrap` sets ``compiled_graph._ab_governed = True``
on the inner graph.  The patched methods check this flag:

- **Flag present** → the developer already called ``wrap()``.
  Execute the original method unchanged (governanced graph handles it).
- **Flag absent** → the developer forgot ``wrap()``.
  Auto-wrap with mandate guards and a default ``MaxStepsPolicy`` to
  prevent runaway tool loops in inner agents, then log a warning.

This guarantees that mandate guards (``AuditGuard``,
``ModelAllowlistPolicy``) can **never** be skipped, regardless of
whether the developer remembered to call ``wrap()``.
"""

from __future__ import annotations

import asyncio
import functools
import logging
from typing import Any

from agentic_blueprint.core.wrap import wrap as _wrap_graph
from agentic_blueprint.governance.policies import MaxStepsPolicy

try:
    from langgraph.graph.state import CompiledStateGraph
    _langgraph_available = True
except ImportError:
    CompiledStateGraph = None  # type: ignore[assignment,misc]
    _langgraph_available = False

logger = logging.getLogger(__name__)

# Sentinel attribute name set on patched classes to prevent double-patching.
_PATCH_MARKER = "_ab_auto_governance_patched"

# Default step limit for auto-governed inner graphs.
# Generous enough for complex tool-use agents (e.g. create_react_agent),
# tight enough to catch runaway loops before they consume excessive tokens.
_DEFAULT_INNER_MAX_STEPS = 25


def install_patch() -> None:
    """Monkey-patch LangGraph's ``CompiledStateGraph`` for auto-governance.

    Safe to call multiple times -- subsequent calls are silent no-ops.
    If LangGraph is not installed, does nothing.
    """
    if not _langgraph_available or CompiledStateGraph is None:
        return

    # Already patched — nothing to do
    if getattr(CompiledStateGraph, _PATCH_MARKER, False):
        return

    _patch_class(CompiledStateGraph)

    # Mark the class so we never patch twice
    setattr(CompiledStateGraph, _PATCH_MARKER, True)

    logger.info("Auto-governance patch installed on CompiledStateGraph")


# ---------------------------------------------------------------------------
# Internal patching helpers
# ---------------------------------------------------------------------------


def _patch_class(cls: type) -> None:
    """Replace ``ainvoke``, ``invoke``, and ``astream`` on *cls*."""

    original_ainvoke = cls.ainvoke
    original_invoke = cls.invoke
    original_astream = getattr(cls, "astream", None)

    @functools.wraps(original_ainvoke)
    async def _ainvoke(self: Any, *args: Any, **kwargs: Any) -> Any:
        if getattr(self, "_ab_governed", False):
            return await original_ainvoke(self, *args, **kwargs)
        if not hasattr(self, "_ab_governed_cache"):
            self._ab_governed_cache = _auto_wrap(self)
        return await self._ab_governed_cache.ainvoke(*args, **kwargs)

    @functools.wraps(original_invoke)
    def _invoke(self: Any, *args: Any, **kwargs: Any) -> Any:
        if getattr(self, "_ab_governed", False):
            return original_invoke(self, *args, **kwargs)
        if not hasattr(self, "_ab_governed_cache"):
            self._ab_governed_cache = _auto_wrap(self)
        return self._ab_governed_cache.invoke(*args, **kwargs)

    cls.ainvoke = _ainvoke
    cls.invoke = _invoke

    if original_astream is not None:
        @functools.wraps(original_astream)
        async def _astream(self: Any, *args: Any, **kwargs: Any):  # type: ignore[override]
            if getattr(self, "_ab_governed", False):
                async for event in original_astream(self, *args, **kwargs):
                    yield event
                return
            if not hasattr(self, "_ab_governed_cache"):
                self._ab_governed_cache = _auto_wrap(self)
            async for event in self._ab_governed_cache.astream(*args, **kwargs):
                yield event

        cls.astream = _astream


def _auto_wrap(compiled_graph: Any) -> Any:
    """Wrap an ungoverned compiled graph with mandate guards + default step limit.

    Issues a warning so developers know governance was applied
    automatically rather than explicitly.  A default
    ``MaxStepsPolicy(_DEFAULT_INNER_MAX_STEPS)`` is injected to prevent
    runaway tool loops in inner agents (e.g. ``create_react_agent``).
    """
    graph_name = getattr(compiled_graph, "name", None) or "auto-governed"

    logger.warning(
        "Ungoverned graph '%s' detected — auto-applying mandate guards "
        "and default MaxStepsPolicy(max_steps=%d). "
        "Call wrap() explicitly to set your own step limit.",
        graph_name,
        _DEFAULT_INNER_MAX_STEPS,
    )

    # wrap() prepends mandate guards automatically (see wrap.py).
    # We also inject a default MaxStepsPolicy so inner graphs
    # (e.g. create_react_agent) cannot loop indefinitely.
    return _wrap_graph(
        compiled_graph,
        name=graph_name,
        guards=[MaxStepsPolicy(max_steps=_DEFAULT_INNER_MAX_STEPS)],
    )
