"""Grounding / hallucination detection guardrail.

Checks whether the LLM's output is **grounded** in provided source material.
This helps catch hallucinated claims, fabricated citations, and unsupported
assertions -- critical for enterprise use cases where factual accuracy matters.

Two detection strategies are provided:

1. **Citation check** (lightweight, rule-based) -- verifies that claims
   reference sources present in the input context.
2. **Overlap check** (lightweight, token-based) -- measures lexical overlap
   between output and source material.

For higher sentence-level accuracy or LLM-judge support, pair this with
:class:`HallucinationGuardrail`.

Usage::

    from agentic_blueprint.governance.guardrails import GroundingGuardrail

    # Block if < 40% of output sentences overlap with source material
    guardrail = GroundingGuardrail(min_overlap=0.4, block=True)
    graph.add_guards(guardrail)

    # Or use citation checking (output must reference source titles/URLs)
    guardrail = GroundingGuardrail(
        require_citations=True,
        citation_patterns=["wikipedia.org", "arxiv.org"],
    )
"""

from __future__ import annotations

import logging
import re
from typing import Awaitable, Callable, Sequence

from agentic_blueprint.exceptions import GuardrailBlockedError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guardrails._text_utils import (
    compute_word_overlap,
    extract_output_text,
    extract_source_text,
    sentence_tokenize,
    tokenize_words,
)
from agentic_blueprint.governance.guardrails.base import (
    Guardrail,
    GuardrailAction,
    GuardrailResult,
)

logger = logging.getLogger(__name__)

# Fraction of a sentence's words that must appear in source material
# for that sentence to be considered "grounded".
_SENTENCE_GROUNDED_THRESHOLD: float = 0.4

# Minimum sentence length (chars) for this guardrail.
# Kept at 10 to preserve original behaviour; HallucinationGuardrail uses 15.
_MIN_SENTENCE_LENGTH: int = 10


class GroundingGuardrail(Guardrail):
    """Check that LLM output is grounded in source material.

    Focuses on **citation presence** and **lexical overlap**.
    For sentence-level faithfulness scoring and optional LLM-judge support,
    see :class:`HallucinationGuardrail`.

    Operates on ``output_state`` from the execution context.  Source
    material is read from configurable state keys.
    """

    def __init__(
        self,
        *,
        min_overlap: float = 0.2,
        require_citations: bool = False,
        citation_patterns: Sequence[str] = (),
        source_keys: Sequence[str] = ("research_notes", "documents", "sources", "context"),
        block: bool = False,
        block_response: str | None = None,
        llm_judge: Callable[[str, str], Awaitable[float]] | None = None,
        combine_strategy: str = "max",
        context_keys: list[str] | None = None,
        scan_context: bool = False,
    ) -> None:
        """
        Args:
            min_overlap: Minimum fraction of output sentences that must
                have lexical overlap with source material (0.0 - 1.0).
            require_citations: If ``True``, check that the output contains
                at least one citation matching ``citation_patterns``.
            citation_patterns: Substrings or regex patterns that count
                as valid citations (e.g. ``["wikipedia.org", "[\\d+]"]``).
            source_keys: State dict keys to look for source material in.
                All keys are searched and their content is concatenated.
            block: If ``True``, raise ``GuardrailBlockedError`` on failure.
                If ``False`` (default), log a warning and return REDACT.
            block_response: Custom user-facing message returned when the
                guardrail blocks.  Used by ``wrap()`` for soft-blocking.
            llm_judge: Optional async callable ``(sentence, source) -> float``
                that returns a grounding score in ``[0, 1]``.  Called per
                sentence alongside lexical overlap.
            combine_strategy: How to combine lexical and LLM scores when
                both are available.  ``"max"`` (default), ``"mean"``, or
                ``"llm_only"``.
        """
        self._min_overlap = min_overlap
        self._require_citations = require_citations
        self._citation_patterns = [
            re.compile(p) if _is_regex(p) else re.compile(re.escape(p))
            for p in citation_patterns
        ]
        self._source_keys = list(source_keys)
        self._block = block
        self._llm_judge = llm_judge
        self._block_response = block_response
        self._context_keys = context_keys
        self._scan_context = scan_context

        if combine_strategy not in ("max", "mean", "llm_only"):
            raise ValueError(
                f"Unknown combine_strategy '{combine_strategy}'. "
                "Choose from: max, mean, llm_only"
            )
        self._combine_strategy = combine_strategy

    async def evaluate(self, ctx: ExecutionContext) -> GuardrailResult:
        if not ctx.output_state:
            return GuardrailResult(guardrail=self.name, action=GuardrailAction.PASS)

        output_text = extract_output_text(
            ctx.output_state,
            context_keys=self._context_keys,
            scan_context=self._scan_context,
        )
        if not output_text:
            return GuardrailResult(guardrail=self.name, action=GuardrailAction.PASS)

        issues: list[str] = []

        # -- Citation check -------------------------------------
        if self._require_citations and self._citation_patterns:
            has_citation = any(
                p.search(output_text) for p in self._citation_patterns
            )
            if not has_citation:
                issues.append(
                    "No citations found matching required patterns: "
                    f"{[p.pattern for p in self._citation_patterns]}"
                )

        # -- Overlap check --------------------------------------
        # Collect from ALL source keys (stop_at_first=False) to maximise
        # coverage — consistent with this guardrail's original behaviour.
        source_text = extract_source_text(
            ctx.input_state,
            self._source_keys,
            stop_at_first=False,
        )
        if source_text and self._min_overlap > 0:
            overlap = await _compute_sentence_overlap(
                output_text,
                source_text,
                llm_judge=self._llm_judge,
                combine_strategy=self._combine_strategy,
            )
            # Store for audit / observability (mirrors HallucinationGuardrail)
            ctx.metadata["grounding_overlap"] = overlap
            if overlap < self._min_overlap:
                issues.append(
                    f"Low grounding overlap: {overlap:.1%} "
                    f"(minimum: {self._min_overlap:.1%})"
                )

        # -- Result ---------------------------------------------
        if not issues:
            return GuardrailResult(guardrail=self.name, action=GuardrailAction.PASS)

        detail = "; ".join(issues)
        if self._block:
            raise GuardrailBlockedError(guardrail=self.name, reason=detail, block_response=self._block_response)

        logger.warning("Grounding check issues (non-blocking): %s", detail)
        return GuardrailResult(
            guardrail=self.name,
            action=GuardrailAction.REDACT,
            detail=detail,
        )


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _is_regex(pattern: str) -> bool:
    """Heuristic: treat *pattern* as a regex if it contains metacharacters.

    Excludes literal ``.`` (common in domain names like ``arxiv.org``) from
    the metacharacter set — only ``\\.`` (escaped dot) triggers regex mode.
    """
    return bool(re.search(r"[\\[{()|*+?^$]", pattern))


def _combine_scores(lexical: float, llm: float | None, strategy: str) -> float:
    """Combine lexical and LLM scores according to the chosen strategy."""
    if llm is None:
        return lexical
    if strategy == "llm_only":
        return llm
    elif strategy == "mean":
        return (lexical + llm) / 2
    else:  # "max"
        return max(lexical, llm)


async def _compute_sentence_overlap(
    output_text: str,
    source_text: str,
    *,
    llm_judge: Callable[[str, str], Awaitable[float]] | None = None,
    combine_strategy: str = "max",
) -> float:
    """Return the fraction of output sentences grounded in *source_text*.

    A sentence is considered grounded when at least
    ``_SENTENCE_GROUNDED_THRESHOLD`` (40 %) of its words appear in the
    source material (after combining with optional LLM judge scores).

    Returns:
        Float in ``[0.0, 1.0]``.
        ``1.0`` when there are no sentences to check (trivially passes).
        ``1.0`` when there is no source material to compare against
        (consistent with ``compute_word_overlap`` — cannot penalise
        without evidence).
    """
    sentences = sentence_tokenize(output_text, min_length=_MIN_SENTENCE_LENGTH)
    if not sentences:
        return 1.0  # nothing to check → pass

    source_words = tokenize_words(source_text)
    if not source_words:
        return 1.0  # no source material → cannot penalise; skip check

    grounded_count = 0
    for s in sentences:
        lexical_score = compute_word_overlap(s, source_words)

        llm_score: float | None = None
        if llm_judge:
            try:
                llm_score = await llm_judge(s, source_text)
            except Exception:
                logger.warning(
                    "GroundingGuardrail LLM judge failed for sentence",
                    exc_info=True,
                )

        combined = _combine_scores(lexical_score, llm_score, combine_strategy)
        if combined >= _SENTENCE_GROUNDED_THRESHOLD:
            grounded_count += 1

    return grounded_count / len(sentences)
