"""Input PII detection guardrail.

Complements the existing :class:`OutputPIIGuardrail` (which scans
**output**) by catching PII *before* it reaches the LLM.  This prevents
personal data from being sent to external model endpoints in the first
place, satisfying GDPR "data minimisation" requirements.

Reuses the same regex patterns as the output PII detector for
consistency.  Teams can extend detection by adding custom patterns.

Usage::

    from agentic_blueprint.governance.guardrails import InputPIIGuardrail

    # Block on any PII in user input (default)
    guardrail = InputPIIGuardrail(block=True)

    # Warn only -- log the finding but don't block
    guardrail = InputPIIGuardrail(block=False)

    # Only scan for emails and IBANs
    guardrail = InputPIIGuardrail(detectors=["email", "iban_de"])
"""

from __future__ import annotations

import logging
import re
from typing import Awaitable, Callable, Sequence

from agentic_blueprint.exceptions import GuardrailBlockedError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guardrails.base import (
    Guardrail,
    GuardrailAction,
    GuardrailResult,
)
from agentic_blueprint.governance.guardrails._text_utils import extract_input_text as _extract_input_text

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# PII patterns (shared with pii_detector.py — kept in sync)
# ---------------------------------------------------------------------------

_BUILTIN_PATTERNS: dict[str, re.Pattern[str]] = {
    "email": re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+"),
    "phone": re.compile(r"\+?\d[\d\s\-]{8,}\d"),
    # Credit card: 4 groups of 4 digits (most common format), or 13-19 digits
    # with explicit separator structure to reduce false positives.
    "credit_card": re.compile(
        r"\b(?:\d{4}[ -]){3}\d{4}\b"         # 4-4-4-4 format (Visa/MC)
        r"|\b(?:\d{4}[ -]){2}\d{5}\b"        # 4-4-5 (Amex alt)
        r"|\b3[47]\d{2}[ -]?\d{6}[ -]?\d{5}\b"  # Amex (34xx/37xx)
    ),
    "iban_de": re.compile(r"\bDE\d{2}[ ]?\d{4}[ ]?\d{4}[ ]?\d{4}[ ]?\d{4}[ ]?\d{2}\b"),
    "ssn_us": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "passport": re.compile(r"\b[A-Z]{1,2}\d{6,9}\b"),
    "ipv4": re.compile(
        r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}"
        r"(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b"
    ),
}

ALL_DETECTORS = tuple(_BUILTIN_PATTERNS.keys())


# ---------------------------------------------------------------------------
# Guardrail
# ---------------------------------------------------------------------------


class InputPIIGuardrail(Guardrail):
    """Scan user input for PII before it reaches the LLM.

    Runs in the ``before_node`` phase.  When PII is detected the
    guardrail either blocks (raises ``GuardrailBlockedError``) or logs a
    warning, depending on the ``block`` parameter.

    Parameters
    ----------
    block : bool
        ``True`` (default) → raise ``GuardrailBlockedError``.
        ``False`` → log a warning and attach metadata only.
    detectors : sequence of str
        Which PII types to scan for.  Defaults to *all* built-in
        detectors.  Available: ``email``, ``phone``, ``credit_card``,
        ``iban_de``, ``ssn_us``, ``passport``, ``ipv4``.
    extra_patterns : dict mapping label → regex string
        Additional PII patterns to include.
    llm_judge : async callable ``(text) -> list[str]``, optional
        Returns a list of detected PII type labels.  Called **after**
        regex scanning to catch obfuscated or context-dependent PII
        that regex misses.  Skipped if ``None`` (default).
    """

    def __init__(
        self,
        *,
        block: bool = True,
        detectors: Sequence[str] | None = None,
        extra_patterns: dict[str, str] | None = None,
        llm_judge: Callable[[str], Awaitable[list[str]]] | None = None,
        block_response: str | None = None,
        context_keys: list[str] | None = None,
        scan_context: bool = False,
    ) -> None:
        self._block = block
        self._llm_judge = llm_judge
        self._block_response = block_response
        self._context_keys = context_keys
        self._scan_context = scan_context

        active = list(detectors or ALL_DETECTORS)
        extra = extra_patterns or {}

        # Only raise for unknown detectors that are NOT covered by
        # extra_patterns — callers can legitimately extend the detector
        # set by providing a custom regex under the same name.
        truly_unknown = set(active) - set(ALL_DETECTORS) - set(extra.keys())
        if truly_unknown:
            raise ValueError(
                f"Unknown PII detectors: {truly_unknown}. "
                f"Available built-ins: {', '.join(ALL_DETECTORS)}. "
                "Provide a regex in 'extra_patterns' to define a custom detector."
            )

        # Build the active pattern set
        self._patterns: dict[str, re.Pattern[str]] = {}
        for name in active:
            if name in _BUILTIN_PATTERNS:
                self._patterns[name] = _BUILTIN_PATTERNS[name]
        for label, regex_str in extra.items():
            self._patterns[label] = re.compile(regex_str)

    # -- before_node: INPUT scanning ----------------------------------------

    async def before_node(self, ctx: ExecutionContext) -> ExecutionContext:
        """Scan input state for PII before LLM processing."""
        input_text = _extract_input_text(
            ctx.input_state,
            context_keys=self._context_keys,
            scan_context=self._scan_context,
        )
        if not input_text:
            return ctx

        found: list[str] = []
        for label, pattern in self._patterns.items():
            if pattern.search(input_text):
                found.append(label)

        # LLM fallback: catch obfuscated PII that regex misses
        if self._llm_judge:
            try:
                llm_found = await self._llm_judge(input_text)
                for label in llm_found:
                    if label not in found:
                        found.append(label)
            except Exception:
                logger.warning(
                    "InputPIIGuardrail LLM judge call failed",
                    exc_info=True,
                )

        if found:
            types = ", ".join(sorted(set(found)))
            detail = f"PII detected in input: {types}"
            action = GuardrailAction.BLOCK if self._block else GuardrailAction.REDACT
            result = GuardrailResult(guardrail=self.name, action=action, detail=detail)
            ctx.metadata.setdefault("guardrail_results", []).append(result)

            if self._block:
                raise GuardrailBlockedError(
                    self.name, detail, block_response=self._block_response,
                )
            logger.warning("InputPIIGuardrail (warn-only): %s", detail)

        return ctx

    # -- after_node: passthrough -------------------------------------------

    async def evaluate(self, ctx: ExecutionContext) -> GuardrailResult:
        """No-op — all checks run in ``before_node``."""
        return GuardrailResult(
            guardrail=self.name,
            action=GuardrailAction.PASS,
            detail="Input PII check completed in before_node phase",
        )


# ---------------------------------------------------------------------------
# Text extraction
# ---------------------------------------------------------------------------
