"""Tool execution guardrail — full I/O validation for tool calls.

Validates that:

1. **Tool names** are on an explicit allow-list (prevents the LLM from
   inventing or calling unregistered tools).
2. **Tool arguments** are free of injection patterns (SQL injection,
   command injection, path traversal).
3. **Tool outputs** conform to expected schemas (optional).

This is the recommended guardrail for any agent that uses external tools
or MCP servers.

Usage::

    from agentic_blueprint.governance.guardrails import ToolExecutionGuardrail

    guardrail = ToolExecutionGuardrail(
        allowed_tools=["search", "calculator", "weather"],
        block=True,
    )

    # With output schema validation
    guardrail = ToolExecutionGuardrail(
        allowed_tools=["search"],
        output_validators={
            "search": lambda output: "results" in output,
        },
    )
"""

from __future__ import annotations

import logging
import re
from typing import Any, Awaitable, Callable, Sequence

from agentic_blueprint.exceptions import GuardrailBlockedError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guardrails.base import (
    Guardrail,
    GuardrailAction,
    GuardrailResult,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Argument injection patterns
# ---------------------------------------------------------------------------

_ARG_INJECTION_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    # SQL injection indicators
    (
        "sql_injection",
        re.compile(
            r"(\b(union\s+select|drop\s+table|insert\s+into|delete\s+from|"
            r"update\s+\w+\s+set|alter\s+table|exec\s*\(|execute\s+immediate|"
            r";\s*drop\s|;\s*delete\s|'\s*or\s+'?\d|'\s*or\s+''='|"
            r"--\s*$|/\*.*\*/)\b)",
            re.IGNORECASE,
        ),
    ),
    # Command injection indicators
    (
        "command_injection",
        re.compile(
            r"(;\s*(rm|del|cat|curl|wget|chmod|chown|sudo|sh|bash|cmd|powershell)\s|"
            r"\|\s*(sh|bash|cmd|powershell)|"
            r"`[^`]*`|"
            r"\$\([^)]+\)|"
            r"&&\s*(rm|del|cat|curl|wget|sudo))",
            re.IGNORECASE,
        ),
    ),
    # Path traversal
    (
        "path_traversal",
        re.compile(
            r"(\.\./|\.\.\\|%2e%2e%2f|%2e%2e/|\.\.%2f|"
            r"/etc/passwd|/etc/shadow|"
            r"C:\\Windows\\|C:\\System)",
            re.IGNORECASE,
        ),
    ),
    # SSRF / URL injection — covers loopback, link-local, RFC-1918 private
    # ranges (10.x, 172.16-31.x, 192.168.x) and cloud metadata endpoints.
    (
        "ssrf_attempt",
        re.compile(
            r"(https?://localhost|"
            r"https?://127\.|"
            r"https?://0\.0\.0\.0|"
            r"https?://\[::1\]|"
            r"https?://169\.254\.|"                 # link-local / AWS metadata
            r"https?://10\.|"                        # RFC-1918: 10.0.0.0/8
            r"https?://192\.168\.|"                  # RFC-1918: 192.168.0.0/16
            r"https?://172\.(1[6-9]|2\d|3[01])\.|"  # RFC-1918: 172.16-31.x
            r"file://|gopher://|dict://|ftp://localhost)",
            re.IGNORECASE,
        ),
    ),
]


# ---------------------------------------------------------------------------
# Guardrail
# ---------------------------------------------------------------------------


class ToolExecutionGuardrail(Guardrail):
    """Validate tool calls: tool names, argument safety, and output shape.

    Combines ``before_node`` (argument validation) and ``after_node``
    (output validation) checks.

    Parameters
    ----------
    allowed_tools : sequence of str, optional
        Explicit tool name allow-list.  If provided, any tool call to a
        tool not in the list is blocked.  If ``None`` (default), tool
        name validation is skipped.
    block : bool
        ``True`` (default) → raise ``GuardrailBlockedError``.
        ``False`` → log a warning and attach metadata only.
    check_arguments : bool
        Scan tool arguments for injection patterns (default ``True``).
    extra_arg_patterns : sequence of (name, regex_str) tuples
        Additional argument injection patterns.
    output_validators : dict mapping tool_name → callable
        ``(output_content: str) -> bool``. If the callable returns
        ``False``, the tool output is flagged.
    llm_judge : async callable ``(text) -> bool``, optional
        Called when regex argument scanning finds no injection.
        Receives the flattened argument text; returns ``True`` if
        injection is detected.  Useful for catching obfuscated attacks
        that bypass pattern matching.
    """

    def __init__(
        self,
        *,
        allowed_tools: Sequence[str] | None = None,
        block: bool = True,
        check_arguments: bool = True,
        extra_arg_patterns: Sequence[tuple[str, str]] | None = None,
        output_validators: dict[str, Callable[[str], bool]] | None = None,
        block_response: str | None = None,
        llm_judge: Callable[[str], Awaitable[bool]] | None = None,
    ) -> None:
        self._allowed_tools: set[str] | None = (
            set(allowed_tools) if allowed_tools is not None else None
        )
        self._block = block
        self._check_arguments = check_arguments
        self._output_validators = output_validators or {}
        self._block_response = block_response
        self._llm_judge = llm_judge

        # Compile argument patterns
        self._arg_patterns: list[tuple[str, re.Pattern[str]]] = list(
            _ARG_INJECTION_PATTERNS
        )
        for name, pat_str in extra_arg_patterns or []:
            self._arg_patterns.append((name, re.compile(pat_str, re.IGNORECASE)))

    # -- before_node: validate tool call ARGUMENTS --------------------------

    async def before_node(self, ctx: ExecutionContext) -> ExecutionContext:
        """Validate tool calls present in the input state."""
        tool_calls = _extract_tool_calls(ctx.input_state)
        if not tool_calls:
            return ctx

        violations: list[str] = []

        for tc in tool_calls:
            tool_name = tc.get("name", tc.get("function", {}).get("name", ""))
            args = tc.get("args", tc.get("function", {}).get("arguments", {}))

            # 1. Tool name allow-list check
            if self._allowed_tools is not None and tool_name not in self._allowed_tools:
                violations.append(f"unregistered_tool:{tool_name}")

            # 2. Argument injection scan
            if self._check_arguments and args:
                arg_text = _flatten_args(args)
                # Scan both raw and sanitised text for evasion resistance
                from agentic_blueprint.governance.guardrails._text_utils import sanitize_text
                arg_text_sanitized = sanitize_text(arg_text, leet=False)
                for label, pattern in self._arg_patterns:
                    if pattern.search(arg_text) or pattern.search(arg_text_sanitized):
                        violations.append(f"{label}:tool={tool_name}")

                # LLM secondary: called when regex found no injection
                if (
                    not any(v.startswith(("sql_", "command_", "path_", "ssrf_")) for v in violations)
                    and self._llm_judge
                ):
                    try:
                        is_injection = await self._llm_judge(arg_text)
                        if is_injection:
                            violations.append(f"llm_judge:tool={tool_name}")
                    except Exception:
                        logger.warning(
                            "ToolExecutionGuardrail LLM judge call failed",
                            exc_info=True,
                        )

        if violations:
            detail = f"Tool execution violations: {'; '.join(violations)}"
            action = GuardrailAction.BLOCK if self._block else GuardrailAction.REDACT
            result = GuardrailResult(guardrail=self.name, action=action, detail=detail)
            ctx.metadata.setdefault("guardrail_results", []).append(result)

            if self._block:
                raise GuardrailBlockedError(self.name, detail, block_response=self._block_response)
            logger.warning("ToolExecutionGuardrail (warn-only): %s", detail)

        return ctx

    # -- after_node: validate tool call OUTPUTS -----------------------------

    async def evaluate(self, ctx: ExecutionContext) -> GuardrailResult:
        """Validate tool outputs against registered validators."""
        if not self._output_validators or not ctx.output_state:
            return GuardrailResult(
                guardrail=self.name,
                action=GuardrailAction.PASS,
                detail="No output validators configured or no output",
            )

        tool_messages = _extract_tool_messages(ctx.output_state)
        failures: list[str] = []

        for tm in tool_messages:
            tool_name = tm.get("name", "")
            content = tm.get("content", "")
            validator = self._output_validators.get(tool_name)
            if validator and not validator(content):
                failures.append(f"output_schema:{tool_name}")

        if failures:
            detail = f"Tool output validation failed: {'; '.join(failures)}"
            if self._block:
                raise GuardrailBlockedError(self.name, detail, block_response=self._block_response)
            logger.warning("ToolExecutionGuardrail output check: %s", detail)
            return GuardrailResult(
                guardrail=self.name,
                action=GuardrailAction.REDACT,
                detail=detail,
            )

        return GuardrailResult(
            guardrail=self.name,
            action=GuardrailAction.PASS,
            detail="Tool outputs valid",
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_tool_calls(state: dict[str, Any]) -> list[dict[str, Any]]:
    """Extract tool call dicts from input state.

    Only extracts tool calls from the **last** assistant message to avoid
    re-validating calls from earlier turns in multi-turn conversations.
    Also checks for a top-level ``tool_calls`` key.
    """
    calls: list[dict[str, Any]] = []

    # Top-level tool_calls
    top_level = state.get("tool_calls", [])
    if isinstance(top_level, list):
        calls.extend(top_level)

    # Look inside messages for the LAST AI message with tool_calls
    messages = state.get("messages", [])
    if hasattr(messages, "value"):
        messages = messages.value
    if isinstance(messages, list):
        last_calls: list[dict[str, Any]] = []
        for msg in messages:
            msg_calls: list[dict[str, Any]] = []
            if isinstance(msg, dict):
                if msg.get("role") == "assistant":
                    msg_calls = msg.get("tool_calls", [])
            elif hasattr(msg, "tool_calls"):
                msg_calls = getattr(msg, "tool_calls", []) or []
            if isinstance(msg_calls, list) and msg_calls:
                last_calls = msg_calls  # keep overwriting → ends with last
        calls.extend(last_calls)

    return calls


def _extract_tool_messages(state: dict[str, Any] | None) -> list[dict[str, Any]]:
    """Extract tool response messages from output state.

    Only extracts tool messages that appear **after** the last assistant
    message (i.e., the responses to the most recent tool calls). This
    avoids re-validating tool outputs from earlier turns.
    """
    if not state:
        return []

    messages = state.get("messages", [])
    if hasattr(messages, "value"):
        messages = messages.value
    if not isinstance(messages, list):
        return []

    # Find the index of the last assistant message
    last_assistant_idx = -1
    for i, msg in enumerate(messages):
        if isinstance(msg, dict) and msg.get("role") == "assistant":
            last_assistant_idx = i
        elif hasattr(msg, "type") and getattr(msg, "type", "") in ("ai", "assistant"):
            last_assistant_idx = i

    # Only collect tool messages after the last assistant message
    results: list[dict[str, Any]] = []
    for msg in messages[last_assistant_idx + 1:] if last_assistant_idx >= 0 else []:
        if isinstance(msg, dict) and msg.get("role") == "tool":
            results.append(msg)
        elif hasattr(msg, "type") and getattr(msg, "type", "") == "tool":
            results.append(
                {
                    "name": getattr(msg, "name", ""),
                    "content": getattr(msg, "content", ""),
                }
            )
    return results


def _flatten_args(args: Any, *, _depth: int = 0) -> str:
    """Flatten tool call arguments to a single string for regex scanning.

    A recursion depth limit of 20 prevents ``RecursionError`` on deeply
    nested or circular arguments.
    """
    if _depth > 20:
        return str(args)
    if isinstance(args, str):
        return args
    if isinstance(args, dict):
        parts: list[str] = []
        for v in args.values():
            parts.append(_flatten_args(v, _depth=_depth + 1))
        return " ".join(parts)
    if isinstance(args, (list, tuple)):
        return " ".join(_flatten_args(item, _depth=_depth + 1) for item in args)
    return str(args)
