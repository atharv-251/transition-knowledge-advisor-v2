"""Abstract base for guardrails.

Guardrails run in the ``after_node`` phase.  They inspect the output state
and can **block** (raise ``GuardrailBlockedError``) or **redact** (mutate the
output in-place).

Each guardrail returns a ``GuardrailResult`` indicating the action taken.

Changes
-------
* ``GuardrailResult`` now carries a ``timestamp`` (UTC epoch float) so every
  audit record is independently time-stamped.
* ``after_node`` only appends results to ``guardrail_results`` when the action
  is not ``PASS``, avoiding noisy no-op entries from before_node-only
  guardrails whose ``evaluate()`` unconditionally returns PASS.
  Guardrails that want to record a PASS (e.g. for explicit auditability)
  can call ``_append_result`` directly.
"""

from __future__ import annotations

import abc
import time
from dataclasses import dataclass, field
from enum import Enum

from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guards import GovernanceGuard


class GuardrailAction(str, Enum):
    PASS = "pass"
    REDACT = "redact"
    BLOCK = "block"


@dataclass(frozen=True)
class GuardrailResult:
    guardrail: str
    action: GuardrailAction
    detail: str = ""
    # When set, the governance layer returns this message instead of
    # raising ``GuardrailBlockedError``.
    block_response: str | None = None
    # UTC epoch timestamp — set automatically; lets audit logs correlate
    # results with external trace spans without relying on log timestamps.
    timestamp: float = field(default_factory=time.time)


class Guardrail(GovernanceGuard, abc.ABC):
    """Abstract guardrail -- runs after every node by default."""

    @abc.abstractmethod
    async def evaluate(self, ctx: ExecutionContext) -> GuardrailResult:
        """Evaluate the output and return the action taken."""

    # -- helpers -----------------------------------------------------------

    @staticmethod
    def _append_result(ctx: ExecutionContext, result: GuardrailResult) -> None:
        """Append *result* to ``ctx.metadata["guardrail_results"]``.

        Call this from ``before_node`` / ``evaluate`` whenever you want a
        result recorded regardless of action (including PASS).
        """
        ctx.metadata.setdefault("guardrail_results", []).append(result)

    # -- lifecycle ---------------------------------------------------------

    async def after_node(self, ctx: ExecutionContext) -> ExecutionContext:
        result = await self.evaluate(ctx)
        # Only append non-PASS results to keep the audit trail signal-rich.
        # Before-node-only guardrails return a vacuous PASS from evaluate();
        # recording those would inflate the results list with noise.
        if result.action != GuardrailAction.PASS:
            self._append_result(ctx, result)
        return ctx
