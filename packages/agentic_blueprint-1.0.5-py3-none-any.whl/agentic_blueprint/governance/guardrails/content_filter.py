"""Keyword-based content filter guardrail.

A simple blocklist / allowlist filter that scans input and output messages
for prohibited terms based on a keyword matching system.  For richer
toxicity detection, teams should implement a model-backed guardrail using
the same ``Guardrail`` interface.

The script is a TEMPLATE/TOOL — it defines how to block words, but the 
actual list of words must be provided by whoever uses this script in their application.

Design decisions
~~~~~~~~~~~~~~~~
- **Bidirectional scanning** — runs in ``before_node`` (user input) *and*
  ``after_node`` (LLM output) so blocked terms are caught regardless of
  origin.  Set ``scan_input=False`` to restore the output-only behaviour.
"""

from __future__ import annotations

import logging
import re
from typing import Awaitable, Callable

from agentic_blueprint.exceptions import GuardrailBlockedError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guardrails._text_utils import (
    extract_input_text,
    extract_output_text,
    sanitize_text as _sanitize_text,
)
from agentic_blueprint.governance.guardrails.base import (
    Guardrail,
    GuardrailAction,
    GuardrailResult,
)

logger = logging.getLogger(__name__)


class ContentFilterGuardrail(Guardrail):
    """Block output containing any of the configured prohibited terms."""

    def __init__(
        self,
        blocked_terms: list[str] | None = None,
        *,
        block: bool = True,
        block_response: str | None = None,
        scan_input: bool = True,
        llm_judge: Callable[[str], Awaitable[bool]] | None = None,
        context_keys: list[str] | None = None,
        scan_context: bool = False,
    ) -> None:
        """
        Args:
            blocked_terms: Case-insensitive terms to block.
                           If ``None`` or empty, the filter is a no-op.
            block: If ``True`` (default), raise ``GuardrailBlockedError``.
                   If ``False``, log a warning and return REDACT.
            block_response: If set, return this message instead of raising.
            scan_input: If ``True`` (default), scan user input in
                ``before_node``. Set to ``False`` for output-only mode
                (restores legacy behaviour).
            llm_judge: Optional async callable ``(text) -> bool``.
                       Called when keyword matching finds no violation.
                       Returns ``True`` if the content should be blocked.
            context_keys: Explicit list of context keys to scan in addition
                to messages.
            scan_context: If ``True``, scan ALL string values in the output
                context (excluding framework internals).
        """
        self._block = block
        self._block_response = block_response
        self._scan_input = scan_input
        self._llm_judge = llm_judge
        self._context_keys = context_keys
        self._scan_context = scan_context
        terms = blocked_terms or []
        if terms:
            # Use word boundaries to avoid substring matches
            # (e.g. "ass" matching "assistant")
            escaped = [rf"\b{re.escape(t)}\b" for t in terms]
            self._pattern: re.Pattern[str] | None = re.compile(
                "|".join(escaped), re.IGNORECASE
            )
        else:
            self._pattern = None

    # -- before_node: INPUT scan -------------------------------------------

    async def before_node(self, ctx: ExecutionContext) -> ExecutionContext:
        """Scan user input for blocked terms before it reaches the LLM."""
        if not self._scan_input or (self._pattern is None and self._llm_judge is None):
            return ctx

        input_text = extract_input_text(
            ctx.input_state,
            context_keys=self._context_keys,
            scan_context=self._scan_context,
        )
        if not input_text:
            return ctx

        # Scan both raw and sanitised text to catch evasion attempts
        sanitized = _sanitize_text(input_text, leet=True)
        matched = self._pattern.search(input_text) or self._pattern.search(sanitized) if self._pattern else False

        if matched:
            detail = "Blocked content detected in input"
            result = GuardrailResult(
                guardrail=self.name,
                action=GuardrailAction.BLOCK if self._block else GuardrailAction.REDACT,
                detail=detail,
            )
            self._append_result(ctx, result)
            if self._block:
                raise GuardrailBlockedError(
                    self.name, detail, block_response=self._block_response,
                )
            logger.warning("ContentFilterGuardrail input scan (warn-only): %s", detail)

        # LLM secondary: called when keyword check found nothing
        if not matched and self._llm_judge:
            try:
                should_block = await self._llm_judge(input_text)
                if should_block:
                    detail = "Blocked content detected in input by LLM judge"
                    result = GuardrailResult(
                        guardrail=self.name,
                        action=GuardrailAction.BLOCK if self._block else GuardrailAction.REDACT,
                        detail=detail,
                    )
                    self._append_result(ctx, result)
                    if self._block:
                        raise GuardrailBlockedError(
                            self.name, detail, block_response=self._block_response,
                        )
                    logger.warning(
                        "ContentFilterGuardrail LLM judge input scan (warn-only): %s", detail,
                    )
            except GuardrailBlockedError:
                raise
            except Exception:
                logger.warning(
                    "ContentFilterGuardrail LLM judge call failed (input scan)",
                    exc_info=True,
                )

        return ctx

    # -- after_node: OUTPUT scan via evaluate() ----------------------------

    async def evaluate(self, ctx: ExecutionContext) -> GuardrailResult:
        if self._pattern is None or not ctx.output_state:
            return GuardrailResult(
                guardrail=self.name, action=GuardrailAction.PASS
            )

        # Use shared extract_output_text which filters by assistant role
        output_text = extract_output_text(
            ctx.output_state,
            context_keys=self._context_keys,
            scan_context=self._scan_context,
        )
        if not output_text:
            return GuardrailResult(
                guardrail=self.name, action=GuardrailAction.PASS
            )

        # Scan both raw and sanitised text to catch evasion attempts
        sanitized = _sanitize_text(output_text, leet=True)
        matched = self._pattern.search(output_text) or self._pattern.search(sanitized) if self._pattern else False

        if matched:
            # Do NOT echo matched terms — they may contain user input
            # and would create an uncontrolled information-leakage channel.
            detail = "Blocked content detected in output"
            if self._block:
                raise GuardrailBlockedError(
                    guardrail=self.name, reason=detail,
                    block_response=self._block_response,
                )
            logger.warning("ContentFilterGuardrail (non-blocking): %s", detail)
            return GuardrailResult(
                guardrail=self.name, action=GuardrailAction.REDACT, detail=detail,
            )

        # LLM secondary: called when keyword check found nothing
        if self._llm_judge:
            try:
                should_block = await self._llm_judge(output_text)
                if should_block:
                    detail = "Blocked content detected by LLM judge"
                    if self._block:
                        raise GuardrailBlockedError(
                            guardrail=self.name, reason=detail,
                            block_response=self._block_response,
                        )
                    logger.warning("ContentFilterGuardrail LLM judge (non-blocking): %s", detail)
                    return GuardrailResult(
                        guardrail=self.name, action=GuardrailAction.REDACT, detail=detail,
                    )
            except GuardrailBlockedError:
                raise
            except Exception:
                logger.warning(
                    "ContentFilterGuardrail LLM judge call failed",
                    exc_info=True,
                )

        return GuardrailResult(
            guardrail=self.name, action=GuardrailAction.PASS
        )
