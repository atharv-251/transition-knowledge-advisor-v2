"""HITL strategy abstraction — framework-specific pause/resume mechanisms.

Every agentic framework has a different primitive for human-in-the-loop
interaction:

* **LangGraph**: ``interrupt()`` + checkpointer + ``Command(resume=...)``
* **CrewAI / AutoGen / SmolAgents**: blocking callback / async future
* **Semantic Kernel**: function invocation filter with ``terminate=True``
* **LlamaIndex Workflows**: ``InputRequiredEvent`` / ``HumanResponseEvent``

This module provides:

1. :class:`HITLPayload` — a framework-agnostic data object carrying all
   information the human reviewer needs.
2. :class:`HITLStrategy` — an abstract base that each framework adapter
   implements to translate the generic payload into the framework's own
   pause/resume mechanism.
3. Concrete strategy implementations:

   * :class:`LangGraphHITLStrategy` — calls ``interrupt()``
   * :class:`BlockingHITLStrategy` — ``asyncio.Future``-based, works for
     any framework that can await a decision (CrewAI, AutoGen, SmolAgents)
   * :class:`NoOpHITLStrategy` — logs a warning and continues (fallback
     when no framework adapter is active)

Framework adapters inject the appropriate strategy into
:class:`~agentic_blueprint.governance.guardrails.human_review.HumanReviewGuard`
at construction time so the guardrail itself stays framework-agnostic.
"""

from __future__ import annotations

import abc
import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Payload — framework-agnostic review request
# ---------------------------------------------------------------------------


@dataclass
class HITLPayload:
    """Data object describing what the human should review.

    This is the common denominator shared by all HITL strategies.
    Each strategy may augment or transform it before presenting to
    the underlying framework.
    """

    guard: str
    node: str
    agent: str
    phase: str  # "before" | "after"
    instructions: str
    require_approval: bool = True
    output_preview: str | None = None
    governance_state: dict[str, Any] | None = None
    step_count: int = 0
    total_tokens: int = 0
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-friendly dict."""
        return {
            "type": "human_review",
            "guard": self.guard,
            "node": self.node,
            "agent": self.agent,
            "phase": self.phase,
            "instructions": self.instructions,
            "require_approval": self.require_approval,
            "output_preview": self.output_preview,
            "governance_state": self.governance_state,
            "step_count": self.step_count,
            "total_tokens": self.total_tokens,
            **self.extra,
        }


# ---------------------------------------------------------------------------
# Abstract strategy
# ---------------------------------------------------------------------------


class HITLStrategy(abc.ABC):
    """Framework-specific mechanism for pausing execution for human review.

    Subclasses implement :meth:`pause` using whatever primitive the
    target framework provides (interrupt, future, event, filter, etc.).
    """

    @abc.abstractmethod
    async def pause(self, payload: HITLPayload) -> None:
        """Pause execution and present *payload* to a human reviewer.

        The method may:
        * **raise** an exception that exits the current execution
          (checkpoint-based, e.g. LangGraph ``GraphInterrupt``),
        * **await** an external decision (blocking-based, e.g. asyncio
          future), or
        * **set a flag** for the framework to inspect (filter-based,
          e.g. Semantic Kernel).

        Parameters
        ----------
        payload : HITLPayload
            All information the reviewer needs to make a decision.
        """
        ...


# ---------------------------------------------------------------------------
# LangGraph strategy — checkpoint-based (non-blocking exit)
# ---------------------------------------------------------------------------


class LangGraphHITLStrategy(HITLStrategy):
    """Pause via LangGraph ``interrupt()`` + checkpointer.

    The graph exits cleanly, state is persisted by the checkpointer,
    and a subsequent ``ainvoke(Command(resume=...))`` call resumes
    execution from where it left off.
    """

    async def pause(self, payload: HITLPayload) -> None:
        try:
            from langgraph.types import interrupt
        except ImportError:
            logger.warning(
                "LangGraphHITLStrategy requires langgraph; "
                "interrupt() not available — skipping."
            )
            return

        logger.info(
            "LangGraphHITLStrategy: interrupting at node '%s' (phase=%s)",
            payload.node,
            payload.phase,
        )

        try:
            interrupt(payload.to_dict())
        except RuntimeError:
            # Outside LangGraph runnable context (e.g. unit tests) —
            # fall back to raising GraphInterrupt directly.
            from langgraph.errors import GraphInterrupt

            raise GraphInterrupt([payload.to_dict()])


# ---------------------------------------------------------------------------
# Blocking strategy — asyncio.Future-based (CrewAI, AutoGen, SmolAgents)
# ---------------------------------------------------------------------------


class BlockingHITLStrategy(HITLStrategy):
    """Pause by awaiting an ``asyncio.Future`` that external code resolves.

    This works for any framework where execution can be suspended via
    ``await`` (CrewAI callbacks, AutoGen ``human_input_mode``, SmolAgents
    step callbacks, etc.).

    The :meth:`pause` call blocks the current task until
    :meth:`submit_decision` is called from an external context (UI,
    API handler, webhook, etc.).

    Usage::

        strategy = BlockingHITLStrategy()

        # In the governed execution (automatic via HumanReviewGuard):
        await strategy.pause(payload)      # blocks here

        # From external code (API route, UI callback, etc.):
        strategy.submit_decision("thread-1", "approved")
    """

    def __init__(self) -> None:
        # Keyed by thread_id / review_id → (payload, future)
        self._pending: dict[str, tuple[HITLPayload, asyncio.Future[str]]] = {}

    async def pause(self, payload: HITLPayload) -> None:
        review_id = f"{payload.agent}:{payload.node}:{payload.step_count}"
        loop = asyncio.get_running_loop()
        future: asyncio.Future[str] = loop.create_future()
        self._pending[review_id] = (payload, future)

        logger.info(
            "BlockingHITLStrategy: awaiting human decision for review_id='%s'",
            review_id,
        )

        try:
            decision = await future
        finally:
            self._pending.pop(review_id, None)

        if payload.require_approval and decision not in ("approved", "approve"):
            from agentic_blueprint.exceptions import GovernanceError

            raise GovernanceError(
                f"Human reviewer rejected at node '{payload.node}': {decision}"
            )

        logger.info(
            "BlockingHITLStrategy: human approved review_id='%s'",
            review_id,
        )

    def submit_decision(self, review_id: str, decision: str) -> None:
        """Resolve a pending review, unblocking the paused execution.

        Parameters
        ----------
        review_id : str
            The key matching ``{agent}:{node}:{step_count}``.
        decision : str
            The human's decision (e.g. ``"approved"``, ``"rejected"``,
            or free-text feedback).

        Raises
        ------
        KeyError
            If no pending review exists for *review_id*.
        """
        entry = self._pending.get(review_id)
        if entry is None:
            raise KeyError(
                f"No pending review with id '{review_id}'. "
                f"Active reviews: {list(self._pending.keys())}"
            )
        _, future = entry
        if not future.done():
            future.set_result(decision)

    @property
    def pending_reviews(self) -> dict[str, HITLPayload]:
        """Return a snapshot of all currently pending reviews."""
        return {k: v[0] for k, v in self._pending.items()}


# ---------------------------------------------------------------------------
# NoOp strategy — fallback when no framework adapter is wired
# ---------------------------------------------------------------------------


class NoOpHITLStrategy(HITLStrategy):
    """Logs a warning and continues — used when no framework is detected.

    This prevents silent failures when ``HumanReviewGuard`` is used
    without a framework adapter that provides a real strategy.
    """

    async def pause(self, payload: HITLPayload) -> None:
        logger.warning(
            "NoOpHITLStrategy: HumanReviewGuard triggered at node '%s' but "
            "no framework-specific HITL strategy is configured. "
            "The guard will be skipped. Wrap your agent with a framework "
            "adapter (e.g. wrap(graph, ...)) to enable HITL.",
            payload.node,
        )
