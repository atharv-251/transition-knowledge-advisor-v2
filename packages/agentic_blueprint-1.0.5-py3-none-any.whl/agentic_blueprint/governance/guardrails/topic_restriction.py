"""Topic restriction guardrail.

Keeps agents on-topic by matching user input against allowed and/or
blocked topic keywords.  Runs in the ``before_node`` phase to intercept
off-topic queries before they consume LLM tokens.

The guardrail supports two complementary modes:

- **allow-list** — only inputs matching at least one allowed topic are
  accepted.  Everything else is blocked.
- **block-list** — inputs matching any blocked topic are rejected.
  Everything else passes.

When both lists are provided, the **block-list is checked first** (a
blocked topic always loses), then the allow-list kicks in.

An optional LLM judge can classify ambiguous inputs that don't match
any keyword.

Usage::

    from agentic_blueprint.governance.guardrails import TopicRestrictionGuardrail

    # Allow-list mode: only automotive topics allowed
    guardrail = TopicRestrictionGuardrail(
        allowed_topics=["automotive", "vehicles", "car engineering", "EV"],
    )

    # Block-list mode: reject politics and religion
    guardrail = TopicRestrictionGuardrail(
        blocked_topics=["politics", "election", "religion", "theology"],
    )

    # Combined: allow automotive, but block competitor intelligence
    guardrail = TopicRestrictionGuardrail(
        allowed_topics=["automotive", "EV", "manufacturing"],
        blocked_topics=["competitor pricing", "stock trading"],
    )
"""

from __future__ import annotations

import logging
import re
from typing import Awaitable, Callable, Sequence

from agentic_blueprint.exceptions import GuardrailBlockedError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guardrails.base import (
    Guardrail,
    GuardrailAction,
    GuardrailResult,
)
from agentic_blueprint.governance.guardrails._text_utils import (
    extract_input_text as _extract_input_text,
    sanitize_text as _sanitize_text,
)

logger = logging.getLogger(__name__)


class TopicRestrictionGuardrail(Guardrail):
    """Restrict agent input to allowed topics / reject blocked topics.

    Runs in ``before_node``.  Keyword matching is case-insensitive with
    word-boundary awareness.

    Parameters
    ----------
    allowed_topics : sequence of str, optional
        Keywords/phrases that define on-topic input.  If provided, at
        least one must match for the input to proceed.
    blocked_topics : sequence of str, optional
        Keywords/phrases that define off-topic input.  If any match, the
        input is rejected regardless of allowed_topics.
    block : bool
        ``True`` (default) → raise ``GuardrailBlockedError``.
        ``False`` → log a warning and attach metadata only.
    llm_judge : async callable ``(text, topics) -> bool``, optional
        Called when keyword matching is inconclusive.  Receives the
        input text and a list of topic strings; should return ``True``
        if the input relates to the given topics.  Used for **both**
        blocked and allowed topic checks to catch semantic evasions
        that bypass regex matching.
    """

    def __init__(
        self,
        *,
        allowed_topics: Sequence[str] | None = None,
        blocked_topics: Sequence[str] | None = None,
        block: bool = True,
        llm_judge: Callable[[str, list[str]], Awaitable[bool]] | None = None,
        block_response: str | None = None,
        context_keys: list[str] | None = None,
        scan_context: bool = False,
    ) -> None:
        if not allowed_topics and not blocked_topics:
            raise ValueError(
                "Provide at least one of 'allowed_topics' or 'blocked_topics'"
            )

        self._allowed_patterns = _compile_topic_patterns(allowed_topics or [])
        self._blocked_patterns = _compile_topic_patterns(blocked_topics or [])
        self._allowed_labels = list(allowed_topics or [])
        self._blocked_labels = list(blocked_topics or [])
        self._block = block
        self._llm_judge = llm_judge
        self._block_response = block_response
        self._context_keys = context_keys
        self._scan_context = scan_context

    # -- before_node: INPUT topic check ------------------------------------

    async def before_node(self, ctx: ExecutionContext) -> ExecutionContext:
        """Check input text against topic restrictions."""
        input_text = _extract_input_text(
            ctx.input_state,
            context_keys=self._context_keys,
            scan_context=self._scan_context,
        )
        if not input_text:
            return ctx

        # Sanitise for evasion resistance (block-list matching)
        sanitized = _sanitize_text(input_text, leet=True)

        # 1. Check blocked topics first (always rejects)
        blocked_hits = [
            label
            for label, pattern in self._blocked_patterns
            if pattern.search(input_text) or pattern.search(sanitized)
        ]
        if blocked_hits:
            detail = f"Blocked topic detected: {', '.join(blocked_hits)}"
            return await self._handle_violation(ctx, detail)

        # 1b. LLM judge fallback for blocked topics — catches semantic
        #     evasions that bypass regex (e.g. "improvised explosive
        #     device" when "bomb" is blocked).
        if self._blocked_labels and self._llm_judge and not blocked_hits:
            try:
                matches_blocked = await self._llm_judge(
                    input_text, self._blocked_labels
                )
                if matches_blocked:
                    detail = (
                        "Blocked topic detected (LLM judge): input relates "
                        f"to restricted topics"
                    )
                    return await self._handle_violation(ctx, detail)
            except Exception:
                logger.warning(
                    "TopicRestrictionGuardrail LLM judge (blocked) failed",
                    exc_info=True,
                )

        # 2. Check allowed topics (if configured)
        if self._allowed_patterns:
            allowed_hits = [
                label
                for label, pattern in self._allowed_patterns
                if pattern.search(input_text) or pattern.search(sanitized)
            ]
            if not allowed_hits:
                # No keyword match — try LLM judge if available
                if self._llm_judge:
                    try:
                        is_on_topic = await self._llm_judge(
                            input_text, self._allowed_labels
                        )
                        if is_on_topic:
                            return ctx
                    except Exception:
                        logger.warning(
                            "TopicRestrictionGuardrail LLM judge failed",
                            exc_info=True,
                        )
                detail = (
                    f"Off-topic input — expected topics: "
                    f"{', '.join(self._allowed_labels)}"
                )
                return await self._handle_violation(ctx, detail)

        return ctx

    async def _handle_violation(
        self, ctx: ExecutionContext, detail: str
    ) -> ExecutionContext:
        """Record the violation and optionally block."""
        action = GuardrailAction.BLOCK if self._block else GuardrailAction.REDACT
        result = GuardrailResult(guardrail=self.name, action=action, detail=detail)
        ctx.metadata.setdefault("guardrail_results", []).append(result)

        if self._block:
            raise GuardrailBlockedError(self.name, detail, block_response=self._block_response)
        logger.warning("TopicRestrictionGuardrail (warn-only): %s", detail)
        return ctx

    # -- after_node: passthrough -------------------------------------------

    async def evaluate(self, ctx: ExecutionContext) -> GuardrailResult:
        """No-op — all checks run in ``before_node``."""
        return GuardrailResult(
            guardrail=self.name,
            action=GuardrailAction.PASS,
            detail="Topic check completed in before_node phase",
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _compile_topic_patterns(
    topics: Sequence[str],
) -> list[tuple[str, re.Pattern[str]]]:
    """Compile topic strings into word-boundary-aware regexes.

    Multi-word topics are matched as literal phrases (case-insensitive).
    Single words get ``\\b`` word boundaries.
    """
    patterns: list[tuple[str, re.Pattern[str]]] = []
    for topic in topics:
        escaped = re.escape(topic)
        # Use word boundaries for cleaner matching
        regex_str = rf"\b{escaped}\b"
        patterns.append((topic, re.compile(regex_str, re.IGNORECASE)))
    return patterns


# ---------------------------------------------------------------------------
# (No local _extract_input_text — uses shared _text_utils.extract_input_text)
