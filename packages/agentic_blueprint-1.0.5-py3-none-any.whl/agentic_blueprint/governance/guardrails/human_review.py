"""HumanReviewGuard — HITL governance guardrail.

Pauses execution at a designated node so a human can review, approve,
or modify the agent's output before execution continues.

The guard is **framework-agnostic**: it delegates the actual pause
mechanism to an :class:`~.hitl_strategy.HITLStrategy` instance that
is injected by the framework adapter (``GovernedGraph``,
``GovernedCrew``, etc.).

Usage::

    from agentic_blueprint.governance.guardrails import HumanReviewGuard

    governed = wrap(
        graph,
        name="approval-agent",
        scoped_guards={
            "draft_email": [
                HumanReviewGuard(
                    instructions="Review the drafted email before sending.",
                ),
            ],
        },
    )

    # First invocation -- stops at draft_email
    result = await governed.ainvoke(state, config={"configurable": {"thread_id": "t1"}})
    # result contains the draft; agent is paused

    # Human reviews ... then resume:
    result = await governed.ainvoke(
        Command(resume="approved"),
        config={"configurable": {"thread_id": "t1"}},
    )

The guard works as an ``after_node`` hook: it lets the node execute,
then interrupts with the node's output for review.  This way the human
sees the actual result before deciding.

For ``before_node`` interrupts (gate BEFORE execution), set
``phase="before"``.

Strategy injection
------------------
Framework adapters auto-inject the appropriate strategy:

* ``GovernedGraph`` → :class:`LangGraphHITLStrategy`
* ``GovernedCrew`` → :class:`BlockingHITLStrategy`

If no strategy is set, the guard uses :class:`NoOpHITLStrategy` which
logs a warning and skips the interrupt.  This is a safe fallback that
makes misconfiguration visible rather than silent.
"""

from __future__ import annotations

import logging
from typing import Any

from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guards import GovernanceGuard
from agentic_blueprint.governance.guardrails.hitl_strategy import (
    HITLPayload,
    HITLStrategy,
    NoOpHITLStrategy,
)

logger = logging.getLogger(__name__)


class HumanReviewGuard(GovernanceGuard):
    """Pause execution for human review via a pluggable HITL strategy.

    Parameters
    ----------
    instructions : str
        Instructions shown to the human reviewer describing what to
        review and what actions are available.
    phase : str
        When to interrupt: ``"after"`` (default) lets the node run first
        so the human sees the output; ``"before"`` interrupts before the
        node executes (approval gate).
    require_approval : bool
        If ``True`` (default), the resume value must be ``"approved"``
        or a non-empty string to continue.  If ``False``, any resume
        value (including empty) continues execution.
    strategy : HITLStrategy | None
        The framework-specific pause mechanism.  When ``None``
        (the default), a :class:`NoOpHITLStrategy` is used which logs
        a warning.  Framework adapters auto-inject the correct strategy
        at construction time.
    name : str
        Guard name for audit/logging.
    """

    def __init__(
        self,
        *,
        instructions: str = "Please review the agent output before proceeding.",
        phase: str = "after",
        require_approval: bool = True,
        strategy: HITLStrategy | None = None,
        name: str = "HumanReviewGuard",
    ) -> None:
        self._instructions = instructions
        self._phase = phase
        self._require_approval = require_approval
        self._strategy = strategy or NoOpHITLStrategy()
        self._name = name

    @property
    def name(self) -> str:
        return self._name

    @property
    def strategy(self) -> HITLStrategy:
        """The active HITL strategy."""
        return self._strategy

    @strategy.setter
    def strategy(self, value: HITLStrategy) -> None:
        """Allow framework adapters to inject a strategy post-construction."""
        self._strategy = value

    async def before_node(self, ctx: ExecutionContext) -> ExecutionContext:
        """Interrupt before node execution if phase='before'."""
        if self._phase == "before":
            await self._do_interrupt(ctx, output_preview=None)
        return ctx

    async def after_node(self, ctx: ExecutionContext) -> ExecutionContext:
        """Interrupt after node execution if phase='after' (default)."""
        if self._phase == "after":
            output_preview = None
            if ctx.output_state and isinstance(ctx.output_state, dict):
                # Extract a human-readable preview of the output
                for key in ("response", "answer", "output", "messages"):
                    if key in ctx.output_state:
                        val = ctx.output_state[key]
                        if isinstance(val, str):
                            output_preview = val
                        elif isinstance(val, list) and val:
                            last = val[-1]
                            output_preview = (
                                getattr(last, "content", None)
                                or (last.get("content") if isinstance(last, dict) else None)
                                or str(last)
                            )
                        break
            await self._do_interrupt(ctx, output_preview=output_preview)
        return ctx

    async def _do_interrupt(
        self, ctx: ExecutionContext, *, output_preview: str | None
    ) -> None:
        """Build the HITL payload and delegate to the strategy."""
        # Serialize governance state for checkpoint persistence
        gov_ctx_data: dict[str, Any] | None = None
        try:
            from agentic_blueprint.core.governance_context import _get_governance_ctx
            gov_ctx = _get_governance_ctx()
            if gov_ctx is not None:
                gov_ctx_data = gov_ctx.to_checkpoint_data()
        except Exception:
            logger.warning("failed to retrieve governance context for HITL review", exc_info=True)

        payload = HITLPayload(
            guard=self._name,
            node=ctx.node_name,
            agent=ctx.agent_name,
            phase=self._phase,
            instructions=self._instructions,
            require_approval=self._require_approval,
            output_preview=output_preview,
            governance_state=gov_ctx_data,
            step_count=ctx.step_count,
            total_tokens=ctx.total_tokens,
        )

        logger.info(
            "HumanReviewGuard: triggering HITL at node '%s' (phase=%s, strategy=%s)",
            ctx.node_name,
            self._phase,
            type(self._strategy).__name__,
        )

        await self._strategy.pause(payload)
