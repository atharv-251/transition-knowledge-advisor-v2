"""Hallucination detection guardrail.

Runtime faithfulness check that verifies LLM output is grounded in
retrieved source material.  Complements the existing
:class:`GroundingGuardrail` (which checks citation presence and lexical
overlap) by adding **sentence-level entailment scoring**.

Two scoring strategies, composable:

1. **Lexical overlap** (default, zero-dependency) — for each output
   sentence, compute the fraction of content words that appear in the
   source material.  Fast and transparent.
2. **LLM judge** (optional) — send (source, claim) pairs to a
   fine-tuned model that returns a faithfulness score.  More accurate
   for paraphrases but adds latency.

Usage::

    from agentic_blueprint.governance.guardrails import HallucinationGuardrail

    # Lexical-only (default), warn on low faithfulness
    guardrail = HallucinationGuardrail(
        source_keys=["ab_sources", "context", "documents"],
        min_faithfulness=0.6,
        block=False,
    )

    # With LLM judge for higher accuracy
    async def faithfulness_judge(claim: str, source: str) -> float:
        # Call your entailment model, return score in [0, 1]
        ...

    guardrail = HallucinationGuardrail(
        llm_judge=faithfulness_judge,
        min_faithfulness=0.7,
    )
"""

from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable, Sequence

from agentic_blueprint.exceptions import GuardrailBlockedError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guardrails._text_utils import (
    compute_word_overlap,
    extract_output_text,
    extract_source_text,
    sentence_tokenize,
    tokenize_words,
)
from agentic_blueprint.governance.guardrails.base import (
    Guardrail,
    GuardrailAction,
    GuardrailResult,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Default configuration
# ---------------------------------------------------------------------------

_DEFAULT_SOURCE_KEYS: list[str] = [
    "ab_sources",
    "sources",
    "context",
    "documents",
    "retrieved_docs",
    "search_results",
]

# Minimum sentence length (characters) for this guardrail.
# Slightly stricter than GroundingGuardrail (10) to avoid scoring
# trivial one-word fragments against a full source corpus.
_MIN_SENTENCE_LENGTH: int = 15


# ---------------------------------------------------------------------------
# Guardrail
# ---------------------------------------------------------------------------


class HallucinationGuardrail(Guardrail):
    """Detect hallucinated content by measuring faithfulness to sources.

    Runs in the ``after_node`` phase.  Compares the LLM output against
    source material found in the state under configurable keys.

    Parameters
    ----------
    source_keys : sequence of str
        State keys to look for source/context material.  The first key
        that contains non-empty content is used (``stop_at_first=True``).
    min_faithfulness : float
        Minimum acceptable faithfulness score in ``[0, 1]``.  Below
        this threshold the output is flagged (default ``0.6``).
    block : bool
        ``True`` → raise ``GuardrailBlockedError``.
        ``False`` (default) → log a warning and attach metadata.
    word_overlap_threshold : float
        Per-sentence minimum word overlap ratio to consider a sentence
        grounded (default ``0.35``).
    llm_judge : async callable ``(claim, source) -> float``, optional
        If provided, each output sentence is scored by the LLM judge
        instead of (or in addition to) lexical overlap.
    combine_strategy : str
        How to combine lexical and LLM scores when both are available.
        ``"max"`` (default) — take the higher score (lenient).
        ``"mean"`` — average both scores.
        ``"llm_only"`` — ignore lexical score when LLM judge is present.
    """

    def __init__(
        self,
        *,
        source_keys: Sequence[str] | None = None,
        min_faithfulness: float = 0.6,
        block: bool = False,
        word_overlap_threshold: float = 0.35,
        llm_judge: Callable[[str, str], Awaitable[float]] | None = None,
        combine_strategy: str = "max",
        block_response: str | None = None,
        context_keys: list[str] | None = None,
        scan_context: bool = False,
    ) -> None:
        self._source_keys = list(source_keys or _DEFAULT_SOURCE_KEYS)
        self._min_faithfulness = min_faithfulness
        self._block = block
        self._word_overlap_threshold = word_overlap_threshold
        self._llm_judge = llm_judge
        self._block_response = block_response
        self._context_keys = context_keys
        self._scan_context = scan_context

        if combine_strategy not in ("max", "mean", "llm_only"):
            raise ValueError(
                f"Unknown combine_strategy '{combine_strategy}'. "
                "Choose from: max, mean, llm_only"
            )
        self._combine_strategy = combine_strategy

    async def evaluate(self, ctx: ExecutionContext) -> GuardrailResult:
        # -- Extract output text --------------------------------
        # Check output_state first; fall back to input_state for pipelines
        # where the answer is stored in the input by the time we run.
        output_text = extract_output_text(
            ctx.output_state,
            context_keys=self._context_keys,
            scan_context=self._scan_context,
        )
        if not output_text:
            return GuardrailResult(
                guardrail=self.name,
                action=GuardrailAction.PASS,
                detail="No output text to check",
            )

        # -- Extract source material ----------------------------
        # Merge both states so sources can live in either input_state
        # (documents passed in) or output_state (docs retrieved during run).
        all_state: dict[str, Any] = {
            **(ctx.input_state or {}),
            **(ctx.output_state or {}),
        }
        source_text = extract_source_text(
            all_state,
            self._source_keys,
            stop_at_first=True,
        )
        if not source_text:
            return GuardrailResult(
                guardrail=self.name,
                action=GuardrailAction.PASS,
                detail="No source material found — faithfulness check skipped",
            )

        # -- Tokenise -------------------------------------------
        sentences = sentence_tokenize(output_text, min_length=_MIN_SENTENCE_LENGTH)
        if not sentences:
            return GuardrailResult(
                guardrail=self.name,
                action=GuardrailAction.PASS,
                detail="No scorable sentences in output",
            )

        source_words = tokenize_words(source_text)

        # -- Score each sentence --------------------------------
        sentence_scores: list[float] = []
        for sentence in sentences:
            # Lexical overlap score via shared utility
            lexical_score = compute_word_overlap(sentence, source_words)

            # Optional LLM judge score
            llm_score: float | None = None
            if self._llm_judge:
                try:
                    llm_score = await self._llm_judge(sentence, source_text)
                except Exception:
                    logger.warning(
                        "HallucinationGuardrail LLM judge failed for sentence",
                        exc_info=True,
                    )

            sentence_scores.append(self._combine_scores(lexical_score, llm_score))

        # -- Aggregate ------------------------------------------
        grounded_count = sum(
            1 for s in sentence_scores if s >= self._word_overlap_threshold
        )
        faithfulness = grounded_count / len(sentence_scores)

        # -- Store detailed results in metadata -----------------
        ctx.metadata["hallucination_faithfulness"] = faithfulness
        ctx.metadata["hallucination_sentence_scores"] = sentence_scores
        ctx.metadata["hallucination_grounded_sentences"] = (
            f"{grounded_count}/{len(sentence_scores)}"
        )

        # -- Return result --------------------------------------
        if faithfulness >= self._min_faithfulness:
            return GuardrailResult(
                guardrail=self.name,
                action=GuardrailAction.PASS,
                detail=(
                    f"Faithfulness: {faithfulness:.2f} "
                    f"({grounded_count}/{len(sentence_scores)} sentences grounded)"
                ),
            )

        detail = (
            f"Low faithfulness: {faithfulness:.2f} "
            f"(threshold: {self._min_faithfulness:.2f}, "
            f"grounded: {grounded_count}/{len(sentence_scores)} sentences)"
        )
        if self._block:
            raise GuardrailBlockedError(self.name, detail, block_response=self._block_response)

        logger.warning("HallucinationGuardrail: %s", detail)
        return GuardrailResult(
            guardrail=self.name,
            action=GuardrailAction.REDACT,
            detail=detail,
        )

    def _combine_scores(self, lexical: float, llm: float | None) -> float:
        """Combine lexical and LLM scores according to the chosen strategy."""
        if llm is None:
            return lexical
        if self._combine_strategy == "llm_only":
            return llm
        elif self._combine_strategy == "mean":
            return (lexical + llm) / 2
        else:  # "max"
            return max(lexical, llm)
