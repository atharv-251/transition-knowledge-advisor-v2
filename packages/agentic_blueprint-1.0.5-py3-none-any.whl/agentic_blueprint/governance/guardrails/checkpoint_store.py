"""Governance checkpoint store — persist GovernanceCtx across HITL pauses.

LangGraph has its own checkpointer (PostgreSQL, SQLite) that automatically
persists graph state including the governance context embedded in the
interrupt payload.  Other frameworks (CrewAI, AutoGen, SmolAgents) have
no such mechanism.

This module provides a lightweight, pluggable checkpoint store that the
SDK uses to persist and restore :class:`GovernanceCtx` across HITL
pause/resume boundaries for non-LangGraph frameworks.

Included backends:

* :class:`InMemoryCheckpointStore` — ephemeral, for development/testing.

Example::

    store = InMemoryCheckpointStore()

    # On pause:
    store.save(thread_id, gov_ctx.to_checkpoint_data())

    # On resume:
    data = store.load(thread_id)
    gov_ctx = GovernanceCtx.from_checkpoint_data(data)
"""

from __future__ import annotations

import abc
import logging
import threading
from typing import Any

logger = logging.getLogger(__name__)


class GovernanceCheckpointStore(abc.ABC):
    """Abstract store for persisting GovernanceCtx across HITL pauses."""

    @abc.abstractmethod
    def save(self, thread_id: str, data: dict[str, Any]) -> None:
        """Persist checkpoint data keyed by *thread_id*."""
        ...

    @abc.abstractmethod
    def load(self, thread_id: str) -> dict[str, Any] | None:
        """Load checkpoint data for *thread_id*, or ``None`` if absent."""
        ...

    @abc.abstractmethod
    def delete(self, thread_id: str) -> None:
        """Remove checkpoint data for *thread_id* (cleanup after resume)."""
        ...


class InMemoryCheckpointStore(GovernanceCheckpointStore):
    """Thread-safe in-memory checkpoint store for development/testing."""

    def __init__(self) -> None:
        self._store: dict[str, dict[str, Any]] = {}
        self._lock = threading.Lock()

    def save(self, thread_id: str, data: dict[str, Any]) -> None:
        with self._lock:
            self._store[thread_id] = data
        logger.debug("Checkpoint saved: thread_id=%s", thread_id)

    def load(self, thread_id: str) -> dict[str, Any] | None:
        with self._lock:
            return self._store.get(thread_id)

    def delete(self, thread_id: str) -> None:
        with self._lock:
            self._store.pop(thread_id, None)
        logger.debug("Checkpoint deleted: thread_id=%s", thread_id)
