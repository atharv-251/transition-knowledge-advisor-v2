"""Shared text-processing utilities for grounding and hallucination guardrails.

All NLP helper functions live here so that ``grounding.py`` and
``hallucination.py`` share a single source of truth.  Any change to
tokenisation or extraction logic only needs to be made once.

Internal module — not part of the public API.
"""

from __future__ import annotations

import re
import unicodedata
from typing import Any


# ---------------------------------------------------------------------------
# Text sanitisation (anti-evasion)
# ---------------------------------------------------------------------------

# Zero-width and invisible Unicode characters that adversaries insert to
# break word-boundary matching.
_INVISIBLE_RE = re.compile(
    r"[\u200b\u200c\u200d\u200e\u200f"   # zero-width space/joiners/marks
    r"\u00ad"                              # soft hyphen
    r"\u2060\u2061\u2062\u2063\u2064"      # word joiner / invisible operators
    r"\ufeff"                              # zero-width no-break space (BOM)
    r"\u034f"                              # combining grapheme joiner
    r"\u061c"                              # Arabic letter mark
    r"\u180e"                              # Mongolian vowel separator
    r"]",
)

# Homoglyph / confusable mapping: common Cyrillic & special chars that
# visually resemble Latin letters.  Only the most frequently exploited
# substitutions are included to avoid over-normalisation.
_CONFUSABLES: dict[str, str] = {
    "\u0430": "a",  # Cyrillic а
    "\u0435": "e",  # Cyrillic е
    "\u043e": "o",  # Cyrillic о
    "\u0440": "p",  # Cyrillic р
    "\u0441": "c",  # Cyrillic с
    "\u0443": "y",  # Cyrillic у (lowercase)
    "\u0456": "i",  # Cyrillic і
    "\u0455": "s",  # Cyrillic ѕ
    "\u0458": "j",  # Cyrillic ј
    "\u04bb": "h",  # Cyrillic һ
    "\u0501": "d",  # Cyrillic ԁ
    "\u051b": "q",  # Cyrillic ԛ
    "\u051d": "w",  # Cyrillic ԝ
    "\u0410": "A",  # Cyrillic А (uppercase)
    "\u0412": "B",  # Cyrillic В
    "\u0415": "E",  # Cyrillic Е
    "\u041a": "K",  # Cyrillic К
    "\u041c": "M",  # Cyrillic М
    "\u041d": "H",  # Cyrillic Н
    "\u041e": "O",  # Cyrillic О
    "\u0420": "P",  # Cyrillic Р
    "\u0421": "C",  # Cyrillic С
    "\u0422": "T",  # Cyrillic Т
    "\u0425": "X",  # Cyrillic Х
    "\u2010": "-",  # hyphen
    "\u2011": "-",  # non-breaking hyphen
    "\u2012": "-",  # figure dash
    "\u2013": "-",  # en dash
    "\u2014": "-",  # em dash
    "\u2018": "'",  # left single quote
    "\u2019": "'",  # right single quote
    "\u201c": '"',  # left double quote
    "\u201d": '"',  # right double quote
    "\uff01": "!",  # fullwidth exclamation
    "\uff1a": ":",  # fullwidth colon
}

_CONFUSABLE_TRANS = str.maketrans(_CONFUSABLES)

# Leetspeak / character substitution mapping for security-sensitive scans.
_LEET: dict[str, str] = {
    "0": "o",
    "1": "i",
    "3": "e",
    "4": "a",
    "5": "s",
    "7": "t",
    "@": "a",
    "$": "s",
    "!": "i",
}

_LEET_TRANS = str.maketrans(_LEET)

# Detects space-separated single characters used to spell out words:
# "h e r o i n", "i g n o r e".
_SPACED_CHARS_RE = re.compile(r"\b([a-zA-Z])\s+(?=[a-zA-Z]\b)")


def sanitize_text(text: str, *, leet: bool = False) -> str:
    """Normalise text to defeat common evasion techniques.

    Applied transformations (in order):

    1. **NFKD Unicode normalisation** — decomposes ligatures, fullwidth
       chars, and compatibility forms into their ASCII equivalents.
    2. **Invisible character removal** — strips zero-width spaces, soft
       hyphens, byte-order marks, and other invisible Unicode.
    3. **Confusable / homoglyph mapping** — replaces visually-similar
       Cyrillic and special characters with their Latin equivalents.
    4. *(optional)* **Leetspeak decoding** — maps ``0→o, 1→i, 3→e, 4→a,
       5→s, 7→t, @→a, $→s, !→i``.  Only enabled for security-sensitive
       scans (injection, toxicity) via ``leet=True``.
    5. **Spaced-character collapsing** — joins ``"h e r o i n"`` →
       ``"heroin"``.
    6. **Whitespace normalisation** — collapses runs of whitespace into
       single spaces.

    The original text is **never** modified and is not used for display;
    the sanitised version is used only for pattern matching.

    Args:
        text: Raw input text.
        leet: Enable leetspeak decoding (default ``False``).

    Returns:
        Sanitised copy suitable for regex matching.
    """
    # 1. NFKD normalisation
    text = unicodedata.normalize("NFKD", text)

    # 2. Strip invisible characters
    text = _INVISIBLE_RE.sub("", text)

    # 3. Confusable mapping
    text = text.translate(_CONFUSABLE_TRANS)

    # 4. Leetspeak (optional — security-sensitive scans only)
    if leet:
        text = text.translate(_LEET_TRANS)

    # 5. Spaced-character collapsing ("h e r o i n" → "heroin")
    text = _SPACED_CHARS_RE.sub(r"\1", text)

    # 6. Whitespace normalisation
    text = re.sub(r"\s+", " ", text).strip()

    return text


# ---------------------------------------------------------------------------
# Sentence & word tokenisation
# ---------------------------------------------------------------------------


def sentence_tokenize(text: str, min_length: int = 10) -> list[str]:
    """Split *text* into sentences using punctuation and newline heuristics.

    No external NLP library is required.

    Splitting strategy (in order of priority):
    1. Standard sentence-ending punctuation (``. ! ?``) followed by
       whitespace.
    2. Paragraph breaks — one or more blank lines (``\\n\\n``) — so that
       bullet-point lists and multi-paragraph responses are properly
       segmented even when they lack terminal punctuation.
    3. Single newlines — each non-empty line is treated as an independent
       unit, which handles numbered lists and structured LLM output.

    Args:
        text:       Input text to split.
        min_length: Minimum character length for a sentence to be kept.
                    Shorter fragments (e.g. ``"OK."`` or ``"Yes!"``) are
                    discarded.  Both guardrails use different defaults
                    (10 for grounding, 15 for hallucination), so this is
                    exposed as a parameter rather than a constant.

    Returns:
        List of non-trivial sentence strings, de-duplicated by value.
    """
    # Step 1 — punctuation-based split
    punct_sentences = re.split(r"(?<=[.!?])\s+", text.strip())

    # Step 2 — within each punct-sentence, also split on newlines so that
    # paragraph/list structure is captured.
    raw: list[str] = []
    for sent in punct_sentences:
        # Split on one or more consecutive newlines
        for line in re.split(r"\n+", sent):
            raw.append(line.strip())

    # Deduplicate while preserving order, then apply min_length filter.
    seen: set[str] = set()
    result: list[str] = []
    for s in raw:
        if len(s) >= min_length and s not in seen:
            seen.add(s)
            result.append(s)
    return result


def tokenize_words(text: str) -> set[str]:
    """Extract unique, lowercase word tokens (2+ characters) from *text*.

    Single-character words (``"a"``, ``"I"`` …) are excluded because they
    appear in almost every sentence and would inflate overlap scores.
    Two-character words (``"AI"``, ``"EU"``, ``"VW"``, ``"UK"`` …) are kept
    because they carry domain significance for grounding checks.

    Returns:
        A ``set`` — no duplicates, O(1) membership checks via ``in``.
    """
    return set(re.findall(r"\b\w{2,}\b", text.lower()))


def compute_word_overlap(sentence: str, source_words: set[str]) -> float:
    """Compute the fraction of *sentence* words that appear in *source_words*.

    Args:
        sentence:     A single output sentence.
        source_words: Pre-computed word set from the full source material.

    Returns:
        Float in ``[0.0, 1.0]``.

        * ``1.0`` when the sentence contains no scorable words (trivially
          considered grounded — empty fragment can't contradict anything).
        * ``1.0`` when *source_words* is empty — no source material is
          available so the check cannot penalise the output.  This
          prevents the guardrail from incorrectly blocking responses when
          the source key is absent from the state.
        * Overlap ratio otherwise.

    Example::

        >>> compute_word_overlap("Berlin is the capital of Germany", tokenize_words("Berlin is the capital city of Germany"))
        1.0
    """
    words = tokenize_words(sentence)
    if not words:
        return 1.0  # trivial / empty sentence → grounded by default
    if not source_words:
        return 1.0  # no source material → cannot penalise; skip check
    return len(words & source_words) / len(words)


# ---------------------------------------------------------------------------
# State extraction helpers
# ---------------------------------------------------------------------------


def extract_messages(state: Any) -> list:
    """Normalise *state* into a flat list of message-like objects.

    Handles:
    * ``dict`` with a ``"messages"`` key (standard LangGraph state).
    * Plain ``list`` of messages.
    * ``Overwrite`` wrappers used by DeepAgents (objects with a ``.value``
      attribute).

    Returns:
        A list (possibly empty) of message dicts or message objects.
    """
    if hasattr(state, "value"):
        state = state.value
    if isinstance(state, dict):
        msgs = state.get("messages", [])
        if hasattr(msgs, "value"):  # nested Overwrite
            msgs = msgs.value
        return msgs if isinstance(msgs, list) else []
    if isinstance(state, list):
        return state
    return []


def extract_output_text(
    state: Any,
    *,
    context_keys: list[str] | None = None,
    scan_context: bool = False,
) -> str:
    """Extract assistant / AI text from an output state object.

    Only the **last** assistant/AI message is extracted from the messages
    list.  Previous assistant messages have already been evaluated by
    guardrails when they were first generated — re-scanning them would
    cause false positives in multi-turn conversational flows.

    Checks (in order):
    1. The **last** assistant message in the ``messages`` list — handles
       both plain dicts (``role == "assistant"``/``"ai"``) and LangChain
       message objects (``msg.type == "ai"``/``"assistant"``).
    2. ``ab_output`` key (DeepAgents convention).
    3. Top-level fallback keys: ``output``, ``report``, ``answer``,
       ``response``, ``result``.

    Returns:
        Concatenated text from all matching sources, joined by newlines.
        Empty string if nothing is found.
    """
    if not state:
        return ""

    parts: list[str] = []
    messages = extract_messages(state)

    # Only scan the LAST assistant message — previous ones were already
    # evaluated when they were first generated.
    last_assistant_content: str | None = None
    for msg in messages:
        content = ""
        if isinstance(msg, dict):
            role = msg.get("role", "")
            if role in ("assistant", "ai"):
                content = msg.get("content", "")
        elif hasattr(msg, "content"):
            msg_type = getattr(msg, "type", "") or getattr(msg, "role", "")
            if msg_type in ("ai", "assistant"):
                content = getattr(msg, "content", "")

        if isinstance(content, str) and content:
            last_assistant_content = content

    if last_assistant_content:
        parts.append(last_assistant_content)

    # Fallback: check well-known top-level keys including ab_output
    if isinstance(state, dict):
        for key in ("ab_output", "output", "report", "answer", "response", "result"):
            val = state.get(key)
            if isinstance(val, str) and val:
                parts.append(val)

    # -- developer-specified context keys ----------------------------------
    if isinstance(state, dict) and (context_keys or scan_context):
        extra = extract_context_text(state, context_keys=context_keys, scan_context=scan_context)
        if extra:
            parts.append(extra)

    return "\n".join(parts)


def extract_context_text(
    state: dict[str, Any],
    *,
    context_keys: list[str] | None = None,
    scan_context: bool = False,
) -> str:
    """Extract text from developer-specified context keys or all context values.

    Platform-agnostic helper: works with any framework's data context
    (LangGraph state, CrewAI task I/O, LangChain chain dicts).

    Two modes of operation:

    1. **Explicit keys** (``context_keys=["extracted_text", "api_response"]``):
       Extract text only from the specified keys.  The developer knows
       their data schema and tells the guardrail exactly where to look.

    2. **Scan all** (``scan_context=True``): Extract all string values from
       the context dict, excluding well-known internal keys (``messages``,
       ``ab_messages``, ``ab_output``, ``is_last_step``, ``remaining_steps``,
       etc.) to avoid false positives on framework internals.

    When both are set, ``context_keys`` takes priority (explicit is better
    than implicit).

    Handles:
    * Plain strings.
    * Lists of strings.
    * Lists of dicts with ``content`` / ``text`` / ``page_content`` fields.
    * LangChain ``Document`` objects (with ``.page_content`` attribute).

    Returns:
        Concatenated text, or ``""`` if nothing is found.
    """
    if not state or not isinstance(state, dict):
        return ""

    # Keys to skip when scan_context=True (framework internals + already-scanned)
    _SKIP_KEYS = frozenset({
        "messages", "ab_messages", "ab_output",
        "is_last_step", "remaining_steps",
        "output", "report", "answer", "response", "result",
        "query", "input", "question", "user_input", "prompt", "task",
    })

    parts: list[str] = []

    if context_keys:
        # Explicit mode: developer-specified keys only
        keys_to_scan = context_keys
    elif scan_context:
        # Auto mode: all keys except internals
        keys_to_scan = [k for k in state if k not in _SKIP_KEYS]
    else:
        return ""

    for key in keys_to_scan:
        val = state.get(key)
        if val is None:
            continue

        if isinstance(val, str) and val:
            parts.append(val)
        elif isinstance(val, list):
            for item in val:
                if isinstance(item, str) and item:
                    parts.append(item)
                elif isinstance(item, dict):
                    for field in ("content", "text", "page_content", "snippet"):
                        t = item.get(field)
                        if isinstance(t, str) and t:
                            parts.append(t)
                            break
                elif hasattr(item, "page_content"):
                    pc = getattr(item, "page_content", "")
                    if isinstance(pc, str) and pc:
                        parts.append(pc)
        elif isinstance(val, dict):
            for field in ("content", "text", "page_content", "snippet"):
                t = val.get(field)
                if isinstance(t, str) and t:
                    parts.append(t)

    return "\n".join(parts)


def extract_source_text(
    state: dict[str, Any],
    source_keys: list[str],
    *,
    stop_at_first: bool = False,
) -> str:
    """Extract and concatenate source material from *state*.

    Args:
        state:          The state dictionary to search.
        source_keys:    Keys to look for source material under, tried in
                        order.
        stop_at_first:  If ``True``, return as soon as the **first**
                        non-empty source key is found (``HallucinationGuardrail``
                        behaviour — avoids mixing unrelated sources).
                        If ``False`` (default), collect from **all** keys
                        and concatenate (``GroundingGuardrail`` behaviour —
                        maximises coverage for citation/overlap checks).

    Handles:
    * Plain strings.
    * Lists of strings.
    * Lists of dicts with ``content`` / ``text`` / ``page_content`` /
      ``snippet`` fields.
    * LangChain ``Document`` objects (with a ``.page_content`` attribute).

    Returns:
        Source text as a single string, or ``""`` if nothing is found.
    """
    all_parts: list[str] = []

    for key in source_keys:
        val = state.get(key)
        if not val:
            continue

        key_parts: list[str] = []

        if isinstance(val, str):
            key_parts.append(val)
        elif isinstance(val, list):
            for item in val:
                if isinstance(item, str):
                    key_parts.append(item)
                elif isinstance(item, dict):
                    # Try common document content fields in preference order
                    for field in ("content", "text", "page_content", "snippet"):
                        t = item.get(field)
                        if isinstance(t, str) and t:
                            key_parts.append(t)
                            break
                elif hasattr(item, "page_content"):
                    # LangChain Document object
                    key_parts.append(str(getattr(item, "page_content", "")))

        if key_parts:
            all_parts.extend(key_parts)
            if stop_at_first:
                break  # found content for this key — stop looking

    return "\n".join(all_parts)


def extract_input_text(
    state: dict[str, Any],
    *,
    context_keys: list[str] | None = None,
    scan_context: bool = False,
) -> str:
    """Extract user-facing text from the input state.

    Shared helper for all before_node guardrails (prompt injection, input
    PII, topic restriction, toxicity input scan).

    Only the **last** user/human message is extracted from the messages
    list.  Previous messages have already been processed through the
    guardrail pipeline when they were first submitted — re-scanning them
    would cause false positives in conversational flows (e.g. blocking
    "What is my name?" because an earlier message contained PII).

    Checks:
    1. ``messages`` / ``ab_messages`` list — extracts content from the
       **last** message with ``role`` in ``("user", "human")`` or
       LangChain ``HumanMessage`` objects (``type == "human"``).
    2. Common scalar input keys: ``query``, ``input``, ``question``,
       ``user_input``, ``prompt``, ``task``.

    Returns:
        Concatenated text from all matching sources, joined by newlines.
        Empty string if nothing is found.
    """
    parts: list[str] = []

    # -- messages list (LangGraph / OpenAI style) --------------------------
    # Only scan the LAST user message — previous ones were already scanned
    # when they first arrived in the conversation.
    messages = state.get("messages") or state.get("ab_messages") or []
    if isinstance(messages, list):
        last_user_content: str | None = None
        for msg in messages:
            if isinstance(msg, dict):
                role = msg.get("role", "")
                if role in ("user", "human"):
                    content = msg.get("content", "")
                    if isinstance(content, str):
                        last_user_content = content
                    elif isinstance(content, list):
                        # OpenAI multi-modal format: [{"type": "text", "text": "..."}]
                        text_parts = [
                            block.get("text", "")
                            for block in content
                            if isinstance(block, dict) and block.get("type") == "text"
                        ]
                        if text_parts:
                            last_user_content = "\n".join(text_parts)
            elif hasattr(msg, "content") and hasattr(msg, "type"):
                # LangChain message objects
                if getattr(msg, "type", "") in ("human", "user"):
                    content = getattr(msg, "content", "")
                    if isinstance(content, str):
                        last_user_content = content
                    elif isinstance(content, list):
                        # OpenAI multi-modal format: [{"type": "text", "text": "..."}]
                        text_parts = [
                            block.get("text", "")
                            for block in content
                            if isinstance(block, dict) and block.get("type") == "text"
                        ]
                        if text_parts:
                            last_user_content = "\n".join(text_parts)
        if last_user_content:
            parts.append(last_user_content)

    # -- scalar input fields -----------------------------------------------
    for key in ("query", "input", "question", "user_input", "prompt", "task"):
        val = state.get(key)
        if isinstance(val, str) and val:
            parts.append(val)

    # -- developer-specified context keys ------------------------------------
    if context_keys or scan_context:
        extra = extract_context_text(state, context_keys=context_keys, scan_context=scan_context)
        if extra:
            parts.append(extra)

    return "\n".join(parts)
