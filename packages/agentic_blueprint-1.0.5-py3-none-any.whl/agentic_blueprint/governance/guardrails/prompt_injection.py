"""Prompt injection detection guardrail.

Hybrid approach: fast regex catches known injection patterns first,
with an optional LLM classifier for borderline cases.

Runs in the **before_node** phase to intercept malicious inputs before
they reach the LLM.

Detected pattern families
-------------------------
- **System-prompt extraction** — "ignore previous instructions", "show
  your system prompt"
- **DAN / jailbreak** — "do anything now", "bypass restrictions"
- **Role-play attacks** — "pretend you are an unrestricted AI"
- **Delimiter injection** — fake ``system:`` / ``assistant:`` blocks
- **Encoding tricks** — requests to base64-decode hidden instructions
- **Instruction override** — "new instructions:", "you are now"

Usage::

    from agentic_blueprint.governance.guardrails import PromptInjectionGuardrail

    # Regex-only (zero-dependency, default)
    guardrail = PromptInjectionGuardrail()

    # With LLM fallback for borderline cases
    async def injection_classifier(text: str) -> float:
        # Call your fine-tuned classifier and return P(injection) ∈ [0,1]
        ...

    guardrail = PromptInjectionGuardrail(
        llm_judge=injection_classifier,
        confidence_threshold=0.7,
    )
"""

from __future__ import annotations

import logging
import re
from typing import Awaitable, Callable, Sequence

from agentic_blueprint.exceptions import GuardrailBlockedError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guardrails.base import (
    Guardrail,
    GuardrailAction,
    GuardrailResult,
)
from agentic_blueprint.governance.guardrails._text_utils import (
    extract_input_text as _extract_input_text,
    sanitize_text as _sanitize_text,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Built-in injection patterns.
#
# Each entry is ``(family_name, compiled_regex)``.  Patterns are checked
# in order; scanning stops at the first match (unless the LLM fallback
# is also enabled, in which case regex results are returned immediately
# without calling the LLM).
# ---------------------------------------------------------------------------

_INJECTION_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    # --- Ignore / disregard prior context ----------------------------------
    (
        "instruction_override",
        re.compile(
            r"(ignore|disregard|forget|override|bypass)\s+"
            r"(all\s+)?(previous\s+|prior\s+|above\s+|earlier\s+|existing\s+|original\s+)?"
            r"(instructions?|prompts?|rules?|context|guidelines?|directions?)",
            re.IGNORECASE,
        ),
    ),
    # --- DAN / jailbreak keywords -----------------------------------------
    (
        "dan_jailbreak",
        re.compile(
            r"\b("
            r"do\s+anything\s+now|"
            r"DAN\s+mode|"
            r"you\s+are\s+(now\s+)?DAN|"
            r"jailbreak|"
            r"bypass\s+(safety|restrictions?|filters?|guidelines?)|"
            r"ignore\s+safety|"
            r"unlock\s+developer\s+mode|"
            r"enter\s+unrestricted\s+mode"
            r")\b",
            re.IGNORECASE,
        ),
    ),
    # --- Role-play / persona attacks --------------------------------------
    (
        "role_play_attack",
        re.compile(
            r"(pretend|act|behave|imagine|roleplay|role[\s\-]?play)\s+"
            r"(you\s+are|you're|as\s+if\s+you\s+are|to\s+be)\s+"
            r"(a\s+|an\s+|the\s+)?"
            r"(unrestricted|unfiltered|evil|malicious|uncensored|"
            r"unethical|amoral|without\s+restrictions)",
            re.IGNORECASE,
        ),
    ),
    # --- Delimiter / block injection --------------------------------------
    (
        "delimiter_injection",
        re.compile(
            r"(```|---+|\*\*\*|===+|<<<|>>>)\s*"
            r"(system|assistant|admin|root|developer|internal)\s*[:\-\|]",
            re.IGNORECASE,
        ),
    ),
    # --- Encoding trick requests ------------------------------------------
    (
        "encoding_trick",
        re.compile(
            r"(base64|rot13|hex|url[\s\-]?encode|ascii)\s*"
            r"(decode|encode|translate|convert|interpret)\s*"
            r"(the\s+following|this|:|\()",
            re.IGNORECASE,
        ),
    ),
    # --- New / updated instruction injection ------------------------------
    (
        "new_instruction",
        re.compile(
            r"("
            r"new\s+instructions?\s*:|"
            r"updated?\s+system\s+prompt\s*:|"
            r"you\s+are\s+now\s+(a|an|the|my)|"
            r"from\s+now\s+on\s+(you|ignore|your)|"
            r"system\s*:\s*you\s+are|"
            r"SYSTEM\s+OVERRIDE|"
            r"admin\s+override"
            r")",
            re.IGNORECASE,
        ),
    ),
    # --- Prompt / instruction leak requests -------------------------------
    (
        "prompt_leak",
        re.compile(
            r"(show|reveal|display|print|output|repeat|echo|dump|list)\s+"
            r"(your|the|my|initial|original|full|complete)\s+"
            r"(system\s+)?"
            r"(prompt|instructions?|rules?|guidelines?|configuration|directives?)",
            re.IGNORECASE,
        ),
    ),
    # --- Indirect prompt leak / social engineering ------------------------
    (
        "indirect_prompt_leak",
        re.compile(
            r"("
            r"what\s+(were|are)\s+(your|the)\s+(initial|original|system|first|starting)\s+(instructions?|directives?|rules?|prompt)|"
            r"repeat\s+(everything|what|back)\s+(above|before|so\s+far)|"
            r"what\s+did\s+(the\s+)?(developer|creator|programmer|admin)\s+(tell|instruct|program)|"
            r"what\s+is\s+your\s+(system\s+)?(prompt|instruction|directive|programming)|"
            r"translate\s+your\s+(instructions?|prompt|rules?)\s+(to|into)"
            r")",
            re.IGNORECASE,
        ),
    ),
]


# ---------------------------------------------------------------------------
# Guardrail implementation
# ---------------------------------------------------------------------------


class PromptInjectionGuardrail(Guardrail):
    """Detect and block prompt injection attacks on user input.

    Runs in the ``before_node`` phase.  Regex patterns catch known attack
    vectors; an optional LLM judge provides a second-pass classifier for
    borderline cases that evade regex detection.

    Parameters
    ----------
    block : bool
        ``True`` (default) → raise ``GuardrailBlockedError``.
        ``False`` → log a warning and attach metadata only.
    extra_patterns : sequence of (name, regex_str) tuples
        Additional detection patterns appended to the built-in set.
    llm_judge : async callable ``(text) -> float``
        Returns injection probability in ``[0, 1]``.  Called only when
        **no** regex match is found.  Skipped if ``None`` (default).
    confidence_threshold : float
        LLM score at or above which the input is treated as an injection
        attempt (default ``0.7``).
    """

    def __init__(
        self,
        *,
        block: bool = True,
        extra_patterns: Sequence[tuple[str, str]] | None = None,
        llm_judge: Callable[[str], Awaitable[float]] | None = None,
        confidence_threshold: float = 0.7,
        block_response: str | None = None,
        context_keys: list[str] | None = None,
        scan_context: bool = False,
    ) -> None:
        self._block = block
        self._llm_judge = llm_judge
        self._confidence_threshold = confidence_threshold
        self._block_response = block_response
        self._context_keys = context_keys
        self._scan_context = scan_context

        # Compile the full pattern list: built-ins + extras
        self._patterns: list[tuple[str, re.Pattern[str]]] = list(_INJECTION_PATTERNS)
        for name, pattern_str in extra_patterns or []:
            self._patterns.append((name, re.compile(pattern_str, re.IGNORECASE)))

    # -- before_node: INPUT scanning ----------------------------------------

    async def before_node(self, ctx: ExecutionContext) -> ExecutionContext:
        """Check input state for injection attacks before LLM processing."""
        input_text = _extract_input_text(
            ctx.input_state,
            context_keys=self._context_keys,
            scan_context=self._scan_context,
        )
        if not input_text:
            return ctx

        # Pre-process: normalise Unicode & strip evasion tricks
        sanitized = _sanitize_text(input_text, leet=True)

        # Phase 1: fast regex scan (run on BOTH raw and sanitised text
        # so that normal inputs still match fast while evasion attempts
        # are caught after normalisation)
        matched = self._regex_scan(input_text)
        if not matched:
            matched = self._regex_scan(sanitized)

        # Phase 2: optional LLM fallback (only when regex found nothing)
        if not matched and self._llm_judge:
            try:
                score = await self._llm_judge(input_text)
                if score >= self._confidence_threshold:
                    matched = [("llm_judge", f"confidence={score:.2f}")]
            except Exception:
                logger.warning(
                    "PromptInjectionGuardrail LLM judge call failed",
                    exc_info=True,
                )

        if matched:
            families = ", ".join(name for name, _ in matched)
            detail = f"Prompt injection detected ({families})"
            action = GuardrailAction.BLOCK if self._block else GuardrailAction.REDACT
            result = GuardrailResult(guardrail=self.name, action=action, detail=detail)
            ctx.metadata.setdefault("guardrail_results", []).append(result)

            if self._block:
                raise GuardrailBlockedError(
                    self.name, detail, block_response=self._block_response,
                )
            logger.warning("PromptInjectionGuardrail (warn-only): %s", detail)

        return ctx

    # -- after_node: passthrough -------------------------------------------

    async def evaluate(self, ctx: ExecutionContext) -> GuardrailResult:
        """No-op — all checks run in ``before_node``.

        Returns PASS without appending to ``guardrail_results`` so that
        the audit trail is not polluted with vacuous no-op entries.
        The base class ``after_node`` only appends non-PASS results, so
        this is automatically suppressed.
        """
        return GuardrailResult(
            guardrail=self.name,
            action=GuardrailAction.PASS,
            detail="Input injection check completed in before_node phase",
        )

    # -- Internal helpers ---------------------------------------------------

    def _regex_scan(self, text: str) -> list[tuple[str, str]]:
        """Return ``(pattern_family, matched_text)`` for every matching pattern."""
        hits: list[tuple[str, str]] = []
        for name, pattern in self._patterns:
            m = pattern.search(text)
            if m:
                hits.append((name, m.group()))
        return hits


# ---------------------------------------------------------------------------
# Text extraction helpers
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# (No local _extract_input_text — uses shared _text_utils.extract_input_text)
