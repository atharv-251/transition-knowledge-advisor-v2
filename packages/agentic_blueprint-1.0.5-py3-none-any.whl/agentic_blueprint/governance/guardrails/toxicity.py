"""Toxicity detection guardrail.

Per-category pattern matching for toxic content in LLM input and output.
Each category (``hate``, ``violence``, ``sexual``, ``self_harm``) has
independent hardcoded indicator patterns.

Design decisions
~~~~~~~~~~~~~~~~
- **No external model dependency** — works offline with compiled regexes.
  Latency is sub-millisecond and no GPU-backed classifier is needed.
- **Bidirectional scanning** — runs in ``before_node`` (user input) *and*
  ``after_node`` (LLM output) so toxic content is caught regardless of
  origin.  Set ``scan_input=False`` to restore the output-only behaviour.
- **Per-category granularity** — enable only the categories relevant to
  your use-case via the ``categories`` parameter.
- **Extensible** — pass ``extra_terms`` to extend the built-in patterns.

Usage::

    from agentic_blueprint.governance.guardrails import ToxicityGuardrail

    # All categories, block on detection (default)
    guardrail = ToxicityGuardrail()

    # Only violence + hate, warn instead of block
    guardrail = ToxicityGuardrail(
        categories=["violence", "hate"],
        block=False,
    )

    # Output-only scan (legacy behaviour)
    guardrail = ToxicityGuardrail(scan_input=False)
"""

from __future__ import annotations

import logging
import re
from typing import Awaitable, Callable, Sequence

from agentic_blueprint.exceptions import GuardrailBlockedError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guardrails.base import (
    Guardrail,
    GuardrailAction,
    GuardrailResult,
)
from agentic_blueprint.governance.guardrails._text_utils import (
    extract_input_text as _extract_input_text,
    extract_output_text as _extract_output_text,
    sanitize_text as _sanitize_text,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Category definitions
# ---------------------------------------------------------------------------

_CATEGORY_PATTERNS: dict[str, list[tuple[str, re.Pattern[str]]]] = {
    "hate": [
        (
            "dehumanisation",
            re.compile(
                r"\b(those\s+people|they\s+are\s+all|every\s+single\s+one\s+of\s+them)\s+"
                r"(are|should\s+be|deserve|need\s+to\s+be)\s+"
                r"(eliminated|removed|eradicated|punished|exterminated|deported)",
                re.IGNORECASE,
            ),
        ),
        (
            "supremacist_language",
            re.compile(
                r"\b(superior|inferior)\s+race\b|\b(racial|ethnic)\s+cleansing\b",
                re.IGNORECASE,
            ),
        ),
        (
            "discriminatory_call",
            re.compile(
                r"\b(all|every)\s+(muslims?|jews?|christians?|blacks?|whites?|asians?|mexicans?|immigrants?)\s+"
                r"(should|must|need\s+to|deserve\s+to)\s+"
                r"(die|be\s+killed|be\s+removed|go\s+back|be\s+deported)",
                re.IGNORECASE,
            ),
        ),
        # Broader hate expression — catches "I hate [group]", "[group]
        # are vermin/animals/scum", etc.
        (
            "hate_expression",
            re.compile(
                r"\b(i\s+hate|death\s+to|down\s+with)\s+"
                r"(all\s+)?"
                r"(muslims?|jews?|christians?|blacks?|whites?|asians?|mexicans?|immigrants?|women|men|gays?|trans)\b",
                re.IGNORECASE,
            ),
        ),
        (
            "group_dehumanise",
            re.compile(
                r"\b(muslims?|jews?|christians?|blacks?|whites?|asians?|mexicans?|immigrants?|refugees?|women|gays?|trans)\s+"
                r"(are|is)\s+"
                r"(vermin|animals?|scum|trash|garbage|cockroaches?|parasites?|sub[\s\-]?human|cancer|plague|disease)",
                re.IGNORECASE,
            ),
        ),
    ],
    "violence": [
        (
            "direct_threat",
            re.compile(
                r"\b(i\s+will|i'm\s+going\s+to|we\s+should|let's|gonna|"
                r"i\s+want\s+to|i\s+need\s+to|someone\s+should|they\s+should|"
                r"we\s+need\s+to|we\s+must|you\s+should|you\s+must|"
                r"i\s+swear\s+i'll|i\s+promise\s+to)\s+"
                r"(kill|murder|shoot|stab|attack|assault|bomb|hurt|harm|"
                r"beat\s+up|destroy|strangle|execute|eliminate|slaughter|"
                r"torture|dismember|behead|lynch|maim|butcher)\s+"
                r"(you|them|him|her|everyone|people|the|that|those|all)",
                re.IGNORECASE,
            ),
        ),
        # Standalone threat without subject specification
        (
            "standalone_threat",
            re.compile(
                r"\b(kill|murder|shoot|stab|bomb|attack|slaughter|execute|behead|lynch)\s+"
                r"(them\s+all|every\s+last\s+one|all\s+of\s+them|everyone)",
                re.IGNORECASE,
            ),
        ),
        # Imperative threats: "die", "go die", "kill yourself"
        (
            "imperative_threat",
            re.compile(
                r"\b(go\s+die|drop\s+dead|i\s+hope\s+you\s+die|you\s+deserve\s+to\s+die|"
                r"kill\s+yourself|hang\s+yourself|shoot\s+yourself)\b",
                re.IGNORECASE,
            ),
        ),
        (
            "violence_instruction",
            re.compile(
                r"(how\s+to|steps?\s+to|instructions?\s+(for|to)|guide\s+to)\s+"
                r"(make\s+a\s+bomb|build\s+a\s+weapon|poison|synthesize\s+.*explosive|"
                r"manufacture\s+.*firearm|create\s+.*toxin)",
                re.IGNORECASE,
            ),
        ),
        (
            "glorification",
            re.compile(
                r"\b(mass\s+shooting|school\s+shooting|terrorist\s+attack|genocide)\s+"
                r"(was\s+justified|was\s+a\s+good\s+thing|should\s+happen\s+again|"
                r"is\s+heroic|deserved)",
                re.IGNORECASE,
            ),
        ),
    ],
    "sexual": [
        (
            "explicit_content",
            re.compile(
                r"\b(explicit\s+sexual|graphic\s+sexual|pornographic)\s+"
                r"(content|material|description|scene|act)",
                re.IGNORECASE,
            ),
        ),
        (
            "minor_exploitation",
            re.compile(
                r"\b(child|minor|underage|under[\s\-]?age)\s+"
                r"(sexual|pornograph|erotic|exploit|abuse|nude|naked)",
                re.IGNORECASE,
            ),
        ),
    ],
    "self_harm": [
        (
            "suicide_instruction",
            re.compile(
                r"(how\s+to|methods?\s+(of|for)|ways?\s+to|steps?\s+to)\s+"
                r"(commit\s+suicide|kill\s+yourself|end\s+(your|my)\s+life|self[\s\-]?harm)",
                re.IGNORECASE,
            ),
        ),
        (
            "self_harm_encouragement",
            re.compile(
                r"(you\s+should|you\s+deserve\s+to|just\s+go\s+ahead\s+and|why\s+don't\s+you)\s+"
                r"(kill\s+yourself|end\s+(it|your\s+life)|hurt\s+yourself|commit\s+suicide|cut\s+yourself)",
                re.IGNORECASE,
            ),
        ),
    ],
}

ALL_CATEGORIES = tuple(_CATEGORY_PATTERNS.keys())


# ---------------------------------------------------------------------------
# Guardrail
# ---------------------------------------------------------------------------


class ToxicityGuardrail(Guardrail):
    """Scan LLM input and output for toxic content across configurable categories.

    Runs in **both** ``before_node`` (user input) and ``after_node``
    (LLM output) phases so toxic content is caught regardless of origin.

    Parameters
    ----------
    categories : sequence of str
        Which categories to enable.  Defaults to all four categories.
    block : bool
        ``True`` (default) → raise ``GuardrailBlockedError``.
        ``False`` → log a warning and attach result metadata only.
    scan_input : bool
        ``True`` (default) → also scan user input in ``before_node``.
        ``False`` → output-only mode (restores legacy behaviour).
    extra_terms : dict mapping category → list of extra regex strings
        Extend the built-in patterns for a given category.
    llm_judge : async callable ``(text) -> float``, optional
        Returns toxicity probability in ``[0, 1]``.  Called only when
        **no** regex match is found.  Skipped if ``None`` (default).
    confidence_threshold : float
        LLM score at or above which the text is treated as toxic
        (default ``0.7``).
    """

    def __init__(
        self,
        *,
        categories: Sequence[str] | None = None,
        block: bool = True,
        scan_input: bool = True,
        extra_terms: dict[str, list[str]] | None = None,
        llm_judge: Callable[[str], Awaitable[float]] | None = None,
        confidence_threshold: float = 0.7,
        block_response: str | None = None,
        context_keys: list[str] | None = None,
        scan_context: bool = False,
    ) -> None:
        self._block = block
        self._scan_input = scan_input
        self._llm_judge = llm_judge
        self._confidence_threshold = confidence_threshold
        self._block_response = block_response
        self._context_keys = context_keys
        self._scan_context = scan_context
        self._categories = list(categories or ALL_CATEGORIES)

        unknown = set(self._categories) - set(ALL_CATEGORIES)
        if unknown:
            raise ValueError(
                f"Unknown toxicity categories: {unknown}. "
                f"Available: {', '.join(ALL_CATEGORIES)}"
            )

        # Build active patterns: built-ins + caller-supplied extras
        self._patterns: dict[str, list[tuple[str, re.Pattern[str]]]] = {}
        for cat in self._categories:
            self._patterns[cat] = list(_CATEGORY_PATTERNS.get(cat, []))
            for i, regex_str in enumerate((extra_terms or {}).get(cat, [])):
                self._patterns[cat].append(
                    (f"custom_{i}", re.compile(regex_str, re.IGNORECASE))
                )

    # -- shared scanner ----------------------------------------------------

    def _scan_text(self, text: str) -> list[str]:
        """Return ``category/label`` hit strings for every matching pattern."""
        hits: list[str] = []
        for category, patterns in self._patterns.items():
            for label, pattern in patterns:
                if pattern.search(text):
                    hits.append(f"{category}/{label}")
        return hits

    # -- before_node: INPUT scan -------------------------------------------

    async def before_node(self, ctx: ExecutionContext) -> ExecutionContext:
        """Scan user input for toxic content before it reaches the LLM."""
        if not self._scan_input:
            return ctx

        input_text = _extract_input_text(
            ctx.input_state,
            context_keys=self._context_keys,
            scan_context=self._scan_context,
        )
        if not input_text:
            return ctx

        # Scan both raw and sanitised text to catch evasion attempts
        sanitized = _sanitize_text(input_text, leet=True)
        hits = self._scan_text(input_text)
        if not hits:
            hits = self._scan_text(sanitized)

        # LLM fallback: only when regex found nothing
        if not hits and self._llm_judge:
            try:
                score = await self._llm_judge(input_text)
                if score >= self._confidence_threshold:
                    hits = [f"llm_judge/confidence={score:.2f}"]
            except Exception:
                logger.warning(
                    "ToxicityGuardrail LLM judge call failed (input scan)",
                    exc_info=True,
                )

        if hits:
            detail = f"Toxic input detected: {', '.join(hits)}"
            result = GuardrailResult(
                guardrail=self.name,
                action=GuardrailAction.BLOCK if self._block else GuardrailAction.REDACT,
                detail=detail,
            )
            self._append_result(ctx, result)
            if self._block:
                raise GuardrailBlockedError(
                    self.name, detail, block_response=self._block_response,
                )
            logger.warning("ToxicityGuardrail input scan (warn-only): %s", detail)
        return ctx

    # -- after_node: OUTPUT scan via evaluate() ----------------------------

    async def evaluate(self, ctx: ExecutionContext) -> GuardrailResult:
        """Scan LLM output for toxic content."""
        output_text = _extract_output_text(
            ctx.output_state,
            context_keys=self._context_keys,
            scan_context=self._scan_context,
        )
        if not output_text:
            return GuardrailResult(
                guardrail=self.name,
                action=GuardrailAction.PASS,
                detail="No output text to scan",
            )

        # Scan both raw and sanitised text to catch evasion attempts
        sanitized = _sanitize_text(output_text, leet=True)
        hits = self._scan_text(output_text)
        if not hits:
            hits = self._scan_text(sanitized)

        # LLM fallback: only when regex found nothing
        if not hits and self._llm_judge:
            try:
                score = await self._llm_judge(output_text)
                if score >= self._confidence_threshold:
                    hits = [f"llm_judge/confidence={score:.2f}"]
            except Exception:
                logger.warning(
                    "ToxicityGuardrail LLM judge call failed (output scan)",
                    exc_info=True,
                )

        if not hits:
            return GuardrailResult(
                guardrail=self.name,
                action=GuardrailAction.PASS,
                detail="No toxic content detected",
            )

        detail = f"Toxic content detected: {', '.join(hits)}"
        action = GuardrailAction.BLOCK if self._block else GuardrailAction.REDACT

        if self._block:
            raise GuardrailBlockedError(
                self.name, detail, block_response=self._block_response,
            )

        logger.warning("ToxicityGuardrail output scan (warn-only): %s", detail)
        return GuardrailResult(guardrail=self.name, action=action, detail=detail)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# (No local extraction helpers — uses shared _text_utils versions which
#  correctly filter by role.  sanitize_text hardens all regex scans
#  against Unicode/homoglyph/leetspeak evasion.)
