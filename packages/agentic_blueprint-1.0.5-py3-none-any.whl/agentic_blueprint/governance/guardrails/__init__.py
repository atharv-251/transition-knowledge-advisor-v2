"""Built-in guardrails.

Changes summary
---------------
base.py
  * ``GuardrailResult`` gains a ``timestamp`` field (UTC epoch) for audit
    completeness.
  * ``after_node`` only appends non-PASS results to ``guardrail_results``
    metadata — avoids polluting the audit trail with no-op entries from
    before_node-only guardrails.
  * New ``_append_result`` helper for guardrails that need explicit PASS
    recording.

_text_utils.py
  * ``compute_word_overlap`` now returns ``1.0`` (trivially grounded) when
    ``source_words`` is empty — prevents grounding/hallucination checks
    from incorrectly failing when no source material is present.
  * ``sentence_tokenize`` now also splits on newlines so paragraph- and
    bullet-structured LLM output is properly segmented.
  * ``extract_output_text`` now also checks the ``ab_output`` key used by
    DeepAgents.

pii_detector.py
  * Pattern set is now imported from ``input_pii._BUILTIN_PATTERNS`` (single
    source of truth) — ``ssn_us``, ``passport``, and ``ipv4`` are no longer
    missing from output PII scanning.

toxicity.py
  * New ``before_node`` input scanner — toxic user inputs are now caught
    before they reach the LLM (set ``scan_input=False`` for legacy behaviour).
  * ``_extract_input_text`` helper added.
  * Shared ``_scan_text`` method used by both phases.

content_filter.py
  * Matched terms are no longer echoed in ``GuardrailBlockedError.reason``
    to prevent user-input leakage via error messages.

prompt_injection.py
  * ``evaluate()`` docstring clarifies it is a no-op whose PASS result is
    automatically suppressed by the updated ``after_node`` base logic.

tool_execution.py
  * SSRF patterns now cover all RFC-1918 private IP ranges
    (10.0.0.0/8, 172.16-31.x/12, 192.168.0.0/16) in addition to the
    previously covered loopback and link-local ranges.

input_pii.py
  * ``InputPIIGuardrail`` no longer raises ``ValueError`` for unknown
    detector names that are covered by ``extra_patterns``.
"""

from agentic_blueprint.governance.guardrails.base import Guardrail, GuardrailAction, GuardrailResult
from agentic_blueprint.governance.guardrails.checkpoint_store import (
    GovernanceCheckpointStore,
    InMemoryCheckpointStore,
)
from agentic_blueprint.governance.guardrails.content_filter import ContentFilterGuardrail
from agentic_blueprint.governance.guardrails.grounding import GroundingGuardrail
from agentic_blueprint.governance.guardrails.hallucination import HallucinationGuardrail
from agentic_blueprint.governance.guardrails.hitl_strategy import (
    BlockingHITLStrategy,
    HITLPayload,
    HITLStrategy,
    LangGraphHITLStrategy,
    NoOpHITLStrategy,
)
from agentic_blueprint.governance.guardrails.human_review import HumanReviewGuard
from agentic_blueprint.governance.guardrails.input_pii import InputPIIGuardrail
from agentic_blueprint.governance.guardrails.llm_judge import (
    create_content_filter_judge,
    create_faithfulness_judge,
    create_grounding_judge,
    create_injection_judge,
    create_pii_judge,
    create_tool_execution_judge,
    create_topic_judge,
    create_toxicity_judge,
)
from agentic_blueprint.governance.guardrails.pii_detector import OutputPIIGuardrail
from agentic_blueprint.governance.guardrails.prompt_injection import PromptInjectionGuardrail
from agentic_blueprint.governance.guardrails.schema_validator import SchemaValidatorGuardrail
from agentic_blueprint.governance.guardrails.tool_execution import ToolExecutionGuardrail
from agentic_blueprint.governance.guardrails.topic_restriction import TopicRestrictionGuardrail
from agentic_blueprint.governance.guardrails.toxicity import ToxicityGuardrail

__all__ = [
    "Guardrail",
    "GuardrailAction",
    "GuardrailResult",
    # HITL strategy pattern
    "HITLStrategy",
    "HITLPayload",
    "LangGraphHITLStrategy",
    "BlockingHITLStrategy",
    "NoOpHITLStrategy",
    "GovernanceCheckpointStore",
    "InMemoryCheckpointStore",
    # Output guardrails (after_node)
    "ContentFilterGuardrail",
    "GroundingGuardrail",
    "HallucinationGuardrail",
    "HumanReviewGuard",
    "OutputPIIGuardrail",
    "SchemaValidatorGuardrail",
    "ToxicityGuardrail",
    # Input guardrails (before_node)
    "InputPIIGuardrail",
    "PromptInjectionGuardrail",
    "TopicRestrictionGuardrail",
    # Bidirectional guardrails (before_node + after_node)
    "ToolExecutionGuardrail",
    # LLM judge factories
    "create_content_filter_judge",
    "create_faithfulness_judge",
    "create_grounding_judge",
    "create_injection_judge",
    "create_pii_judge",
    "create_tool_execution_judge",
    "create_topic_judge",
    "create_toxicity_judge",
]
