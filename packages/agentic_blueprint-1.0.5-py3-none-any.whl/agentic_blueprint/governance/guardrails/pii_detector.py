"""Regex-based PII detector / redactor guardrail.

A lightweight, zero-dependency PII scanner that catches common patterns
(emails, phone numbers, credit cards, German IBANs, US SSNs, passports,
IPv4 addresses).  For production use with sensitive workloads, teams
should swap this with a model-based detector (e.g., Presidio) behind
the same ``Guardrail`` interface.

Pattern source-of-truth
-----------------------
Patterns are imported from :mod:`input_pii` to ensure the output PII
scanner and the input PII scanner always detect exactly the same entity
types.  Any new pattern added to ``input_pii._BUILTIN_PATTERNS`` is
automatically picked up here.
"""

from __future__ import annotations

import logging
import re
from typing import Awaitable, Callable

from agentic_blueprint.exceptions import GuardrailBlockedError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guardrails.base import (
    Guardrail,
    GuardrailAction,
    GuardrailResult,
)
from agentic_blueprint.governance.guardrails._text_utils import (
    extract_messages as _extract_messages,
    extract_context_text as _extract_context_text,
)

logger = logging.getLogger(__name__)

# Import the single source-of-truth pattern set from input_pii.
# This eliminates drift between the two PII guardrails.
from agentic_blueprint.governance.guardrails.input_pii import _BUILTIN_PATTERNS as _PATTERNS  # noqa: F401

_REDACTION = "[REDACTED]"


class OutputPIIGuardrail(Guardrail):
    """Scan output messages for PII and either redact or block."""

    def __init__(
        self,
        *,
        block: bool = False,
        llm_judge: Callable[[str], Awaitable[list[str]]] | None = None,
        block_response: str | None = None,
        context_keys: list[str] | None = None,
        scan_context: bool = False,
    ) -> None:
        """
        Args:
            block: If ``True``, raise ``GuardrailBlockedError`` on detection.
                   If ``False`` (default), redact the matches in-place.
            llm_judge: Optional async callable ``(text) -> list[str]``
                       that returns detected PII type labels.  Called
                       after regex scanning to catch obfuscated PII.
            block_response: Custom user-facing message returned when the
                guardrail blocks.  Used by ``wrap()`` for soft-blocking.
            context_keys: Explicit list of context keys to scan in addition
                to messages.  E.g. ``["extracted_text", "api_response"]``.
            scan_context: If ``True``, scan ALL string values in the output
                context (excluding framework internals).  Overridden by
                ``context_keys`` when both are set.
        """
        self._block = block
        self._llm_judge = llm_judge
        self._block_response = block_response
        self._context_keys = context_keys
        self._scan_context = scan_context

    async def evaluate(self, ctx: ExecutionContext) -> GuardrailResult:
        if not ctx.output_state:
            return GuardrailResult(
                guardrail=self.name, action=GuardrailAction.PASS
            )

        # Only scan the LAST assistant message — previous ones were already
        # evaluated when they were first generated.  Scanning the full
        # history causes false positives in multi-turn conversations.
        last_msg = _extract_last_assistant_message(ctx.output_state)

        content = _extract_content(last_msg) if last_msg is not None else None
        found: list[str] = []

        if content:
            for label, pattern in _PATTERNS.items():
                if pattern.search(content):
                    found.append(label)

        # Scan developer-specified state keys for PII
        state_text = ""
        if self._context_keys or self._scan_context:
            state_text = _extract_context_text(
                ctx.output_state,
                context_keys=self._context_keys,
                scan_context=self._scan_context,
            )
            if state_text:
                for label, pattern in _PATTERNS.items():
                    if label not in found and pattern.search(state_text):
                        found.append(label)

        # LLM fallback: catch obfuscated PII that regex misses
        all_text = "\n".join(filter(None, [content, state_text]))
        if self._llm_judge and all_text:
            try:
                llm_found = await self._llm_judge(all_text)
                for label in llm_found:
                    if label not in found:
                        found.append(label)
            except Exception:
                logger.warning(
                    "OutputPIIGuardrail LLM judge call failed",
                    exc_info=True,
                )

        if not found:
            return GuardrailResult(
                guardrail=self.name, action=GuardrailAction.PASS
            )

        if self._block:
            raise GuardrailBlockedError(
                guardrail=self.name,
                reason=f"PII detected: {', '.join(sorted(set(found)))}",
                block_response=self._block_response,
            )

        # Redact in-place (only the last assistant message)
        _redact_content(last_msg)

        # Warn if LLM found additional PII types that regex can't redact
        regex_labels = set()
        if content:
            for label, pattern in _PATTERNS.items():
                if pattern.search(content):
                    regex_labels.add(label)
        llm_only = set(found) - regex_labels
        if llm_only:
            logger.warning(
                "OutputPIIGuardrail: LLM detected PII types %s that "
                "regex cannot redact — consider blocking or using a "
                "model-based redactor (e.g. Presidio)",
                sorted(llm_only),
            )

        return GuardrailResult(
            guardrail=self.name,
            action=GuardrailAction.REDACT,
            detail=f"Redacted: {', '.join(sorted(set(found)))}",
        )


def _extract_last_assistant_message(state: object) -> object | None:
    """Return the last assistant/AI message from the output state.

    Iterates the full messages list but only keeps a reference to the
    most recent assistant message — previous ones were already scanned.
    """
    messages = _extract_messages(state)
    last: object | None = None
    for msg in messages:
        if isinstance(msg, dict):
            if msg.get("role") in ("assistant", "ai"):
                last = msg
        elif hasattr(msg, "type") or hasattr(msg, "role"):
            msg_type = getattr(msg, "type", "") or getattr(msg, "role", "")
            if msg_type in ("ai", "assistant"):
                last = msg
    return last


def _extract_content(msg: object) -> str | None:
    """Pull text content from a message (dict or object)."""
    if isinstance(msg, dict):
        return msg.get("content")
    return getattr(msg, "content", None)


def _redact_content(msg: object) -> None:
    """Replace PII patterns in message content."""
    content = _extract_content(msg)
    if not content:
        return
    for pattern in _PATTERNS.values():
        content = pattern.sub(_REDACTION, content)
    if isinstance(msg, dict):
        msg["content"] = content
    elif hasattr(msg, "content"):
        try:
            msg.content = content  # type: ignore[attr-defined]
        except (AttributeError, TypeError):
            pass

