"""Output schema validation guardrail.

Validates that LLM output conforms to a user-defined schema.  This is
especially useful for structured-output agents that must return JSON or
domain-specific formats.

Supports:

- **Pydantic models** -- validates against ``model.model_validate_json()``.
- **JSON Schema dicts** -- validates against ``jsonschema.validate()``.
- **Callable validators** -- any ``(content: str) -> bool`` function.

Usage::

    from pydantic import BaseModel
    from agentic_blueprint.governance.guardrails import SchemaValidatorGuardrail

    class ResearchOutput(BaseModel):
        title: str
        summary: str
        sources: list[str]

    guardrail = SchemaValidatorGuardrail(schema=ResearchOutput)
    graph.add_guards(guardrail)

    # Or with a JSON Schema dict:
    guardrail = SchemaValidatorGuardrail(schema={
        "type": "object",
        "required": ["title", "summary"],
        "properties": {
            "title": {"type": "string"},
            "summary": {"type": "string"},
        },
    })

    # Or with a custom validator:
    guardrail = SchemaValidatorGuardrail(
        validator=lambda content: "SOURCES:" in content,
        detail="Output must contain a SOURCES section",
    )
"""

from __future__ import annotations

import json
import logging
from typing import Any, Callable

from pydantic import BaseModel as _BaseModel

from agentic_blueprint.exceptions import GuardrailBlockedError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guardrails.base import (
    Guardrail,
    GuardrailAction,
    GuardrailResult,
)

logger = logging.getLogger(__name__)


class SchemaValidatorGuardrail(Guardrail):
    """Validate LLM output against a schema or custom validator.

    If validation fails, the guardrail raises ``GuardrailBlockedError``
    (when ``block=True``) or returns a ``REDACT`` result with detail
    (when ``block=False``).
    """

    def __init__(
        self,
        *,
        schema: Any | None = None,
        validator: Callable[[str], bool] | None = None,
        block: bool = True,
        detail: str = "",
        block_response: str | None = None,
    ) -> None:
        """
        Args:
            schema: A Pydantic model class **or** a JSON Schema dict.
                Exactly one of ``schema`` or ``validator`` must be provided.
            validator: A callable ``(content: str) -> bool``.
                Return ``True`` if the content is valid.
            block: If ``True`` (default), raise on invalid output.
                If ``False``, log a warning and attach metadata.
            detail: Human-readable description of the expected format
                (shown in error messages and audit events).
        """
        if schema is None and validator is None:
            raise ValueError("Provide either 'schema' (Pydantic model or JSON Schema) or 'validator'")

        self._schema = schema
        self._validator = validator
        self._block = block
        self._detail = detail
        self._block_response = block_response

        # Detect schema type
        self._is_pydantic = schema is not None and _is_pydantic_model(schema)
        self._is_json_schema = isinstance(schema, dict)

    async def evaluate(self, ctx: ExecutionContext) -> GuardrailResult:
        if not ctx.output_state:
            return GuardrailResult(guardrail=self.name, action=GuardrailAction.PASS)

        messages = _safe_extract_messages(ctx.output_state)
        content = _extract_last_assistant_content(messages)

        if content is None:
            return GuardrailResult(guardrail=self.name, action=GuardrailAction.PASS)

        # -- Validate -------------------------------------------
        is_valid, error_detail = self._validate(content)

        if is_valid:
            return GuardrailResult(guardrail=self.name, action=GuardrailAction.PASS)

        # -- Invalid output -------------------------------------
        reason = self._detail or error_detail or "Output does not match expected schema"

        if self._block:
            raise GuardrailBlockedError(guardrail=self.name, reason=reason, block_response=self._block_response)

        logger.warning("Schema validation failed (non-blocking): %s", reason)
        return GuardrailResult(
            guardrail=self.name,
            action=GuardrailAction.REDACT,
            detail=reason,
        )

    def _validate(self, content: str) -> tuple[bool, str]:
        """Validate content against the configured schema/validator.

        Returns ``(is_valid, error_detail)``.
        """
        # Custom validator
        if self._validator is not None:
            try:
                result = self._validator(content)
                return (bool(result), "" if result else "Custom validator returned False")
            except Exception as exc:
                return (False, f"Validator raised: {exc}")

        # Pydantic model
        if self._is_pydantic:
            return _validate_pydantic(self._schema, content)

        # JSON Schema dict
        if self._is_json_schema:
            return _validate_json_schema(self._schema, content)

        return (True, "")


# -- Helpers ----------------------------------------------------


def _is_pydantic_model(obj: Any) -> bool:
    """Check if *obj* is a Pydantic model class."""
    return isinstance(obj, type) and issubclass(obj, _BaseModel)


def _validate_pydantic(model_class: Any, content: str) -> tuple[bool, str]:
    """Validate *content* against a Pydantic model."""
    try:
        model_class.model_validate_json(content)
        return (True, "")
    except Exception as exc:
        return (False, f"Pydantic validation failed: {exc}")


def _validate_json_schema(schema: dict[str, Any], content: str) -> tuple[bool, str]:
    """Validate *content* against a JSON Schema dict."""
    try:
        data = json.loads(content)
    except json.JSONDecodeError as exc:
        return (False, f"Output is not valid JSON: {exc}")

    try:
        import jsonschema

        jsonschema.validate(instance=data, schema=schema)
        return (True, "")
    except ImportError:
        # Fallback: basic type check without jsonschema
        logger.debug("jsonschema not installed, performing basic validation only")
        required = schema.get("required", [])
        if isinstance(data, dict):
            missing = [k for k in required if k not in data]
            if missing:
                return (False, f"Missing required fields: {missing}")
        return (True, "")
    except jsonschema.ValidationError as exc:
        return (False, f"JSON Schema validation failed: {exc.message}")


def _safe_extract_messages(output_state: object) -> list:
    """Normalise output_state into a flat list of message-like objects.

    Handles dict, list, and DeepAgents' ``Overwrite`` wrappers.
    """
    if hasattr(output_state, "value"):
        output_state = output_state.value
    if isinstance(output_state, dict):
        msgs = output_state.get("messages", [])
        if hasattr(msgs, "value"):
            msgs = msgs.value
        return msgs if isinstance(msgs, list) else []
    if isinstance(output_state, list):
        return output_state
    return []


def _extract_last_assistant_content(messages: list[Any]) -> str | None:
    """Extract text content from the last assistant message.

    Handles both plain dicts (``role == "assistant"``) and LangChain
    message objects (``type == "ai"``).
    """
    if not isinstance(messages, list):
        return None
    for msg in reversed(messages):
        # Dict-style messages
        if isinstance(msg, dict):
            role = msg.get("role", "")
            if role in ("assistant", "ai"):
                content = msg.get("content")
                return content if isinstance(content, str) else None
        # LangChain message objects (AIMessage has type="ai")
        else:
            msg_type = getattr(msg, "type", "") or getattr(msg, "role", "")
            if msg_type in ("ai", "assistant"):
                content = getattr(msg, "content", None)
                return content if isinstance(content, str) else None
    return None
