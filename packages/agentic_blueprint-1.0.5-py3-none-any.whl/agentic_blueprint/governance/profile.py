"""Governance profile -- mandate guard registry.

Mandate guards are **non-removable by developers** and represent the
minimum compliance baseline for the organisation.  They are
automatically prepended to every governed graph or callable.

The registry is loaded once at :func:`~agentic_blueprint.init_blueprint` time
and reused for the lifetime of the process.

Two sources of mandate guards
------------------------------
1. **Platform defaults** — SDK team edits :data:`PLATFORM_MANDATE_FACTORIES`.
   These are always present for every project.

2. **Project-specific** — set during project onboarding in the Control
   Plane's ``mandate_guardrails`` column (comma-separated class names).
   Resolved at ``init_blueprint()`` time from the credential row.

At load time the final mandate list is::

    [*platform_mandates, *project_mandates]

Developers add their own guards on top via ``wrap(graph, guards=[...])``.

Available guardrail/policy class names for the Control Plane
------------------------------------------------------------
The :data:`GUARDRAIL_CLASS_REGISTRY` maps short names (stored in the
Control Plane table) to zero-argument factories.  To make a new
guardrail/policy available for project-level mandating:

1. Implement the class in ``guardrails/`` or ``policies/``.
2. Add an entry to :data:`GUARDRAIL_CLASS_REGISTRY` below.
3. Platform admins can now add the name to any project's
   ``mandate_guardrails`` column.

Usage inside the SDK (not developer-facing)::

    from agentic_blueprint.governance.profile import get_mandate_guards

    mandate = get_mandate_guards()
    all_guards = [*mandate, *developer_guards]
"""

from __future__ import annotations

import json
import logging
import threading
from typing import Any, Callable, Sequence

from agentic_blueprint.governance.audit import AuditGuard
from agentic_blueprint.governance.guards import GovernanceGuard
from agentic_blueprint.governance.risk import RiskClass
from agentic_blueprint.governance.guardrails import (
    ContentFilterGuardrail,
    GroundingGuardrail,
    HallucinationGuardrail,
    InputPIIGuardrail,
    OutputPIIGuardrail,
    PromptInjectionGuardrail,
    SchemaValidatorGuardrail,
    ToolExecutionGuardrail,
    TopicRestrictionGuardrail,
    ToxicityGuardrail,
)
from agentic_blueprint.governance.policies import (
    BudgetPolicy,
    MaxStepsPolicy,
    ModelAllowlistPolicy,
    RateLimitPolicy,
    TimeoutPolicy,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Type alias
# ---------------------------------------------------------------------------

GuardFactory = Callable[..., GovernanceGuard]


# ---------------------------------------------------------------------------
# 1. PLATFORM MANDATES — SDK team edits this dict.
#
# These guards run on EVERY project.  Order matters (execution order).
# To add a new platform-wide mandate: add a line here.
# To remove one: delete the line.
# ---------------------------------------------------------------------------

PLATFORM_MANDATE_FACTORIES: dict[str, GuardFactory] = {
    "ModelAllowlistPolicy": ModelAllowlistPolicy,   # CISO-approved models only
    "AuditGuard":           AuditGuard,              # Structured audit trail (all levels)
}


# ---------------------------------------------------------------------------
# 1b. PLATFORM DEFAULTS — always-present safety nets.
#
# Unlike mandates, developers CAN override these by passing their own
# instance of the same policy in ``wrap(guards=[...])``.
# If they don't, the platform default is auto-injected by ``wrap()``.
#
# These are NOT included in collision detection — no GovernanceError
# is raised if a developer passes their own MaxStepsPolicy, etc.
# ---------------------------------------------------------------------------

PLATFORM_DEFAULT_FACTORIES: dict[str, GuardFactory] = {
    "MaxStepsPolicy": lambda: MaxStepsPolicy(max_steps=50),
    "BudgetPolicy":   lambda: BudgetPolicy(max_tokens=500_000),
    "TimeoutPolicy":  lambda: TimeoutPolicy(timeout_seconds=600),
}


# ---------------------------------------------------------------------------
# 2. GUARDRAIL CLASS REGISTRY — name → class mapping.
#
# The Control Plane stores guardrail names + config per project.
# This registry resolves those names to actual classes.
#
# To make a new guardrail/policy available for per-project mandating,
# add an entry here.
# ---------------------------------------------------------------------------

GUARDRAIL_CLASS_REGISTRY: dict[str, GuardFactory] = {
    # Policies (before_node)
    "ModelAllowlistPolicy": ModelAllowlistPolicy,
    "TimeoutPolicy":        TimeoutPolicy,
    "BudgetPolicy":         BudgetPolicy,
    "MaxStepsPolicy":       MaxStepsPolicy,
    "RateLimitPolicy":      RateLimitPolicy,
    # Guardrails (after_node — output)
    "OutputPIIGuardrail":        OutputPIIGuardrail,
    "ContentFilterGuardrail":    ContentFilterGuardrail,
    "GroundingGuardrail":        GroundingGuardrail,
    "SchemaValidatorGuardrail":  SchemaValidatorGuardrail,
    "ToxicityGuardrail":         ToxicityGuardrail,
    "HallucinationGuardrail":    HallucinationGuardrail,
    # Guardrails (before_node — input)
    "PromptInjectionGuardrail":  PromptInjectionGuardrail,
    "InputPIIGuardrail":         InputPIIGuardrail,
    "TopicRestrictionGuardrail": TopicRestrictionGuardrail,
    # Guardrails (before_node + after_node — tool I/O)
    "ToolExecutionGuardrail":    ToolExecutionGuardrail,
    # Audit
    "AuditGuard": AuditGuard,
}


# ---------------------------------------------------------------------------
# 3. RISK-BASED GUARD PROFILES
#
# Each risk level defines the MINIMUM guards that are auto-applied.
# Guards are additive: HIGH includes MEDIUM, MEDIUM includes LOW.
#
# LOW:    Lightweight monitoring — model allowlist + audit only.
# MEDIUM: Full policy checks — all platform + project mandates (default).
# HIGH:   Maximum safety — adds all input + output safety guardrails.
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Default block-response messages for mandate guardrails.
#
# When a mandate guard blocks, it returns this message instead of raising
# an exception.  The developer's application code sees the message in
# result["response"] and decides how to render it in their UI.
#
# This is NON-OVERRIDABLE by developers.  Mandate guards always use
# these messages.
# ---------------------------------------------------------------------------

_BLOCK_RESPONSES: dict[str, str] = {
    "PromptInjectionGuardrail": (
        "Your request has been flagged as a potential security concern "
        "and cannot be processed."
    ),
    "InputPIIGuardrail": (
        "Please do not share personal data such as emails, phone numbers, "
        "credit card numbers, or government IDs."
    ),
    "ToxicityGuardrail": (
        "Your message has been flagged for harmful or threatening content. "
        "Please rephrase your request respectfully."
    ),
}


# MEDIUM guards: input/output PII + prompt injection + toxicity + tool safety.
# These run on all MEDIUM and HIGH agents.
# scan_context=True ensures mandate guards scan ALL pipeline context values,
# not just messages — catches PII / toxicity in intermediate data fields.
_MEDIUM_RISK_EXTRA_FACTORIES: dict[str, GuardFactory] = {
    "PromptInjectionGuardrail": lambda: PromptInjectionGuardrail(
        block_response=_BLOCK_RESPONSES["PromptInjectionGuardrail"],
        scan_context=True,
    ),
    "InputPIIGuardrail": lambda: InputPIIGuardrail(
        block_response=_BLOCK_RESPONSES["InputPIIGuardrail"],
        scan_context=True,
    ),
    "OutputPIIGuardrail": lambda: OutputPIIGuardrail(scan_context=True),
    "ToxicityGuardrail": lambda: ToxicityGuardrail(
        block_response=_BLOCK_RESPONSES["ToxicityGuardrail"],
        scan_context=True,
    ),
    "ToolExecutionGuardrail": ToolExecutionGuardrail,
}

# HIGH-only guards: added on top of MEDIUM for high-risk agents.
_HIGH_RISK_EXTRA_FACTORIES: dict[str, GuardFactory] = {
    "ContentFilterGuardrail": lambda: ContentFilterGuardrail(scan_context=True),
}


def get_all_risk_guard_names(risk_class: RiskClass) -> set[str]:
    """Return the names of all guards that will be auto-applied for *risk_class*.

    This is used by :func:`wrap` for collision detection — if a developer
    passes a guard whose name appears in this set, a :class:`GovernanceError`
    is raised with a helpful message.

    Note: Platform defaults (MaxStepsPolicy, BudgetPolicy, TimeoutPolicy)
    are NOT included — developers are allowed to override those.
    """
    # Start with platform mandates + project mandates
    names = {
        g.name for g in get_mandate_guards()
    } | set(PLATFORM_MANDATE_FACTORIES.keys())

    if risk_class in (RiskClass.MEDIUM, RiskClass.HIGH):
        names |= set(_MEDIUM_RISK_EXTRA_FACTORIES.keys())

    if risk_class == RiskClass.HIGH:
        names |= set(_HIGH_RISK_EXTRA_FACTORIES.keys())

    return names


def get_risk_guards(
    risk_class: RiskClass,
    *,
    block_responses: dict[str, str] | None = None,
) -> list[GovernanceGuard]:
    """Return the guards required for the given *risk_class*.

    These are prepended before developer guards and are **non-overridable**.
    The logic is additive:

    - **LOW**:    Platform mandates only (ModelAllowlistPolicy + AuditGuard).
    - **MEDIUM**: LOW + PromptInjectionGuardrail + InputPIIGuardrail +
      OutputPIIGuardrail + ToxicityGuardrail + ToolExecutionGuardrail.
    - **HIGH**:   MEDIUM + ContentFilterGuardrail.

    Platform defaults (MaxStepsPolicy, BudgetPolicy, TimeoutPolicy) are
    injected separately by :func:`wrap` and are developer-overridable.

    Parameters
    ----------
    risk_class:
        Risk level for the agent.
    block_responses:
        Developer-supplied overrides for the default ``block_response``
        messages on mandate guardrails.  Keys are guardrail class names
        (e.g. ``"PromptInjectionGuardrail"``).  Values replace the
        platform default message.  This lets developers customise the
        user-facing text without removing or weakening the guardrail.

    Returns
    -------
    list[GovernanceGuard]
        Ordered list of guards for this risk level.
    """
    # ALL levels start with mandate guards (platform + project)
    mandate = list(get_mandate_guards())

    if risk_class == RiskClass.LOW:
        return mandate

    # MEDIUM+: merge developer block-response overrides with defaults
    effective_msgs = dict(_BLOCK_RESPONSES)
    if block_responses:
        effective_msgs.update(block_responses)

    # MEDIUM: add PII guards + prompt injection + toxicity + tool execution
    # scan_context=True on all content-scanning guards so mandates inspect
    # every pipeline context value, not only the messages list.
    medium_factories: dict[str, Callable[[], GovernanceGuard]] = {
        "PromptInjectionGuardrail": lambda: PromptInjectionGuardrail(
            block_response=effective_msgs.get("PromptInjectionGuardrail"),
            scan_context=True,
        ),
        "InputPIIGuardrail": lambda: InputPIIGuardrail(
            block_response=effective_msgs.get("InputPIIGuardrail"),
            scan_context=True,
        ),
        "OutputPIIGuardrail": lambda: OutputPIIGuardrail(scan_context=True),
        "ToxicityGuardrail": lambda: ToxicityGuardrail(
            block_response=effective_msgs.get("ToxicityGuardrail"),
            scan_context=True,
        ),
        "ToolExecutionGuardrail": ToolExecutionGuardrail,
    }

    mandate_names = {g.name for g in mandate}
    for name, factory in medium_factories.items():
        if name not in mandate_names:
            mandate.append(factory())
            logger.info("Risk MEDIUM+: added %s", name)

    if risk_class == RiskClass.HIGH:
        # HIGH: add content filter on top of MEDIUM
        high_factories: dict[str, Callable[[], GovernanceGuard]] = {
            "ContentFilterGuardrail": lambda: ContentFilterGuardrail(scan_context=True),
        }

        mandate_names = {g.name for g in mandate}
        for name, factory in high_factories.items():
            if name not in mandate_names:
                mandate.append(factory())
                logger.info("Risk HIGH: added %s", name)

    return mandate


# ---------------------------------------------------------------------------
# Instantiated guards — populated once by load_profile(), read-many.
# ---------------------------------------------------------------------------

_mandate_guards: list[GovernanceGuard] = []
_mandate_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Profile lifecycle
# ---------------------------------------------------------------------------


def load_profile(project_mandate_guardrails: str = "") -> None:
    """Instantiate mandate guards and cache them for the process lifetime.

    Called once by ``init_blueprint()``.  Subsequent calls are no-ops.

    Parameters
    ----------
    project_mandate_guardrails:
        JSON string from the Control Plane's ``mandate_guardrails`` field.
        Expected format: a JSON array of objects, each with ``"name"``
        and optional ``"config"`` dict::

            [
                {"name": "OutputPIIGuardrail", "config": {}},
                {"name": "TimeoutPolicy", "config": {"timeout_seconds": 120}}
            ]

        Empty string or ``"[]"`` means no project-specific mandates.
    """
    if _mandate_guards:  # already loaded
        return

    with _mandate_lock:
        if _mandate_guards:  # double-check after acquiring lock
            return

        # --- Platform mandates (always present) ---
        for name, factory in PLATFORM_MANDATE_FACTORIES.items():
            _mandate_guards.append(factory())
            logger.debug("Platform mandate loaded: %s", name)

        # --- Project-specific mandates (from Control Plane table) ---
        guardrail_entries = _parse_guardrail_json(project_mandate_guardrails)
        for entry in guardrail_entries:
            name = entry.get("name", "")
            config: dict[str, Any] = entry.get("config", {})

            if not name:
                continue

            # Skip if already present as a platform mandate
            if name in PLATFORM_MANDATE_FACTORIES:
                logger.debug(
                    "Project mandate '%s' skipped — already a platform mandate", name,
                )
                continue

            factory = GUARDRAIL_CLASS_REGISTRY.get(name)
            if factory is None:
                logger.warning(
                    "Unknown guardrail '%s' in project mandate_guardrails — skipped. "
                    "Available: %s",
                    name,
                    ", ".join(sorted(GUARDRAIL_CLASS_REGISTRY)),
                )
                continue

            # Instantiate with config kwargs (e.g. timeout_seconds=120)
            try:
                guard = factory(**config) if config else factory()
            except Exception as exc:
                logger.warning(
                    "Failed to instantiate '%s' with config %s: %s — using defaults",
                    name, config, exc,
                )
                try:
                    guard = factory()
                except Exception as exc2:
                    logger.warning(
                        "Failed to instantiate '%s' with defaults: %s — skipped",
                        name, exc2,
                    )
                    continue

            _mandate_guards.append(guard)
            logger.info("Project mandate loaded: %s (config=%s)", name, config or "defaults")

        logger.info(
            "Governance profile loaded: %d mandate guard(s) — %s",
            len(_mandate_guards),
            ", ".join(g.name for g in _mandate_guards),
        )


def get_mandate_guards() -> Sequence[GovernanceGuard]:
    """Return the mandate guards for the current process.

    If the profile has not been loaded yet (e.g. ``init_blueprint()`` was
    not called), returns an empty list -- governance still works, it
    just won't auto-inject mandates.
    """
    return list(_mandate_guards)


def get_platform_defaults() -> list[GovernanceGuard]:
    """Return platform default guards (safety nets).

    These are always-present defaults that developers **CAN** override.
    If a developer passes their own instance of the same policy class
    in ``wrap(guards=[...])``, the developer's version replaces the
    platform default — no collision error is raised.

    If the developer doesn't provide one, the platform default is
    auto-injected to ensure basic safety limits are always in place.

    Current defaults:

    - ``MaxStepsPolicy(max_steps=50)``  — prevents infinite loops
    - ``BudgetPolicy(max_tokens=500_000)`` — prevents runaway costs
    - ``TimeoutPolicy(timeout_seconds=600)`` — prevents hung agents

    Returns
    -------
    list[GovernanceGuard]
        Default instances, one per factory in
        :data:`PLATFORM_DEFAULT_FACTORIES`.
    """
    return [factory() for factory in PLATFORM_DEFAULT_FACTORIES.values()]


def is_profile_loaded() -> bool:
    """Whether :func:`load_profile` has been called."""
    return bool(_mandate_guards)


def reset_profile() -> None:
    """Clear all loaded mandate guards.

    Intended for **test isolation only**.  Calling this in production is
    not supported — mandate guards should remain immutable for the
    process lifetime.
    """
    _mandate_guards.clear()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _parse_guardrail_json(raw: str) -> list[dict[str, Any]]:
    """Parse the mandate_guardrails JSON string into a list of dicts.

    Handles:
    - Empty string / "[]" → []
    - Valid JSON array → list of {"name": ..., "config": ...}
    - Malformed JSON → logs warning, returns []
    """
    if not raw or raw.strip() in ("", "[]"):
        return []
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, list):
            return parsed
        logger.warning("mandate_guardrails is not a JSON array: %s", type(parsed).__name__)
        return []
    except (json.JSONDecodeError, TypeError) as exc:
        logger.warning("Failed to parse mandate_guardrails JSON: %s", exc)
        return []
