"""Token / cost budget policy.

Caps total token usage or estimated cost for a single graph invocation so
runaway loops don't burn budget.
"""

from __future__ import annotations

from agentic_blueprint.exceptions import BudgetExceededError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.policies.base import Policy


class BudgetPolicy(Policy):
    """Block execution when token or cost budgets are exceeded."""

    def __init__(
        self,
        max_tokens: int | None = None,
        max_cost: float | None = None,
        *,
        block_response: str | None = None,
    ) -> None:
        self._max_tokens = max_tokens
        self._max_cost = max_cost
        self._block_response = block_response

    async def check(self, ctx: ExecutionContext) -> None:
        if self._max_tokens is not None and ctx.total_tokens >= self._max_tokens:
            raise BudgetExceededError(
                f"Token budget exhausted: {ctx.total_tokens}/{self._max_tokens}",
                block_response=self._block_response,
            )
        if self._max_cost is not None and ctx.total_cost >= self._max_cost:
            raise BudgetExceededError(
                f"Cost budget exhausted: ${ctx.total_cost:.4f}/${self._max_cost:.4f}",
                block_response=self._block_response,
            )
