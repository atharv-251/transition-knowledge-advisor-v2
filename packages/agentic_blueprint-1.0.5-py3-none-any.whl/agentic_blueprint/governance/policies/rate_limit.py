"""Simple in-process rate-limiter policy.

Uses a sliding-window counter per agent to restrict how many node executions
can occur within a configurable window.  This is *not* a distributed rate
limiter -- it protects a single process.

Inactive agents are evicted when the agent count exceeds
``max_tracked_agents`` to prevent unbounded memory growth.
"""

from __future__ import annotations

import time
from collections import defaultdict, deque

from agentic_blueprint.exceptions import RateLimitExceededError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.policies.base import Policy

DEFAULT_MAX_CALLS = 100
DEFAULT_WINDOW_SECONDS = 60.0
DEFAULT_MAX_TRACKED_AGENTS = 1000


class RateLimitPolicy(Policy):
    """Reject if the agent exceeds ``max_calls`` within ``window_seconds``."""

    def __init__(
        self,
        max_calls: int = DEFAULT_MAX_CALLS,
        window_seconds: float = DEFAULT_WINDOW_SECONDS,
        max_tracked_agents: int = DEFAULT_MAX_TRACKED_AGENTS,
        *,
        block_response: str | None = None,
    ) -> None:
        self._max_calls = max_calls
        self._window = window_seconds
        self._max_tracked_agents = max_tracked_agents
        self._windows: dict[str, deque[float]] = defaultdict(deque)
        self._block_response = block_response

    async def check(self, ctx: ExecutionContext) -> None:
        now = time.monotonic()
        window = self._windows[ctx.agent_name]

        # Evict expired timestamps
        while window and window[0] <= now - self._window:
            window.popleft()

        if len(window) >= self._max_calls:
            raise RateLimitExceededError(
                f"Agent '{ctx.agent_name}' exceeded {self._max_calls} "
                f"calls/{self._window}s",
                block_response=self._block_response,
            )

        window.append(now)

        # Evict inactive agents when the table grows too large
        if len(self._windows) > self._max_tracked_agents:
            empty_keys = [k for k, v in self._windows.items() if not v]
            for k in empty_keys:
                del self._windows[k]
