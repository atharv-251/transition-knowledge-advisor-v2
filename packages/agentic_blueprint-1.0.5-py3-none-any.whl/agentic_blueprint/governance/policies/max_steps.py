"""Max-steps policy -- prevents infinite loops.

When placed on a **node-level** guards list (via
``graph.add_node(name, fn, guards=[MaxStepsPolicy(max_steps=N)])``),
the policy counts how many times **that specific node** has been executed
within the current ``ainvoke`` call.  This means
``MaxStepsPolicy(max_steps=3)`` on the critic node allows the critic to
run up to 3 times -- independent of how many other nodes have executed.

When placed on the **graph-level** pipeline (via
``graph.add_guards(MaxStepsPolicy(max_steps=N))``), it acts as a
global safety net using the total step count across all nodes.
"""

from __future__ import annotations

from agentic_blueprint.exceptions import PolicyViolationError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.policies.base import Policy

DEFAULT_MAX_STEPS = 10


class MaxStepsPolicy(Policy):
    """Raise when node executions exceed ``max_steps``.

    Uses ``ctx.node_step_count`` (per-node count) when available,
    otherwise falls back to ``ctx.step_count`` (global count).
    """

    def __init__(
        self,
        max_steps: int = DEFAULT_MAX_STEPS,
        *,
        block_response: str | None = None,
    ) -> None:
        self._max_steps = max_steps
        self._block_response = block_response

    async def check(self, ctx: ExecutionContext) -> None:
        # Prefer per-node count (set by AgentGraph when node-level guards are used)
        count = ctx.node_step_count if ctx.node_step_count > 0 else ctx.step_count
        if count > self._max_steps:
            raise PolicyViolationError(
                policy="max_steps",
                detail=(
                    f"Node '{ctx.node_name}' execution limit reached "
                    f"({count}/{self._max_steps})"
                ),
                block_response=self._block_response,
            )
