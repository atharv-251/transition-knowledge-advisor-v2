"""CISO model-allowlist policy.

Only models explicitly approved by VW CISO may be used.  Any attempt to
call a disallowed model raises ``ModelNotAllowedError`` before the LLM is
invoked.
"""

from __future__ import annotations

from agentic_blueprint.exceptions import ModelNotAllowedError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.policies.base import Policy

# Default allowlist aligned with full VW LLMaaS catalogue.
# See: https://llmapi.ai.vwgroup.com docs for the current model list.
DEFAULT_ALLOWED_MODELS: frozenset[str] = frozenset(
    {
        # Chat Completions (/v1/chat/completions)
        "gpt-4o",
        "gpt-4o-mini",
        "gpt-4.1",
        "gpt-4.1-mini",
        "gpt-4.1-nano",
        # Responses API (/v1/responses) -- GPT-5 family
        "gpt-5",
        "gpt-5-mini",
        "gpt-5-nano",
        "gpt-5-chat",
        "gpt-5.1",
        "gpt-5.1-chat",
        "gpt-5.2",
        # Image Generation (/v1/images/generations)
        "gpt-image-1",
        "gpt-image-1-mini",
        # OCR (/v1/ocr)
        "mistral-document-ai-2505",
        # Realtime Voice (/v1/realtime)
        "gpt-realtime",
    }
)


class ModelAllowlistPolicy(Policy):
    """Block execution if the configured model is not on the allowlist."""

    def __init__(
        self,
        allowed_models: frozenset[str] | None = None,
        *,
        block_response: str | None = None,
    ) -> None:
        self._allowed = allowed_models or DEFAULT_ALLOWED_MODELS
        self._block_response = block_response

    async def check(self, ctx: ExecutionContext) -> None:
        model = ctx.governance_config.get("model")
        if model and model not in self._allowed:
            raise ModelNotAllowedError(
                model=model,
                allowed=sorted(self._allowed),
                block_response=self._block_response,
            )
