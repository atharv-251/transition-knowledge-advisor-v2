"""Abstract base for governance policies.

A policy is a lightweight check that runs in the **before_node** phase of the
guards pipeline.  It inspects the :class:`ExecutionContext` and either:

* returns silently (pass), or
* raises a ``GovernanceError`` subclass (block).
"""

from __future__ import annotations

import abc

from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guards import GovernanceGuard


class Policy(GovernanceGuard, abc.ABC):
    """Abstract governance policy.

    Subclasses implement ``check`` which is called during ``before_node``.
    """

    @abc.abstractmethod
    async def check(self, ctx: ExecutionContext) -> None:
        """Validate the execution context.  Raise on violation."""

    async def before_node(self, ctx: ExecutionContext) -> ExecutionContext:
        await self.check(ctx)
        return ctx
