"""Timeout policy -- wall-clock limit for a single graph invocation.

Checked *before* each node.  The actual cancellation happens at the
LangGraph level via ``asyncio.timeout`` in ``AgentGraph.ainvoke``, but this
policy provides an early, descriptive rejection.
"""

from __future__ import annotations

from agentic_blueprint.exceptions import TimeoutExceededError
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.policies.base import Policy

DEFAULT_TIMEOUT_SECONDS = 300.0  # 5 minutes


class TimeoutPolicy(Policy):
    """Reject if total elapsed time exceeds the configured limit."""

    def __init__(
        self,
        timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
        *,
        block_response: str | None = None,
    ) -> None:
        self._timeout = timeout_seconds
        self._block_response = block_response

    async def check(self, ctx: ExecutionContext) -> None:
        if ctx.elapsed_seconds >= self._timeout:
            raise TimeoutExceededError(
                f"Graph execution exceeded {self._timeout}s timeout "
                f"(elapsed: {ctx.elapsed_seconds:.1f}s)",
                block_response=self._block_response,
            )
