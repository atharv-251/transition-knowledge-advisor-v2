"""Execution context -- rich data object passed through the guards pipeline.

Every guard receives and may mutate this context.  It carries identity,
state, metrics, and timing for the current node execution.

The ``project_id`` field is set from either the ``AgenticBlueprintSettings`` defaults
or per-invocation overrides, ensuring every governance check and audit
event carries the correct project identity.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ExecutionContext:
    """Context flowing through the governance guards pipeline."""

    # -- Identity -----------------------------------------------
    agent_name: str
    node_name: str
    trace_id: str
    session_id: str | None = None
    user_id: str | None = None
    workflow_id: str | None = None

    # -- Project identity ---------------------------------------
    project_id: str | None = None

    # -- Risk classification ------------------------------------
    risk_class: str = "medium"  # "low" | "medium" | "high"

    # -- Agent identity & lifecycle -----------------------------
    agent_id: str | None = None
    agent_version: str | None = None
    lifecycle: str = "active"  # "active" | "deprecated" | "retired"

    # -- State --------------------------------------------------
    input_state: dict[str, Any] = field(default_factory=dict)
    output_state: dict[str, Any] | None = None
    error: BaseException | None = None

    # -- Metrics ------------------------------------------------
    step_count: int = 0
    node_step_count: int = 0  # how many times *this* node has executed
    total_tokens: int = 0
    total_cost: float = 0.0

    # -- Timing -------------------------------------------------
    started_at: float = field(default_factory=time.time)
    node_started_at: float = field(default_factory=time.time)

    # -- Metadata -----------------------------------------------
    tags: list[str] = field(default_factory=list)
    governance_config: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def elapsed_seconds(self) -> float:
        """Wall-clock seconds since the graph invocation started."""
        return time.time() - self.started_at

    @property
    def node_elapsed_seconds(self) -> float:
        """Wall-clock seconds since this node started."""
        return time.time() - self.node_started_at

    @property
    def project_context(self) -> dict[str, str | None]:
        """Return a dict of project identity fields for easy propagation."""
        return {
            "project_id": self.project_id,
            "user_id": self.user_id,
        }
