"""Platform initialisation state and gating.

This module holds the lightweight platform state that tracks whether
``init_blueprint()`` has been called.  All factory functions
(``get_llm()``, ``wrap()``, ``pipeline()``, etc.) call
``require_platform_init()`` to ensure the developer bootstrapped the
SDK before using any component.

.. versionchanged:: 0.4.4
   Control Plane validation, ``ProjectRegistry``, ``ControlPlaneGate``,
   TTL re-validation, and all related network calls were **removed**.
   ``project_id`` and ``workflow_id`` are now purely optional metadata
   used for Langfuse trace tagging only.
"""

from __future__ import annotations

import logging

from agentic_blueprint.exceptions import ConfigurationError

logger = logging.getLogger(__name__)


# -- Centralised platform state ---------------------------------


class _PlatformState:
    """Single object holding all mutable module-level state.

    Avoids scattered ``global`` variables by grouping them into one
    instance.  All public helpers delegate to this object.
    """

    __slots__ = (
        "initialized",
        "project_id",
        "default_user_id",
    )

    def __init__(self) -> None:
        self.initialized: bool = False
        self.project_id: str | None = None
        self.default_user_id: str | None = None

    def reset(self) -> None:
        """Reset all state to defaults (for testing)."""
        self.initialized = False
        self.project_id = None
        self.default_user_id = None


# Module-level singleton -- the only mutable state in this module.
_state = _PlatformState()


# -- Platform initialization gate -------------------------------


def mark_platform_initialized(project_id: str = "") -> None:
    """Called by ``init_blueprint()`` after successful bootstrap.

    Sets the global gate that all factory functions check.

    Parameters
    ----------
    project_id : str, optional
        Optional project identifier (used for Langfuse trace tagging).
    """
    _state.initialized = True
    _state.project_id = project_id or None
    logger.debug(
        "Platform initialized (project_id=%s)",
        project_id or "(not set)",
    )


def is_platform_initialized() -> bool:
    """Whether ``init_blueprint()`` has been called successfully."""
    return _state.initialized


def require_platform_init() -> None:
    """Gate check -- ensures ``init_blueprint()`` was called.

    Called by every factory function (``get_llm()``, ``get_image_model()``,
    ``wrap()``, ``pipeline()``, etc.) to enforce correct bootstrapping.

    Raises
    ------
    ConfigurationError
        If ``init_blueprint()`` was not called.
    """
    if not _state.initialized:
        raise ConfigurationError(
            "Agentic Blueprint platform not initialised. Call init_blueprint() before using "
            "any SDK component:\n"
            "  from agentic_blueprint import init_blueprint\n"
            "  settings = init_blueprint()"
        )


def reset_platform_initialization() -> None:
    """Reset the initialisation gate (for testing only)."""
    _state.reset()


def get_default_user_id() -> str | None:
    """Return the ``user_id`` resolved from the credential registry.

    This is set once during ``init_blueprint()`` by looking up the
    ``AGENTIC_BLUEPRINT_SECRET_KEY`` in the ``ab_api_credentials`` table.

    Used by ``AgentGraph.ainvoke()`` as a fallback when the caller does not
    pass an explicit ``user_id``.  Developers can always override it::

        await graph.ainvoke(state, user_id="alice")  # overrides the default

    Returns ``None`` if the credential table was not consulted (e.g. no
    ``AGENTIC_BLUEPRINT_DATABASE_URL`` is set or the key was not found).
    """
    return _state.default_user_id


def get_platform_project_id() -> str | None:
    """Return the ``project_id`` resolved during ``init_blueprint()``.

    Set from ``AGENTIC_BLUEPRINT_PROJECT_ID`` env var.  Used by
    ``AgentGraph`` as a fallback when no explicit ``project_id`` is
    passed at construction or invocation time.
    """
    return _state.project_id or None


def set_default_user_id(user_id: str | None) -> None:
    """Set the process-level default user_id (called by ``init_blueprint()``)."""
    _state.default_user_id = user_id
