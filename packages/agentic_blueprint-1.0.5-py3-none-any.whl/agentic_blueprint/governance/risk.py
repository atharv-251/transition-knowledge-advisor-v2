"""Risk classification for agentic systems.

Every agent/workflow should declare its risk level, which determines
the minimum governance profile automatically applied.

Three tiers
-----------
- **LOW**   — lightweight monitoring (model allowlist + audit only).
  Suitable for simple FAQ bots and read-only assistants.

- **MEDIUM** — full policy checks + risk-based mandates (default).
  Adds PromptInjection, InputPII, OutputPII, Toxicity, and
  ToolExecution guardrails on top of LOW.

- **HIGH**  — all guardrails enforced (everything from MEDIUM plus
  content filtering).  Suitable for agents that write data, send
  emails, access sensitive systems, or interact with external users.

Usage::

    from agentic_blueprint import wrap, RiskClass

    governed = wrap(graph, name="faq-bot",   risk_class=RiskClass.LOW)
    governed = wrap(graph, name="researcher", risk_class=RiskClass.MEDIUM)
    governed = wrap(graph, name="db-agent",   risk_class=RiskClass.HIGH)

Risk guards are **additive** — HIGH includes everything from MEDIUM,
and MEDIUM includes everything from LOW.  Developers can always add
more guards on top via ``guards=[...]`` but cannot remove risk-mandated
ones.
"""

from __future__ import annotations

from enum import Enum


class RiskClass(str, Enum):
    """Agent/workflow risk classification.

    Determines the minimum governance profile applied by ``wrap()``.
    """

    LOW = "low"
    """Auto execution with lightweight monitoring.

    Guards: ModelAllowlistPolicy + AuditGuard.
    """

    MEDIUM = "medium"
    """Full logging + all policy checks (default).

    Guards: LOW + PromptInjectionGuardrail + InputPIIGuardrail +
    OutputPIIGuardrail + ToxicityGuardrail + ToolExecutionGuardrail.
    """

    HIGH = "high"
    """Maximum safety — all input + output guardrails mandatory.

    Guards: MEDIUM + ContentFilterGuardrail.
    """


class AutonomyLevel(str, Enum):
    """Autonomy level classification (VW Agentic Standards §1).

    Controls how much freedom the agent has before requiring
    human involvement.
    """

    A1_ASSISTED = "a1_assisted"
    """One-to-one interaction; agent acts as a simple tool.

    Human drives every step.  Agent is a smart autocomplete.
    """

    A2_COLLABORATIVE = "a2_collaborative"
    """Agent plans, user approves the plan before execution.

    Agent proposes actions; human greenlights each batch.
    """

    A3_DELEGATED = "a3_delegated"
    """Agent executes autonomously but PAUSES for human approval
    on high-impact actions (HITL).

    Maximum autonomy for irreversible-impact (D3) workloads.
    """

    A4_AUTONOMOUS = "a4_autonomous"
    """Fully autonomous — agent handles the entire loop including
    error correction.  No human in the loop.

    NOT permitted when ``impact=D3_IRREVERSIBLE`` (Safety Valve).
    """


class ImpactClass(str, Enum):
    """Business impact classification (VW Agentic Standards §1).

    Determines the potential damage of an agent's actions and
    constrains the maximum permissible autonomy level.
    """

    D1_ADVISORY = "d1_advisory"
    """Informational output only.  No system changes.

    Example: FAQ bot, research summary, analytics dashboard.
    """

    D2_REVERSIBLE = "d2_reversible"
    """Actions can be undone with low cost.

    Example: Booking a meeting, creating a draft, updating a ticket.
    """

    D3_IRREVERSIBLE = "d3_irreversible"
    """Financial transactions, data deletions, production changes.

    Requires autonomy ≤ A3 (Safety Valve rule).
    Example: €500k procurement order, production deployment, data purge.
    """


class DataSensitivity(str, Enum):
    """Data sensitivity classification (VW Agentic Standards §1).

    Determines logging mode and identity requirements.
    """

    PUBLIC = "public"
    """Standard documentation, public information."""

    INTERNAL = "internal"
    """Internal company data, low leakage risk."""

    CONFIDENTIAL = "confidential"
    """IP, engine specs, financial strategy."""

    SECRET = "secret"
    """Highly sensitive IP or strategy documents."""

    PII_GDPR = "pii_gdpr"
    """Private customer or employee data (GDPR-regulated).

    Requires OBO identity mode (Privacy Guard rule).
    """


class ExposureLevel(str, Enum):
    """Environmental exposure classification (VW Agentic Standards §1).

    Determines whether full payload logging is mandatory.
    """

    LEVEL_0_SYSTEM = "level_0_system"
    """No human interface; triggered by schedules or data events."""

    LEVEL_1_INTERNAL = "level_1_internal"
    """Employee-facing; authenticated via SSO."""

    LEVEL_2_PARTNER = "level_2_partner"
    """B2B-facing; authenticated via Federated ID."""

    LEVEL_3_EXTERNAL = "level_3_external"
    """Public-facing; anonymous/high adversarial risk.

    Mandatory AI-Gateway and full payload logging (Screenshot Defense).
    """


class AgentLifecycleState(str, Enum):
    """Agent lifecycle state (VW Agentic Standards §4).

    Determines whether an agent is permitted to execute.
    """

    ACTIVE = "active"
    """Agent is operational and permitted to run."""

    DEPRECATED = "deprecated"
    """Agent is scheduled for retirement.  Executes with a warning."""

    RETIRED = "retired"
    """Agent is decommissioned.  Execution is blocked at wrap() time."""
