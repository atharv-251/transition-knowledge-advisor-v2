"""GovernedBase — abstract base for all framework adapters.

Every framework adapter (LangGraph, CrewAI, AutoGen, Semantic Kernel, …)
inherits from this class.  It provides:

* Identity resolution (session, user, project, workflow)
* Langfuse trace creation and teardown
* GovernanceCtx sidecar lifecycle (create → set → cleanup)
* Pipeline orchestration integration
* ``invoke()`` sync bridge
* ``last_governance_ctx`` for evaluation access

Subclasses implement ``_execute()``: the framework-specific execution
logic that runs between governance setup and teardown.
"""

from __future__ import annotations

import abc
import asyncio
import concurrent.futures
import copy
import logging
import time
from typing import Any, Sequence

from agentic_blueprint._internal.helpers import generate_id
from agentic_blueprint.config.settings import get_settings
from agentic_blueprint.core.governance_context import (
    GovernanceCtx,
    _set_governance_ctx,
)
from agentic_blueprint.core.langfuse_client import (
    get_langfuse_client,
    _fix_trace_name,
)
from agentic_blueprint.core.pipeline import get_active_pipeline
from agentic_blueprint.governance.guards import GovernanceGuard, GuardsPipeline
from agentic_blueprint.governance.risk import RiskClass
from agentic_blueprint.governance.project_registry import (
    get_default_user_id,
    get_platform_project_id,
    require_platform_init,
)
from agentic_blueprint.observability.context import (
    set_current_trace_id,
    set_project_id,
    set_session_id,
    set_user_id,
    set_workflow_id,
)

logger = logging.getLogger(__name__)

__all__ = ["GovernedBase"]


class GovernedBase(abc.ABC):
    """Abstract base for all governed framework adapters.

    Subclasses must implement:

    * ``_execute(gov_ctx, lf, trace_id, input_state, config, **kw)``
      — run the framework and return the result dict.

    Everything else (identity resolution, trace creation, context
    lifecycle, pipeline integration, cleanup) is handled here.
    """

    # ------------------------------------------------------------------
    # Initialisation (common to all adapters)
    # ------------------------------------------------------------------

    def __init__(
        self,
        *,
        name: str,
        guards: Sequence[GovernanceGuard] = (),
        scoped_guards: dict[str, Sequence[GovernanceGuard]] | None = None,
        tags: Sequence[str] = (),
        project_id: str | None = None,
        workflow_id: str | None = None,
        risk_class: RiskClass = RiskClass.MEDIUM,
        agent_id: str | None = None,
        agent_version: str | None = None,
        lifecycle: str = "active",
    ) -> None:
        self.name = name
        self.risk_class = risk_class
        self.tags = list(tags)
        self.agent_id = agent_id
        self.agent_version = agent_version
        self.lifecycle = lifecycle

        # Project identity resolution
        settings = get_settings()
        self.project_id = (
            project_id or settings.project_id
            or get_platform_project_id() or None
        )
        self.workflow_id = workflow_id or settings.workflow_id or name

        # Guard pipelines — base guards run on every execution unit.
        # Subclasses access these to build runtime pipelines.
        self._base_guards = list(guards)
        self._scoped_guards_map = dict(scoped_guards or {})
        self._base_pipeline = GuardsPipeline(guards)
        self._node_pipelines: dict[str, GuardsPipeline] = {}

        # Runtime state
        self._step_counter: int = 0
        self._step_lock = asyncio.Lock()
        self._invoke_ctx: dict[str, Any] | None = None
        self.last_governance_ctx: GovernanceCtx | None = None

    # ------------------------------------------------------------------
    # Abstract — subclasses implement framework-specific execution
    # ------------------------------------------------------------------

    @abc.abstractmethod
    async def _execute(
        self,
        gov_ctx: GovernanceCtx,
        lf: Any | None,
        trace_id: str,
        input_state: dict[str, Any],
        config: dict[str, Any] | None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run the wrapped framework and return the result.

        Called after governance setup is complete.  ``gov_ctx`` and
        tracing contextvars are already active.

        Parameters
        ----------
        gov_ctx:
            The active governance sidecar context.
        lf:
            Langfuse client (may be ``None`` if tracing is disabled).
        trace_id:
            The Langfuse trace ID for this invocation.
        input_state:
            The (deep-copied) input state dict.
        config:
            Optional framework-specific config dict.
        **kwargs:
            Forwarded from ``ainvoke()``.

        Returns
        -------
        dict[str, Any]
            The framework's result state.
        """
        ...

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    async def ainvoke(
        self,
        input_state: dict[str, Any],
        *,
        session_id: str | None = None,
        user_id: str | None = None,
        project_id: str | None = None,
        workflow_id: str | None = None,
        config: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Invoke the governed framework.

        Handles identity resolution, trace creation, governance context
        lifecycle, and cleanup.  Subclass logic runs via ``_execute()``.
        """
        require_platform_init()
        self._step_counter = 0

        # Pipeline context (multi-agent orchestration)
        pipe_ctx = get_active_pipeline()
        is_pipeline_child = pipe_ctx is not None

        # --- Identity resolution ---
        resolved_session = (
            session_id
            or (pipe_ctx.session_id if pipe_ctx else None)
            or generate_id("sess-")
        )
        resolved_user = (
            user_id
            or (pipe_ctx.user_id if pipe_ctx else None)
            or get_default_user_id()
        )
        resolved_project = (
            project_id or self.project_id
            or (pipe_ctx.project_id if pipe_ctx else None)
            or get_platform_project_id()
        )
        resolved_workflow = workflow_id or self.workflow_id

        # --- Trace creation ---
        _cfg_trace_id = (config or {}).get("configurable", {}).get("_ab_trace_id")
        lf = get_langfuse_client()
        if is_pipeline_child:
            trace_id = pipe_ctx.trace_id
        else:
            trace_id = _cfg_trace_id or (
                lf.create_trace_id() if lf else generate_id("tr-")
            )

        # Store invocation context for node wrappers
        self._invoke_ctx = {
            "trace_id": trace_id,
            "session_id": resolved_session,
            "user_id": resolved_user,
            "project_id": resolved_project,
            "workflow_id": resolved_workflow,
        }
        if is_pipeline_child and pipe_ctx.root_span_id:
            self._invoke_ctx["pipeline_root_span_id"] = pipe_ctx.root_span_id

        # Set tracing contextvars
        set_current_trace_id(trace_id)
        set_session_id(resolved_session)
        set_user_id(resolved_user)
        set_project_id(resolved_project)
        set_workflow_id(resolved_workflow)

        # --- Governance context (sidecar) ---
        input_for_ctx = input_state if isinstance(input_state, dict) else {}
        gov_ctx = GovernanceCtx(
            trace_id=trace_id,
            session_id=resolved_session,
            user_id=resolved_user or "",
            project_id=resolved_project or "",
            workflow_id=resolved_workflow or "",
            agent_id=self.agent_id or "",
            agent_version=self.agent_version or "",
            input_state=copy.deepcopy(input_for_ctx),
        )
        ctx_token = _set_governance_ctx(gov_ctx)

        start = time.perf_counter()

        # Pipeline chain tracking
        _pipe_chain_run_id = None
        if is_pipeline_child and pipe_ctx is not None:
            _pipe_chain_run_id = pipe_ctx._start_agent_chain(
                self.name, input_for_ctx,
            )

        try:
            # --- Delegate to framework-specific execution ---
            result = await self._execute(
                gov_ctx, lf, trace_id, input_state, config, **kwargs,
            )

            # Auto-capture output
            if gov_ctx.output is None and isinstance(result, dict):
                for key in ("answer", "response", "output", "report"):
                    if key in result and isinstance(result[key], str):
                        gov_ctx.output = result[key]
                        break

            gov_ctx.output_state = result
            self.last_governance_ctx = gov_ctx

            # Report to pipeline context
            if is_pipeline_child and pipe_ctx is not None:
                pipe_ctx.node_history.extend(gov_ctx.node_history)
                pipe_ctx.agent_names.append(self.name)
                pipe_ctx.sub_trace_ids.append(trace_id)
                pipe_ctx._last_gov_ctx = gov_ctx

            if _pipe_chain_run_id is not None and pipe_ctx is not None:
                pipe_ctx._end_agent_chain(
                    _pipe_chain_run_id, self.name, result,
                )

            return result

        except Exception:
            logger.debug(
                "%s invocation failed (trace_id=%s)",
                type(self).__name__, trace_id, exc_info=True,
            )
            raise
        finally:
            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.debug(
                "%s invocation complete (trace_id=%s, steps=%d, %.1fms)",
                type(self).__name__, trace_id,
                self._step_counter, elapsed_ms,
            )

            if is_pipeline_child:
                _set_governance_ctx(None)
            else:
                if lf is not None:
                    try:
                        lf.flush()
                    except Exception:
                        logger.debug("Langfuse flush failed", exc_info=True)
                    _fix_trace_name(lf, trace_id, self.name)

                _set_governance_ctx(None)
                set_current_trace_id(None)
                set_session_id(None)
                set_user_id(None)
                set_project_id(None)
                set_workflow_id(None)

            self._invoke_ctx = None

    def invoke(
        self,
        input_state: dict[str, Any],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Synchronous wrapper around :meth:`ainvoke`."""
        import contextvars

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if loop is not None and loop.is_running():
            ctx = contextvars.copy_context()
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(
                    ctx.run, asyncio.run, self.ainvoke(input_state, **kwargs),
                ).result()
        return asyncio.run(self.ainvoke(input_state, **kwargs))

    # ------------------------------------------------------------------
    # HITL resume — unified API for non-LangGraph frameworks
    # ------------------------------------------------------------------

    def submit_hitl_decision(self, review_id: str, decision: str) -> None:
        """Submit a human decision for a pending HITL review.

        For **blocking-strategy** frameworks (CrewAI, AutoGen, SmolAgents),
        this resolves the ``asyncio.Future`` that is suspending execution,
        causing the governed agent to continue.

        For **checkpoint-strategy** frameworks (LangGraph), use the
        standard ``ainvoke(Command(resume=...), config=...)`` mechanism
        instead — this method is a no-op for those frameworks.

        Parameters
        ----------
        review_id : str
            The review identifier (``{agent}:{node}:{step_count}``).
        decision : str
            The human's decision (e.g. ``"approved"``, ``"rejected"``).

        Raises
        ------
        KeyError
            If no pending review matches *review_id*.
        NotImplementedError
            If the active HITL strategy does not support external
            decision submission.
        """
        from agentic_blueprint.governance.guardrails.hitl_strategy import (
            BlockingHITLStrategy,
        )

        # Search all guards for a BlockingHITLStrategy with the pending review
        all_guards = list(self._base_guards)
        for sg in self._scoped_guards_map.values():
            all_guards.extend(sg)

        from agentic_blueprint.governance.guardrails.human_review import HumanReviewGuard

        for guard in all_guards:
            if isinstance(guard, HumanReviewGuard):
                strategy = guard.strategy
                if isinstance(strategy, BlockingHITLStrategy):
                    if review_id in strategy.pending_reviews:
                        strategy.submit_decision(review_id, decision)
                        return

        raise KeyError(
            f"No pending HITL review with id '{review_id}'. "
            "Ensure you are using a blocking HITL strategy (CrewAI, AutoGen, etc.)."
        )
