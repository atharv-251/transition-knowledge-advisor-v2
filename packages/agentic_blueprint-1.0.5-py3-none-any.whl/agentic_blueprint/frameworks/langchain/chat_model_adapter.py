"""LangChain ``BaseChatModel`` adapter for Agentic Blueprint ``ChatModel``.

This adapter bridges Agentic Blueprint's :class:`~agentic_blueprint.core.models.ChatModel` (which
wraps raw ``openai.AsyncOpenAI``) into LangChain's
:class:`~langchain_core.language_models.BaseChatModel` interface.

**Why this matters**: Many LangChain-ecosystem frameworks (DeepAgents,
``create_react_agent``, ``ToolNode``, ``AgentExecutor``) require a
``BaseChatModel`` instance.  Without this adapter, Agentic Blueprint's ``ChatModel``
cannot be used with those frameworks because:

1. ``ChatModel`` returns OpenAI-native types (``ChatCompletionMessage``,
   ``dict``), not LangChain ``AIMessage`` objects.
2. ``BaseChatModel`` expects ``_generate`` / ``_agenerate`` methods
   returning ``ChatResult``.

This adapter converts in both directions so the VW LLMaaS + OAuth +
Langfuse tracing stack works seamlessly inside any LangChain framework.

Usage::

    from agentic_blueprint import get_llm
    from agentic_blueprint.frameworks.langchain import LLMChatModel

    # Wrap an existing ChatModel
    ab_llm = get_llm(model="gpt-4o")
    langchain_llm = LLMChatModel.from_blueprint(ab_llm)

    # Or create directly (calls get_llm internally)
    langchain_llm = LLMChatModel(model_name="gpt-4o")

    # Now use with any LangChain framework:
    from deepagents import create_deep_agent
    agent = create_deep_agent(model=langchain_llm, tools=[...])
"""

from __future__ import annotations

import logging
from typing import Any, List, Optional

from agentic_blueprint.frameworks.llm_bridge import (
    lazy_get_model,
    messages_to_dicts,
    response_to_ai_message,
    sync_from_async,
)

from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import BaseMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from pydantic import Field, PrivateAttr

logger = logging.getLogger(__name__)




class LLMChatModel(BaseChatModel):
    """LangChain-compatible wrapper around the Agentic Blueprint :class:`ChatModel`.

    Implements ``BaseChatModel`` so it can be used with **any** LangChain
    ecosystem framework: DeepAgents, ``create_react_agent``, ``ToolNode``,
    ``AgentExecutor``, LCEL chains, etc.

    The underlying ``ChatModel`` handles VW LLMaaS OAuth, API auto-selection,
    and Langfuse tracing automatically.
    """

    model_name: str = Field(default="gpt-4o", description="Model name for VW LLMaaS")
    temperature: float = Field(default=0.0, description="Sampling temperature")
    max_tokens: Optional[int] = Field(default=None, description="Max tokens for response")

    _ab_model: Any = PrivateAttr(default=None)

    # -- Construction helpers -----------------------------------

    @classmethod
    def from_blueprint(cls, chat_model: Any) -> "LLMChatModel":
        """Create from an existing :class:`~agentic_blueprint.core.models.ChatModel`.

        Usage::

            from agentic_blueprint import get_llm
            from agentic_blueprint.frameworks.langchain import LLMChatModel

            llm = get_llm(model="gpt-4o")
            langchain_llm = LLMChatModel.from_blueprint(llm)
        """
        instance = cls(
            model_name=chat_model.model,
            temperature=chat_model.temperature,
            max_tokens=chat_model.max_tokens,
        )
        instance._ab_model = chat_model
        return instance

    def _get_model(self) -> Any:
        """Lazily initialise the underlying Agentic Blueprint ``ChatModel``."""
        return lazy_get_model(
            self,
            "_ab_model",
            model=self.model_name,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )

    # -- BaseChatModel interface --------------------------------

    @property
    def _llm_type(self) -> str:
        return "agentic_blueprint-llmaas"

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """Synchronous generation -- delegates to async."""
        return sync_from_async(self._agenerate(messages, stop=stop, **kwargs))

    async def _agenerate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[Any] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """Async generation -- core implementation."""
        model = self._get_model()
        dict_messages = messages_to_dicts(messages)

        # Forward stop sequences if provided
        call_kwargs: dict[str, Any] = {**kwargs}
        if stop:
            call_kwargs["stop"] = stop

        response = await model.ainvoke(dict_messages, **call_kwargs)
        ai_message = response_to_ai_message(response)

        return ChatResult(
            generations=[ChatGeneration(message=ai_message)],
        )

    # -- Tool binding -------------------------------------------

    def bind_tools(self, tools: list[Any], **kwargs: Any) -> "LLMChatModel":
        """Return a copy with tools bound for function-calling.

        Delegates to the underlying ``ChatModel.bind_tools()`` so
        the tools are formatted for OpenAI's function-calling API.
        """
        model = self._get_model()
        bound_model = model.bind_tools(tools)

        new_instance = LLMChatModel(
            model_name=self.model_name,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )
        new_instance._ab_model = bound_model
        return new_instance


