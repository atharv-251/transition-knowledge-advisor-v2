"""LangChain ecosystem adapter -- ``BaseChatModel`` bridge.

Provides :class:`LLMChatModel` so the VW LLMaaS integration works
with **any** LangChain-based framework: DeepAgents, ``create_react_agent``,
``ToolNode``, ``AgentExecutor``, LCEL chains, etc.
"""

from agentic_blueprint.frameworks.langchain.chat_model_adapter import LLMChatModel

__all__ = [
    "LLMChatModel",
]
