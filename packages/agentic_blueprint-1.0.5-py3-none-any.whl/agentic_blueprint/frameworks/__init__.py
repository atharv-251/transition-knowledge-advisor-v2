"""Framework adapters — governed wrappers for agent frameworks.

Agentic Blueprint is a **governance platform**, not another agent framework.
It wraps existing frameworks (LangGraph, CrewAI, AutoGen, Semantic Kernel, …)
with consistent governance, tracing, and audit via ``wrap()`` — regardless
of which framework the developer chooses.

Architecture::

    GovernedBase (ABC)          — shared lifecycle, identity, tracing
      ├── GovernedGraph         — LangGraph (node monkey-patching)
      ├── GovernedCrew          — CrewAI (event-bus integration)
      └── (future adapters)     — AutoGen, Semantic Kernel, LlamaIndex, …

    llm_bridge                  — shared message conversion, token tracking
      ├── LLMChatModel          — LangChain BaseChatModel adapter
      └── CrewAILLM             — CrewAI BaseLLM adapter

Available adapters::

    agentic_blueprint.frameworks.base        — GovernedBase ABC
    agentic_blueprint.frameworks.llm_bridge  — shared LLM adapter utilities
    agentic_blueprint.frameworks.langgraph   — GovernedGraph
    agentic_blueprint.frameworks.crewai      — GovernedCrew, CrewAILLM
    agentic_blueprint.frameworks.langchain   — LLMChatModel

Register third-party adapters via :func:`~agentic_blueprint.register_framework`.
"""

from agentic_blueprint.frameworks.base import GovernedBase

__all__ = ["GovernedBase"]
