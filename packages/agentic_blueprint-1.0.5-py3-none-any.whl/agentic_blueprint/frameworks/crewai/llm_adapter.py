"""CrewAI LLM adapter — routes all LLM calls through the Agentic Blueprint SDK.

Subclasses ``crewai.llms.base_llm.BaseLLM`` so that every CrewAI agent
automatically benefits from:

* VW LLMaaS OAuth + token refresh
* API auto-selection (Chat Completions vs Responses API)
* Langfuse tracing
* Model allowlist enforcement (via governance)

Usage::

    from agentic_blueprint.frameworks.crewai import CrewAILLM

    llm = CrewAILLM(model="gpt-4o")                    # SDK default
    llm = CrewAILLM(model="gpt-5-mini", temperature=0)  # specific model

    from crewai import Agent
    agent = Agent(role="Researcher", llm=llm, ...)
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from typing import Any

from crewai.llms.base_llm import BaseLLM, LLMCallType, llm_call_context, _current_call_id
from agentic_blueprint.frameworks.llm_bridge import (
    extract_content,
    lazy_get_model,
    sync_from_async,
)

try:
    from opentelemetry import context as _otel_ctx
except ImportError:  # pragma: no cover
    _otel_ctx = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


# Context window sizes for common models
_CONTEXT_WINDOWS: dict[str, int] = {
    "gpt-4o": 128_000,
    "gpt-4o-mini": 128_000,
    "gpt-4.1": 1_047_576,
    "gpt-4.1-mini": 1_047_576,
    "gpt-4.1-nano": 1_047_576,
    "gpt-5": 1_047_576,
    "gpt-5-mini": 1_047_576,
    "gpt-5-nano": 1_047_576,
    "gpt-5.1": 1_047_576,
    "gpt-5.2": 1_047_576,
}


class CrewAILLM(BaseLLM):
    """Agentic Blueprint ``ChatModel`` exposed as a CrewAI ``BaseLLM``.

    All LLM calls are routed through the SDK's :class:`ChatModel`,
    which handles OAuth, API selection, and Langfuse tracing
    automatically.

    Parameters
    ----------
    model:
        Model name for VW LLMaaS (e.g. ``"gpt-4o"``, ``"gpt-5-mini"``).
    temperature:
        Sampling temperature.  ``None`` uses the SDK default (0.0).
    max_tokens:
        Maximum output tokens.  ``None`` = model default.
    """

    def __init__(
        self,
        model: str = "gpt-4o",
        temperature: float | None = None,
        max_tokens: int | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            model=model,
            temperature=temperature,
            provider="agentic_blueprint",
            **kwargs,
        )
        self._max_tokens = max_tokens
        self._ab_model: Any = None  # lazy init

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_model(self) -> Any:
        """Lazily create the SDK :class:`ChatModel`."""
        return lazy_get_model(
            self,
            "_ab_model",
            model=self.model,
            temperature=self.temperature or 0.0,
            max_tokens=self._max_tokens,
        )

    @classmethod
    def from_sdk(cls, chat_model: Any) -> "CrewAILLM":
        """Wrap an existing SDK :class:`ChatModel`.

        Usage::

            from agentic_blueprint import get_llm
            from agentic_blueprint.frameworks.crewai import CrewAILLM

            ab_llm = get_llm(model="gpt-5-mini")
            crewai_llm = CrewAILLM.from_sdk(ab_llm)
        """
        instance = cls(
            model=chat_model.model,
            temperature=chat_model.temperature,
            max_tokens=chat_model.max_tokens,
        )
        instance._ab_model = chat_model
        return instance

    # ------------------------------------------------------------------
    # BaseLLM interface — .call() (abstract, required)
    # ------------------------------------------------------------------

    def call(
        self,
        messages: str | list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        callbacks: list[Any] | None = None,
        available_functions: dict[str, Any] | None = None,
        from_task: Any | None = None,
        from_agent: Any | None = None,
        response_model: Any | None = None,
    ) -> str | Any:
        """Synchronous call — delegates to async via event loop.

        CrewAI agents call ``.call()`` from synchronous code while an
        async event-loop is already running (inside ``akickoff``).
        We offload to a ``ThreadPoolExecutor`` in that case.

        To preserve the Langfuse OTel trace context across the thread
        boundary we capture it before the submit and re-attach it
        inside the worker thread.  This ensures LLM generations are
        nested under the parent trace instead of creating orphan traces.
        """
        with llm_call_context():
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None

            if loop and loop.is_running():
                # Preserve OTel trace context across the thread boundary
                parent_otel_ctx = _otel_ctx.get_current() if _otel_ctx is not None else None

                def _run_in_thread() -> Any:
                    token = None
                    if _otel_ctx is not None and parent_otel_ctx is not None:
                        token = _otel_ctx.attach(parent_otel_ctx)
                    try:
                        return asyncio.run(
                            self.acall(
                                messages,
                                tools=tools,
                                callbacks=callbacks,
                                available_functions=available_functions,
                                from_task=from_task,
                                from_agent=from_agent,
                                response_model=response_model,
                            ),
                        )
                    finally:
                        if _otel_ctx is not None and token is not None:
                            _otel_ctx.detach(token)

                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    return pool.submit(_run_in_thread).result()

            return asyncio.run(
                self.acall(
                    messages,
                    tools=tools,
                    callbacks=callbacks,
                    available_functions=available_functions,
                    from_task=from_task,
                    from_agent=from_agent,
                    response_model=response_model,
                )
            )

    # ------------------------------------------------------------------
    # BaseLLM interface — .acall() (async override)
    # ------------------------------------------------------------------

    async def acall(
        self,
        messages: str | list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        callbacks: list[Any] | None = None,
        available_functions: dict[str, Any] | None = None,
        from_task: Any | None = None,
        from_agent: Any | None = None,
        response_model: Any | None = None,
    ) -> str | Any:
        """Async call — routes through the SDK ChatModel."""
        # Ensure we are inside an llm_call_context so that CrewAI
        # telemetry events have a valid call_id (avoids the
        # "LLM event emitted outside call context" warning).
        # call() already opens one; for direct acall() we open here.

        if _current_call_id.get() is None:
            # No surrounding context — open one for this acall scope.
            _current_call_id.set(str(uuid.uuid4()))

        # Emit CrewAI event: LLM call started
        self._emit_call_started_event(
            messages=messages,
            tools=tools,
            callbacks=callbacks,
            available_functions=available_functions,
            from_task=from_task,
            from_agent=from_agent,
        )

        try:
            ab_model = self._get_model()

            # Normalise messages
            formatted = self._format_messages(messages)

            # Bind tools if provided
            if tools:
                ab_model_with_tools = ab_model.bind_tools(
                    self._convert_tools_for_crewai(tools)
                )
            else:
                ab_model_with_tools = ab_model

            # Invoke the SDK ChatModel
            response = await ab_model_with_tools.ainvoke(formatted)

            # Extract content from response
            content = extract_content(response)
            # Check for tool calls
            if isinstance(response, dict):
                tool_calls = response.get("tool_calls")
            else:
                tool_calls = getattr(response, "tool_calls", None)

            # Handle tool calls
            if tool_calls and available_functions:
                for tc in tool_calls:
                    fn_name = (
                        tc.get("function", {}).get("name", "")
                        if isinstance(tc, dict)
                        else getattr(getattr(tc, "function", None), "name", "")
                    )
                    fn_args_raw = (
                        tc.get("function", {}).get("arguments", "{}")
                        if isinstance(tc, dict)
                        else getattr(getattr(tc, "function", None), "arguments", "{}")
                    )
                    fn_args = (
                        json.loads(fn_args_raw) if isinstance(fn_args_raw, str)
                        else fn_args_raw
                    )
                    result = self._handle_tool_execution(
                        fn_name,
                        fn_args,
                        available_functions,
                        from_task=from_task,
                        from_agent=from_agent,
                    )
                    if result is not None:
                        return result

            # Track token usage if available
            usage = getattr(response, "usage", None)
            if usage:
                usage_dict = (
                    usage if isinstance(usage, dict)
                    else {
                        "prompt_tokens": getattr(usage, "prompt_tokens", 0),
                        "completion_tokens": getattr(usage, "completion_tokens", 0),
                    }
                )
                self._track_token_usage_internal(usage_dict)

            # Apply stop words
            if isinstance(content, str):
                content = self._apply_stop_words(content)

            # Validate structured output if requested
            if response_model and isinstance(content, str):
                content = self._validate_structured_output(content, response_model)

            # Emit CrewAI event: LLM call completed
            self._emit_call_completed_event(
                response=content,
                call_type=LLMCallType.LLM_CALL,
                from_task=from_task,
                from_agent=from_agent,
                messages=messages,
            )

            return content

        except Exception as e:
            self._emit_call_failed_event(
                error=str(e),
                from_task=from_task,
                from_agent=from_agent,
            )
            raise

    # ------------------------------------------------------------------
    # Capability methods
    # ------------------------------------------------------------------

    def get_context_window_size(self) -> int:
        """Return context window size for the configured model."""
        return _CONTEXT_WINDOWS.get(self.model, 128_000)

    def supports_multimodal(self) -> bool:
        """SDK models support multimodal via gpt-4o and gpt-5 families."""
        return "4o" in self.model or self.model.startswith("gpt-5")

    def supports_stop_words(self) -> bool:
        """Check if stop words are configured."""
        return self._supports_stop_words_implementation()

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _convert_tools_for_crewai(
        tools: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Convert CrewAI tool schemas to OpenAI function-calling format."""
        converted = []
        for tool in tools:
            if isinstance(tool, dict) and "function" in tool:
                converted.append(tool)
            elif isinstance(tool, dict):
                converted.append({
                    "type": "function",
                    "function": tool,
                })
            else:
                converted.append(tool)
        return converted
