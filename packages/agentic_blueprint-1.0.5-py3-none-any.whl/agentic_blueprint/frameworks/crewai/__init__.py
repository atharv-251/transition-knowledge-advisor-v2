"""CrewAI framework integration -- governed multi-agent crews.

Governance is applied via ``agentic_blueprint.wrap()`` on any
CrewAI ``Crew`` instance.  Use native CrewAI APIs and wrap the result::

    from crewai import Agent, Task, Crew
    from agentic_blueprint import wrap, get_llm
    from agentic_blueprint.frameworks.crewai import CrewAILLM

    # Route all agent LLM calls through VW LLMaaS
    llm = CrewAILLM.from_sdk(get_llm())

    researcher = Agent(role="Researcher", ..., llm=llm)
    writer     = Agent(role="Writer",     ..., llm=llm)

    crew = Crew(agents=[researcher, writer], tasks=[...])

    governed = wrap(crew, name="research-crew", risk_class=RiskClass.HIGH)
    result = await governed.ainvoke({"messages": [...]})

The :class:`CrewAILLM` adapter ensures OAuth tokens, tracing,
and token accounting all flow through the SDK automatically.

The :class:`GovernedCrew` wrapper (returned by ``wrap()``) runs
guardrails, policies, and audit on crew execution and normalises
CrewAI output to the same ``{"messages": [...]}`` interface that
``GovernedGraph`` provides.
"""

import contextlib

from agentic_blueprint.frameworks.crewai.governed_crew import GovernedCrew  # noqa: F401

# CrewAILLM requires crewai to be installed (optional dependency)
with contextlib.suppress(ImportError):
    from agentic_blueprint.frameworks.crewai.llm_adapter import CrewAILLM  # noqa: F401

__all__ = [
    "GovernedCrew",
    "CrewAILLM",
]
