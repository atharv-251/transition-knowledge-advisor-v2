"""GovernedCrew — event-bus-based governance wrapper for CrewAI.

Provides the same guardrail/policy/audit/tracing behaviour that
:class:`~agentic_blueprint.core.wrap.GovernedGraph` gives LangGraph,
but hooks into CrewAI's native event bus instead of monkey-patching
graph nodes.

The wrapper supports **both** the native CrewAI interface and the
unified SDK interface::

    # Native CrewAI interface — returns CrewOutput
    governed = wrap(crew, name="my-crew", risk_class=RiskClass.HIGH)
    output = await governed.kickoff_async(inputs={"topic": "VW history"})
    output = governed.kickoff(inputs={"topic": "VW history"})

    # Unified SDK interface — returns {"messages": [...]}
    result = await governed.ainvoke({"messages": [...]})

Internally both paths delegate to ``Crew.akickoff()`` and run the
same governance pipeline (guards, policies, audit, tracing)."""

from __future__ import annotations

import asyncio
import logging
import os
import time
from collections.abc import Sequence
from typing import Any

from agentic_blueprint._internal.helpers import generate_id
from agentic_blueprint.frameworks.base import GovernedBase
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guards import GovernanceGuard, GuardsPipeline
from agentic_blueprint.governance.risk import RiskClass
from agentic_blueprint.governance.project_registry import (
    get_default_user_id,
    get_platform_project_id,
    require_platform_init,
)
from agentic_blueprint.observability.context import (
    set_current_trace_id,
    set_project_id,
    set_session_id,
    set_user_id,
    set_workflow_id,
)
from agentic_blueprint.config import get_settings
from agentic_blueprint.core.governance_context import (
    GovernanceCtx,
    _set_governance_ctx,
)
from agentic_blueprint.core.pipeline import get_active_pipeline
from agentic_blueprint.core.langfuse_client import get_langfuse_client as _get_langfuse_client
from agentic_blueprint.exceptions import GuardrailBlockedError
from agentic_blueprint.governance.policies.max_steps import MaxStepsPolicy
from agentic_blueprint.governance.policies.timeout import TimeoutPolicy

from crewai.events import crewai_event_bus
from crewai.events.types.agent_events import (
    AgentExecutionStartedEvent,
    AgentExecutionCompletedEvent,
)
from crewai.events.types.task_events import (
    TaskStartedEvent,
    TaskCompletedEvent,
)
from crewai.events.types.tool_usage_events import (
    ToolUsageStartedEvent,
    ToolUsageFinishedEvent,
    ToolUsageErrorEvent,
)

try:
    from langfuse import propagate_attributes as _propagate_attrs
except ImportError:  # pragma: no cover
    from contextlib import nullcontext as _propagate_attrs  # type: ignore[assignment]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# GovernedCrew
# ---------------------------------------------------------------------------


class GovernedCrew(GovernedBase):
    """Governance wrapper for a CrewAI :class:`Crew`.

    Intercepts lifecycle events via CrewAI's event bus to run guardrails,
    policies, and audit — the same set that :class:`GovernedGraph` uses
    for LangGraph.

    After wrapping, the developer can use either the **native CrewAI
    interface** (``kickoff`` / ``kickoff_async``) or the **unified SDK
    interface** (``ainvoke`` / ``invoke``).  Both run the same governance
    pipeline.

    Native CrewAI interface (returns ``CrewOutput``)::

        output = await governed.kickoff_async(inputs={"topic": "..."})
        output = governed.kickoff(inputs={"topic": "..."})

    Unified SDK interface (returns ``{"messages": [...]}`` dict)::

        result = await governed.ainvoke({"messages": [...]})
        result = governed.invoke({"messages": [...]})

    Langfuse trace structure::

        TRACE: my-crew
          +-- SPAN: task[0] "Research topic"
          |     +-- Guardrails: input✓ output✓
          +-- SPAN: task[1] "Write article"
          |     +-- Guardrails: input✓ output✓
          +-- Event: crew_completed (total_tokens, task_outputs)
    """

    def __init__(
        self,
        crew: Any,
        *,
        name: str,
        guards: Sequence[GovernanceGuard] = (),
        scoped_guards: dict[str, Sequence[GovernanceGuard]] | None = None,
        tags: Sequence[str] = (),
        project_id: str | None = None,
        workflow_id: str | None = None,
        risk_class: RiskClass = RiskClass.MEDIUM,
        agent_id: str | None = None,
        agent_version: str | None = None,
        lifecycle: str = "active",
    ) -> None:
        super().__init__(
            name=name,
            guards=guards,
            scoped_guards=scoped_guards,
            tags=tags,
            project_id=project_id,
            workflow_id=workflow_id,
            risk_class=risk_class,
            agent_id=agent_id,
            agent_version=agent_version,
            lifecycle=lifecycle,
        )
        self._crew = crew

        # Build scoped guard pipelines — CrewAI combines base + scoped
        self._graph_pipeline = self._base_pipeline
        if scoped_guards:
            for scope_name, ng in scoped_guards.items():
                combined = list(guards) + list(ng)
                self._node_pipelines[scope_name] = GuardsPipeline(combined)

        # CrewAI-specific state
        self._invocation_started_at: float = 0.0

        # Resolve model name from the crew's agents for ModelAllowlistPolicy
        self._model_name: str | None = self._resolve_model_name()

        # Propagate governance limits into CrewAI's native agent parameters
        self._propagate_limits_to_agents(guards)

        # Inject blocking HITL strategy into any HumanReviewGuard
        self._inject_hitl_strategy()

        # Event bus listener state (set up per-invocation)
        self._event_handlers: list[tuple[type, Any]] = []
        self._agent_spans: dict[str, Any] = {}
        self._task_spans: dict[str, Any] = {}
        self._tool_spans: dict[str, Any] = {}

    # ------------------------------------------------------------------
    # HITL strategy injection
    # ------------------------------------------------------------------

    def _inject_hitl_strategy(self) -> None:
        """Inject :class:`BlockingHITLStrategy` into all HumanReviewGuards."""
        from agentic_blueprint.governance.guardrails.human_review import HumanReviewGuard
        from agentic_blueprint.governance.guardrails.hitl_strategy import (
            BlockingHITLStrategy,
            NoOpHITLStrategy,
        )

        if not hasattr(self, "_hitl_strategy"):
            self._hitl_strategy = BlockingHITLStrategy()
        for guard in self._base_guards:
            if isinstance(guard, HumanReviewGuard) and isinstance(
                guard.strategy, NoOpHITLStrategy
            ):
                guard.strategy = self._hitl_strategy
        for guards in self._scoped_guards_map.values():
            for guard in guards:
                if isinstance(guard, HumanReviewGuard) and isinstance(
                    guard.strategy, NoOpHITLStrategy
                ):
                    guard.strategy = self._hitl_strategy

    # ------------------------------------------------------------------
    # Governance → CrewAI limit propagation
    # ------------------------------------------------------------------

    def _propagate_limits_to_agents(
        self, guards: Sequence[GovernanceGuard],
    ) -> None:
        """Push SDK governance limits into CrewAI's native agent params.

        CrewAI agents have their own ``max_iter`` and ``max_execution_time``
        parameters that control the internal ReAct loop (LLM → tool → LLM).
        Our ``MaxStepsPolicy`` and ``TimeoutPolicy`` only see *task-level*
        boundaries, not the iterations inside a task.

        This method inspects the guards for ``MaxStepsPolicy`` and
        ``TimeoutPolicy`` and sets the corresponding native limits on
        every agent in the crew — ensuring governance is enforced at
        both the SDK layer *and* the framework layer.
        """
        max_iter: int | None = None
        timeout_seconds: float | None = None

        for guard in guards:
            if isinstance(guard, MaxStepsPolicy) and max_iter is None:
                max_iter = guard._max_steps
            elif isinstance(guard, TimeoutPolicy) and timeout_seconds is None:
                timeout_seconds = guard._timeout

        agents = getattr(self._crew, "agents", None) or []

        for agent in agents:
            # Only override if the developer hasn't already set a custom limit
            if max_iter is not None:
                current = getattr(agent, "max_iter", None)
                if current is None or current >= 25:  # 25 = CrewAI default
                    agent.max_iter = max_iter
                    logger.debug(
                        "Propagated max_iter=%d to agent '%s'",
                        max_iter, getattr(agent, "role", "?"),
                    )
            if timeout_seconds is not None:
                current = getattr(agent, "max_execution_time", None)
                if current is None:
                    agent.max_execution_time = int(timeout_seconds)
                    logger.debug(
                        "Propagated max_execution_time=%ds to agent '%s'",
                        int(timeout_seconds), getattr(agent, "role", "?"),
                    )

    # ------------------------------------------------------------------
    # Event bus integration — rich Langfuse spans
    # ------------------------------------------------------------------

    def _setup_event_listeners(self) -> None:
        """Register event-bus listeners that create rich Langfuse spans.

        These replace CrewAI's own noisy telemetry spans (which have
        generic names like "Task Created", "Tool Usage") with proper
        spans that show agent role, tool name + input/output, etc.

        CrewAI's built-in telemetry is suppressed by setting
        ``CREWAI_DISABLE_TELEMETRY=true`` in :meth:`ainvoke`.
        """
        # Keep refs so we can unregister later
        self._event_handlers: list[tuple[type, Any]] = []

        # ---- Agent spans ----

        def _on_agent_started(source: Any, event: AgentExecutionStartedEvent) -> None:
            lf = _get_langfuse_client()
            if lf is None or self._invoke_ctx is None:
                return
            agent = event.agent
            role = getattr(agent, "role", "Agent")
            task_desc = ""
            if event.task:
                task_desc = getattr(event.task, "description", "")[:100]
            try:
                span = lf.start_observation(
                    name=f"Agent: {role}",
                    as_type="agent",
                    input={"task": task_desc, "tools": [
                        getattr(t, "name", str(t)) for t in (event.tools or [])
                    ]},
                    metadata={"agent_role": role},
                )
                # Store span keyed by agent id for matching on completion
                agent_id = str(getattr(agent, "id", id(agent)))
                self._agent_spans[agent_id] = span
            except Exception:
                logger.debug("Langfuse agent span creation failed", exc_info=True)

        def _on_agent_completed(source: Any, event: AgentExecutionCompletedEvent) -> None:
            agent_id = str(getattr(event.agent, "id", id(event.agent)))
            span = self._agent_spans.pop(agent_id, None)
            if span is not None:
                try:
                    output_preview = str(event.output or "")[:500]
                    span.update(output={"response": output_preview})
                    span.end()
                except Exception:
                    logger.debug("Langfuse agent span end failed", exc_info=True)

        # ---- Task spans ----

        def _on_task_started(source: Any, event: TaskStartedEvent) -> None:
            lf = _get_langfuse_client()
            if lf is None or self._invoke_ctx is None:
                return
            task = event.task
            task_desc = getattr(task, "description", "")[:100]
            agent = getattr(task, "agent", None)
            agent_role = getattr(agent, "role", "Unknown") if agent else "Unknown"
            try:
                span = lf.start_observation(
                    name=f"Task: {task_desc[:60]}",
                    as_type="span",
                    input={"description": task_desc, "agent": agent_role},
                    metadata={"agent": agent_role},
                )
                task_id = str(getattr(task, "id", id(task)))
                self._task_spans[task_id] = span
            except Exception:
                logger.debug("Langfuse task span creation failed", exc_info=True)

        def _on_task_completed(source: Any, event: TaskCompletedEvent) -> None:
            task_id = str(getattr(event.task, "id", id(event.task)))
            span = self._task_spans.pop(task_id, None)
            if span is not None:
                try:
                    output = getattr(event, "output", None) or ""
                    output_preview = str(output)[:500]
                    span.update(output={"result": output_preview})
                    span.end()
                except Exception:
                    logger.debug("Langfuse task span end failed", exc_info=True)

        # ---- Tool spans ----

        def _on_tool_started(source: Any, event: ToolUsageStartedEvent) -> None:
            lf = _get_langfuse_client()
            if lf is None or self._invoke_ctx is None:
                return
            tool_name = event.tool_name or "unknown_tool"
            tool_args = event.tool_args
            agent_role = event.agent_role or "Unknown"
            try:
                span = lf.start_observation(
                    name=f"Tool: {tool_name}",
                    as_type="tool",
                    input={"args": tool_args, "agent": agent_role},
                    metadata={"tool_name": tool_name, "agent": agent_role},
                )
                # Key by tool_name + agent to handle concurrent tools
                key = f"{agent_role}:{tool_name}:{id(event)}"
                self._tool_spans[key] = (span, tool_name, agent_role)
                # Also store the latest key for this agent+tool combo
                self._tool_spans[f"latest:{agent_role}:{tool_name}"] = key
            except Exception:
                logger.debug("Langfuse tool span creation failed", exc_info=True)

        def _on_tool_finished(source: Any, event: ToolUsageFinishedEvent) -> None:
            tool_name = event.tool_name or "unknown_tool"
            agent_role = event.agent_role or "Unknown"
            # Find matching span
            latest_key = self._tool_spans.pop(f"latest:{agent_role}:{tool_name}", None)
            if latest_key and latest_key in self._tool_spans:
                span, _, _ = self._tool_spans.pop(latest_key)
                try:
                    output = event.output
                    output_preview = str(output)[:500] if output else ""
                    span.update(output={"result": output_preview})
                    span.end()
                except Exception:
                    logger.debug("Langfuse tool span end failed", exc_info=True)

        def _on_tool_error(source: Any, event: ToolUsageErrorEvent) -> None:
            tool_name = event.tool_name or "unknown_tool"
            agent_role = event.agent_role or "Unknown"
            latest_key = self._tool_spans.pop(f"latest:{agent_role}:{tool_name}", None)
            if latest_key and latest_key in self._tool_spans:
                span, _, _ = self._tool_spans.pop(latest_key)
                try:
                    span.update(
                        output={"error": str(event.error)[:500]},
                        level="ERROR",
                    )
                    span.end()
                except Exception:
                    logger.debug("Langfuse tool error span end failed", exc_info=True)

        # Register all handlers
        handlers = [
            (AgentExecutionStartedEvent, _on_agent_started),
            (AgentExecutionCompletedEvent, _on_agent_completed),
            (TaskStartedEvent, _on_task_started),
            (TaskCompletedEvent, _on_task_completed),
            (ToolUsageStartedEvent, _on_tool_started),
            (ToolUsageFinishedEvent, _on_tool_finished),
            (ToolUsageErrorEvent, _on_tool_error),
        ]
        for event_type, handler in handlers:
            crewai_event_bus.register_handler(event_type, handler)
            self._event_handlers.append((event_type, handler))

    def _teardown_event_listeners(self) -> None:
        """Unregister event-bus listeners after invocation."""
        if not hasattr(self, "_event_handlers") or not self._event_handlers:
            return
        try:
            for event_type, handler in self._event_handlers:
                crewai_event_bus.off(event_type, handler)
        except Exception:
            logger.debug("Event listener teardown failed", exc_info=True)
        self._event_handlers.clear()
        # Clean up any lingering spans
        for attr in ("_agent_spans", "_task_spans", "_tool_spans"):
            if hasattr(self, attr):
                getattr(self, attr).clear()

    def _get_pipeline_for_task(self, task_name: str) -> GuardsPipeline:
        """Return the guard pipeline for a specific task."""
        return self._node_pipelines.get(task_name, self._graph_pipeline)

    def _build_execution_context(
        self,
        node_name: str,
        input_state: dict[str, Any],
        output_state: dict[str, Any] | None = None,
        *,
        total_tokens: int = 0,
        total_cost: float = 0.0,
    ) -> ExecutionContext:
        """Build an :class:`ExecutionContext` for guards."""
        ctx = ExecutionContext(
            agent_name=self.name,
            node_name=node_name,
            trace_id=self._invoke_ctx.get("trace_id", "") if self._invoke_ctx else "",
            session_id=self._invoke_ctx.get("session_id") if self._invoke_ctx else None,
            user_id=self._invoke_ctx.get("user_id") if self._invoke_ctx else None,
            workflow_id=self._invoke_ctx.get("workflow_id") if self._invoke_ctx else None,
            project_id=self._invoke_ctx.get("project_id") if self._invoke_ctx else None,
            risk_class=self.risk_class.value,
            input_state=input_state,
            output_state=output_state,
            step_count=self._step_counter,
            node_step_count=self._step_counter,
            total_tokens=total_tokens,
            total_cost=total_cost,
            tags=self.tags,
        )
        # Preserve the original invocation start time so TimeoutPolicy
        # sees actual elapsed wall-clock time instead of near-zero.
        if self._invocation_started_at > 0:
            ctx.started_at = self._invocation_started_at
        # Populate governance_config with model for ModelAllowlistPolicy
        if self._model_name:
            ctx.governance_config["model"] = self._model_name
        return ctx

    # ------------------------------------------------------------------
    # GovernedBase abstract — overridden by full ainvoke() below
    # ------------------------------------------------------------------

    async def _execute(
        self,
        gov_ctx: GovernanceCtx,
        lf: Any | None,
        trace_id: str,
        input_state: dict[str, Any],
        config: dict[str, Any] | None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Not used — GovernedCrew overrides ainvoke() directly."""
        raise NotImplementedError(
            "GovernedCrew overrides ainvoke() directly. "
            "This method should not be called."
        )

    # ------------------------------------------------------------------
    # ainvoke — the primary entry point (same interface as GovernedGraph)
    # ------------------------------------------------------------------

    async def ainvoke(
        self,
        input_state: dict[str, Any],
        *,
        session_id: str | None = None,
        user_id: str | None = None,
        project_id: str | None = None,
        workflow_id: str | None = None,
        config: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Unified SDK interface — returns ``{"messages": [...]}`` dict.

        Accepts the same ``{"messages": [...]}`` input format as
        ``GovernedGraph.ainvoke()`` and returns the same shape.

        Parameters
        ----------
        input_state:
            Input dict.  If it contains ``"messages"``, the last user
            message is extracted as the crew input.  Otherwise the dict
            is passed directly as ``inputs`` to ``Crew.akickoff()``.
        session_id, user_id, project_id, workflow_id:
            Identity overrides for tracing.
        config:
            Additional configuration (for API compatibility with GovernedGraph).
        """
        result, _crew_output = await self._governed_execution(
            input_state,
            session_id=session_id,
            user_id=user_id,
            project_id=project_id,
            workflow_id=workflow_id,
        )
        return result

    def invoke(
        self,
        input_state: dict[str, Any],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Synchronous invoke — delegates to :meth:`ainvoke`."""
        import contextvars

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import concurrent.futures

            ctx = contextvars.copy_context()
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(
                    ctx.run, asyncio.run, self.ainvoke(input_state, **kwargs)
                ).result()
        return asyncio.run(self.ainvoke(input_state, **kwargs))

    # ------------------------------------------------------------------
    # kickoff_async / kickoff — native CrewAI interface with governance
    # ------------------------------------------------------------------

    async def kickoff_async(
        self,
        inputs: dict[str, Any] | None = None,
        *,
        session_id: str | None = None,
        user_id: str | None = None,
        project_id: str | None = None,
        workflow_id: str | None = None,
    ) -> Any:
        """Native CrewAI interface — runs governance and returns ``CrewOutput``.

        Drop-in replacement for ``Crew.kickoff_async(inputs=...)``.
        Accepts the same ``inputs`` dict that CrewAI expects (template
        variables for task descriptions) and returns the raw
        ``CrewOutput`` object.

        The full governance pipeline (guards, policies, audit, tracing)
        runs identically to :meth:`ainvoke`.

        Parameters
        ----------
        inputs:
            Dict of template variables for CrewAI task descriptions.
            Passed directly as ``inputs`` to ``Crew.akickoff()``.
        session_id, user_id, project_id, workflow_id:
            Identity overrides for tracing.

        Returns
        -------
        CrewOutput
            The raw CrewAI output object.

        Raises
        ------
        GuardrailBlockedError
            If a guardrail blocks the input.
        """
        inputs = inputs or {}

        # Build a normalised input_state for the governance pipeline.
        # The "input" key (if present) becomes the user message so that
        # guards can scan it.  All other keys are preserved as context.
        user_content = inputs.get("input", "")
        if not user_content:
            # Use str representation of all inputs as the "user message"
            # so guards have something to scan.
            user_content = " ".join(str(v) for v in inputs.values()) if inputs else ""
        input_state: dict[str, Any] = {
            "messages": [{"role": "user", "content": user_content}],
            **{k: v for k, v in inputs.items() if k != "input"},
        }

        result, crew_output = await self._governed_execution(
            input_state,
            session_id=session_id,
            user_id=user_id,
            project_id=project_id,
            workflow_id=workflow_id,
        )

        # If guards blocked, raise instead of returning (no CrewOutput)
        if crew_output is None:
            blocked_msg = result.get("response", "Request blocked by governance guardrail.")
            raise GuardrailBlockedError(
                guardrail="GovernedCrew",
                detail=blocked_msg,
                block_response=blocked_msg,
            )

        return crew_output

    def kickoff(
        self,
        inputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:
        """Synchronous native CrewAI interface — delegates to :meth:`kickoff_async`."""
        import contextvars

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import concurrent.futures

            ctx = contextvars.copy_context()
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(
                    ctx.run, asyncio.run, self.kickoff_async(inputs, **kwargs)
                ).result()
        return asyncio.run(self.kickoff_async(inputs, **kwargs))

    # ------------------------------------------------------------------
    # Shared governance execution (used by ainvoke AND kickoff_async)
    # ------------------------------------------------------------------

    async def _governed_execution(
        self,
        input_state: dict[str, Any],
        *,
        session_id: str | None = None,
        user_id: str | None = None,
        project_id: str | None = None,
        workflow_id: str | None = None,
    ) -> tuple[dict[str, Any], Any]:
        """Shared governance setup used by both :meth:`ainvoke` and
        :meth:`kickoff_async`.

        Returns ``(normalised_dict, crew_output)``.
        """
        require_platform_init()

        os.environ["CREWAI_DISABLE_TELEMETRY"] = "true"

        self._step_counter = 0
        self._invocation_started_at = time.time()

        pipe_ctx = get_active_pipeline()
        is_pipeline_child = pipe_ctx is not None

        resolved_session = (
            session_id
            or (pipe_ctx.session_id if pipe_ctx else None)
            or generate_id("sess-")
        )
        resolved_user = (
            user_id
            or (pipe_ctx.user_id if pipe_ctx else None)
            or get_default_user_id()
        )
        resolved_project = (
            project_id or self.project_id
            or (pipe_ctx.project_id if pipe_ctx else None)
            or get_platform_project_id()
        )
        resolved_workflow = workflow_id or self.workflow_id

        lf = _get_langfuse_client()
        if is_pipeline_child:
            trace_id = pipe_ctx.trace_id
        else:
            trace_id = lf.create_trace_id() if lf else generate_id("tr-")

        self._invoke_ctx = {
            "trace_id": trace_id,
            "session_id": resolved_session,
            "user_id": resolved_user,
            "project_id": resolved_project,
            "workflow_id": resolved_workflow,
        }

        set_current_trace_id(trace_id)
        set_session_id(resolved_session)
        set_user_id(resolved_user)
        set_project_id(resolved_project)
        set_workflow_id(resolved_workflow)

        gov_ctx = GovernanceCtx(
            trace_id=trace_id,
            session_id=resolved_session,
            user_id=resolved_user or "",
            project_id=resolved_project or "",
            workflow_id=resolved_workflow or "",
            agent_id=self.agent_id or "",
            agent_version=self.agent_version or "",
            input_state=input_state,
        )
        ctx_token = _set_governance_ctx(gov_ctx)

        self._setup_event_listeners()

        start = time.perf_counter()

        try:
            result, crew_output = await self._run_governed(input_state, gov_ctx, lf, trace_id)

            gov_ctx.output_state = result
            self.last_governance_ctx = gov_ctx

            if is_pipeline_child and pipe_ctx is not None:
                pipe_ctx.agent_names.append(self.name)
                pipe_ctx.sub_trace_ids.append(trace_id)
                pipe_ctx._last_gov_ctx = gov_ctx

            return result, crew_output

        except Exception:
            logger.debug(
                "GovernedCrew invocation failed (trace_id=%s)", trace_id,
                exc_info=True,
            )
            raise
        finally:
            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.debug(
                "GovernedCrew invocation complete (trace_id=%s, tasks=%d, %.1fms)",
                trace_id, len(self._crew.tasks), elapsed_ms,
            )
            if not is_pipeline_child:
                if lf is not None:
                    try:
                        lf.flush()
                    except Exception:
                        logger.debug("Langfuse flush failed", exc_info=True)
                _set_governance_ctx(None)
                set_current_trace_id(None)
                set_session_id(None)
                set_user_id(None)
                set_project_id(None)
                set_workflow_id(None)
            else:
                _set_governance_ctx(None)
            self._invoke_ctx = None
            self._teardown_event_listeners()

    # ------------------------------------------------------------------
    # Core: governed execution
    # ------------------------------------------------------------------

    async def _run_governed(
        self,
        input_state: dict[str, Any],
        gov_ctx: GovernanceCtx,
        lf: Any,
        trace_id: str,
    ) -> tuple[dict[str, Any], Any]:
        """Run the crew with per-task governance.

        Returns ``(normalised_dict, crew_output)`` where *crew_output*
        is the raw ``CrewOutput`` from ``Crew.akickoff()``.  When a
        guard blocks, *crew_output* is ``None``.
        """
        # Extract input for CrewAI
        crew_inputs = self._extract_crew_inputs(input_state)

        # ----------------------------------------------------------
        # Langfuse: single-trace hierarchy
        # ----------------------------------------------------------
        # We mirror GovernedGraph's approach: create a root span via
        # ``start_as_current_span`` and wrap the execution in
        # ``propagate_attributes`` so that the ``langfuse.openai``
        # drop-in (used by ChatModel) automatically nests every LLM
        # generation under ***this*** trace instead of creating
        # orphan traces.
        # ----------------------------------------------------------

        settings = get_settings()
        env_tag = f"env:{settings.environment}" if settings.environment else "env:development"
        pipe_ctx = get_active_pipeline()
        is_pipeline_child = pipe_ctx is not None

        resolved_session = self._invoke_ctx.get("session_id") if self._invoke_ctx else None
        resolved_user = self._invoke_ctx.get("user_id") if self._invoke_ctx else None
        resolved_project = self._invoke_ctx.get("project_id") if self._invoke_ctx else None

        root_span = None
        trace_ctx: dict[str, str] = {"trace_id": trace_id}
        if is_pipeline_child and pipe_ctx and pipe_ctx.root_span_id:
            trace_ctx["parent_span_id"] = pipe_ctx.root_span_id

        if lf is not None:
            try:
                root_span = lf.start_as_current_span(
                    trace_context=trace_ctx,
                    name=self.name,
                    input=crew_inputs,
                )
                root_span.__enter__()

                if not is_pipeline_child:
                    lf.update_current_trace(
                        name=self.name,
                        user_id=resolved_user,
                        session_id=resolved_session,
                        tags=list(self.tags or []) + [env_tag],
                        metadata={
                            "project_id": resolved_project,
                            "workflow_id": self.workflow_id,
                            "environment": env_tag,
                            "risk_class": self.risk_class.value,
                            "framework": "crewai",
                            "tasks": [t.description[:80] for t in self._crew.tasks],
                            "agent_id": getattr(self, "agent_id", None),
                            "agent_version": getattr(self, "agent_version", None),
                            "lifecycle": getattr(self, "lifecycle", "active"),
                        },
                        input=crew_inputs,
                    )
            except Exception:
                logger.debug("Langfuse trace creation failed", exc_info=True)
                root_span = None

        try:
            return await self._run_governed_inner(
                input_state, crew_inputs, gov_ctx, lf, trace_id,
                env_tag, resolved_user, resolved_session,
            )
        finally:
            if root_span is not None:
                try:
                    root_span.__exit__(None, None, None)
                except Exception:
                    logger.debug("Langfuse root span close failed", exc_info=True)

    async def _run_governed_inner(
        self,
        input_state: dict[str, Any],
        crew_inputs: dict[str, Any],
        gov_ctx: GovernanceCtx,
        lf: Any,
        trace_id: str,
        env_tag: str,
        resolved_user: str | None,
        resolved_session: str | None,
    ) -> tuple[dict[str, Any], Any]:
        """Inner governed execution — runs inside the Langfuse root span.

        Returns ``(normalised_dict, crew_output)``.  When blocked,
        *crew_output* is ``None``.
        """

        # Run before_node guards on the CREW-LEVEL input (first task's guards)
        self._step_counter = 1
        first_task_name = self._task_name(0)
        pipeline = self._get_pipeline_for_task(first_task_name)
        exec_ctx = self._build_execution_context(
            node_name=first_task_name,
            input_state=input_state,
        )
        exec_ctx = await pipeline.run_before(exec_ctx)

        # Check if guards blocked the input
        blocked = exec_ctx.metadata.get("guardrail_blocked_response")
        if blocked:
            self._emit_audit_block(first_task_name, blocked, exec_ctx, lf, trace_id)
            return self._make_blocked_response(blocked, input_state), None

        # Execute the crew inside propagate_attributes so that the
        # ``langfuse.openai`` drop-in nests every LLM call under
        # this trace — giving us ONE trace per workflow, not N.
        try:
            with _propagate_attrs(
                trace_name=(
                    self.name if not get_active_pipeline()
                    else get_active_pipeline().name
                ),
                user_id=resolved_user,
                session_id=resolved_session,
                tags=list(self.tags or []) + [env_tag],
            ):
                crew_output = await self._crew.akickoff(inputs=crew_inputs)
        except Exception as e:
            logger.error("CrewAI execution failed: %s", e)
            raise

        # Extract token usage from CrewOutput for BudgetPolicy
        total_tokens = 0
        total_cost = 0.0
        token_usage = getattr(crew_output, "token_usage", None)
        if isinstance(token_usage, dict):
            total_tokens = token_usage.get("total_tokens", 0) or 0
        elif token_usage is not None:
            total_tokens = getattr(token_usage, "total_tokens", 0) or 0

        # Run after_node guards on the CREW-LEVEL output (last task's guards)
        self._step_counter = len(self._crew.tasks)
        last_task_name = self._task_name(len(self._crew.tasks) - 1)
        pipeline_after = self._get_pipeline_for_task(last_task_name)
        output_text = str(crew_output.raw) if hasattr(crew_output, "raw") else str(crew_output)
        output_state = {
            "messages": input_state.get("messages", []) + [
                {"role": "assistant", "content": output_text}
            ],
        }
        exec_ctx_after = self._build_execution_context(
            node_name=last_task_name,
            input_state=input_state,
            output_state=output_state,
            total_tokens=total_tokens,
            total_cost=total_cost,
        )
        exec_ctx_after = await pipeline_after.run_after(exec_ctx_after)

        # Langfuse: update root span with output
        if lf is not None:
            try:
                obs_id = lf.get_current_observation_id()
                if obs_id:
                    lf.update_current_span(
                        output=output_text,
                        metadata={
                            "tasks_completed": len(crew_output.tasks_output)
                            if hasattr(crew_output, "tasks_output") else 0,
                            "token_usage": crew_output.token_usage
                            if hasattr(crew_output, "token_usage") else {},
                        },
                    )
            except Exception:
                logger.debug("Langfuse trace update failed", exc_info=True)

        # Build normalised response
        result = {
            "messages": input_state.get("messages", []) + [
                {"role": "assistant", "content": output_text}
            ],
            "crew_output": crew_output,
        }

        # Auto-capture output for governance context
        gov_ctx.output = output_text

        return result, crew_output

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _resolve_model_name(self) -> str | None:
        """Extract the model name from the crew's agents for ModelAllowlistPolicy.

        Checks the first agent's LLM for a ``model`` or ``model_name``
        attribute (covers both ``CrewAILLM`` and native CrewAI LLM objects).
        """
        agents = getattr(self._crew, "agents", None) or []
        for agent in agents:
            llm = getattr(agent, "llm", None)
            if llm is None:
                continue
            # CrewAILLM stores it as .model_name, native LiteLLM as .model
            model = (
                getattr(llm, "model_name", None)
                or getattr(llm, "model", None)
            )
            if model:
                return str(model)
        return None

    @staticmethod
    def _extract_crew_inputs(input_state: dict[str, Any]) -> dict[str, Any]:
        """Extract CrewAI-compatible inputs from the normalised state dict.

        If ``input_state`` has ``"messages"``, extract the last user message
        as ``"input"``.  Otherwise pass through as-is.
        """
        messages = input_state.get("messages")
        if messages:
            # Find the last user message
            for msg in reversed(messages):
                role = msg.get("role", "") if isinstance(msg, dict) else getattr(msg, "role", "")
                content = msg.get("content", "") if isinstance(msg, dict) else getattr(msg, "content", "")
                if role == "user":
                    # Keep all other keys from input_state, add "input"
                    result = {k: v for k, v in input_state.items() if k != "messages"}
                    result["input"] = content
                    return result
            # No user message found — pass messages as input
            result = {k: v for k, v in input_state.items() if k != "messages"}
            result["input"] = str(messages[-1])
            return result
        return input_state

    def _task_name(self, index: int) -> str:
        """Return a stable name for task at *index*."""
        try:
            task = self._crew.tasks[index]
            return getattr(task, "name", None) or f"task_{index}"
        except (IndexError, AttributeError):
            return f"task_{index}"

    @staticmethod
    def _make_blocked_response(
        response_text: str,
        input_state: dict[str, Any],
    ) -> dict[str, Any]:
        """Return a blocked response in the normalised format."""
        return {
            "response": response_text,
            "messages": input_state.get("messages", []) + [
                {"role": "assistant", "content": response_text}
            ],
        }

    def _emit_audit_block(
        self,
        task_name: str,
        block_message: str,
        exec_ctx: ExecutionContext,
        lf: Any,
        trace_id: str,
    ) -> None:
        """Emit audit event for a guardrail block."""
        detail = exec_ctx.metadata.get("guardrail_blocked_detail", "")
        logger.info(
            "guardrail_block agent_name=%s node_name=%s detail=%s",
            self.name, task_name, detail,
        )
        if lf is not None:
            try:
                lf.event(
                    trace_id=trace_id,
                    name="guardrail_block",
                    input={"task": task_name, "detail": detail},
                    output={"response": block_message},
                )
            except Exception:
                logger.debug("Langfuse event emission failed", exc_info=True)
