"""DeepAgents framework integration -- autonomous research agents with governance.

DeepAgents agents compile to LangGraph graphs, so governance is applied
automatically via :class:`~agentic_blueprint.frameworks.langgraph.GovernedGraph`
when you call ``wrap()``.  Use :class:`~agentic_blueprint.frameworks.langchain.LLMChatModel`
as the LLM for DeepAgents agents::

    from deepagents import create_deep_agent
    from agentic_blueprint import wrap, get_llm
    from agentic_blueprint.frameworks.langchain import LLMChatModel

    llm = LLMChatModel.from_blueprint(get_llm(model="gpt-4o"))
    agent = create_deep_agent(tools=[...], system_prompt="...", model=llm)
    governed = wrap(agent, name="researcher", guards=[...])
    result = await governed.ainvoke({"messages": [...]})

This module re-exports DeepAgents types for convenience.
"""

import contextlib

# Re-export deepagents types that users need for the new multi-agent,
# skills, and memory features introduced in deepagents ≥0.4.
with contextlib.suppress(ImportError):
    from deepagents import (  # noqa: F401
        CompiledSubAgent,
        FilesystemMiddleware,
        MemoryMiddleware,
        SubAgent,
        SubAgentMiddleware,
    )

# Re-export the native create_deep_agent for convenience
with contextlib.suppress(ImportError):
    from deepagents import create_deep_agent  # noqa: F401

__all__ = [
    "create_deep_agent",
    # deepagents types (available when deepagents ≥0.4 installed)
    "CompiledSubAgent",
    "SubAgent",
    "SubAgentMiddleware",
    "FilesystemMiddleware",
    "MemoryMiddleware",
]
