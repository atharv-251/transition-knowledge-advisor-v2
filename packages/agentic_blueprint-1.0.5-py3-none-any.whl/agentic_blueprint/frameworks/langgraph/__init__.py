"""LangGraph framework integration.

Governance is applied via ``agentic_blueprint.wrap()`` on any compiled
LangGraph graph.  Use native LangGraph APIs (``StateGraph``,
``create_agent``, etc.) and wrap the result::

    from langgraph.graph import StateGraph, START, END
    from langchain.agents import create_agent
    from agentic_blueprint import wrap

    graph = builder.compile()
    governed = wrap(graph, name="my-agent", guards=[...])
    result = await governed.ainvoke({"messages": [...]})
"""

from agentic_blueprint.frameworks.langgraph.governed_graph import GovernedGraph  # noqa: F401

__all__ = ["GovernedGraph"]
