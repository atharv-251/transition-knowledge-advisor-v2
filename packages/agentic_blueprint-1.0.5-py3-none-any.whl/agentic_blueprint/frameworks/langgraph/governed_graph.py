"""GovernedGraph — transparent governance wrapper for compiled LangGraph.

Intercepts **every node** in a compiled LangGraph graph by monkey-patching
the node callables.  Guardrails, policies, and audit run as invisible
middleware before and after each node — the developer's graph state,
edges, and checkpointers are untouched.

Created by :func:`~agentic_blueprint.core.wrap.wrap`.  Prefer using
``wrap()`` rather than constructing ``GovernedGraph`` directly.
"""

from __future__ import annotations

import asyncio
import copy
import functools
import json as _json
import logging
import time
from dataclasses import asdict, is_dataclass
from typing import Any, Callable, Sequence

from agentic_blueprint._internal.helpers import generate_id
from agentic_blueprint.config.settings import get_settings
from agentic_blueprint.core.governance_context import (
    GovernanceCtx,
    _get_governance_ctx,
    _set_governance_ctx,
    _governance_ctx_var,
)
from agentic_blueprint.core.langfuse_client import (
    get_langfuse_client,
    _fix_trace_name,
)
from agentic_blueprint.core.pipeline import get_active_pipeline
from agentic_blueprint.governance.context import ExecutionContext
from agentic_blueprint.governance.guards import GovernanceGuard, GuardsPipeline
from agentic_blueprint.frameworks.base import GovernedBase
from agentic_blueprint.governance.risk import RiskClass
from agentic_blueprint.governance.project_registry import (
    get_default_user_id,
    get_platform_project_id,
    require_platform_init,
)
from agentic_blueprint.observability.context import (
    get_current_trace_id,
    get_project_id,
    get_session_id,
    get_user_id,
    get_workflow_id,
    set_current_trace_id,
    set_project_id,
    set_session_id,
    set_user_id,
    set_workflow_id,
    _trace_id_var,
    _session_id_var,
    _user_id_var,
    _project_id_var,
    _workflow_id_var,
)

try:
    from langfuse import propagate_attributes as _propagate_attrs
except ImportError:  # pragma: no cover
    from contextlib import nullcontext as _propagate_attrs  # type: ignore[assignment]

logger = logging.getLogger(__name__)

__all__ = ["GovernedGraph"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_token_usage(result: Any) -> int:
    """Extract total token count from a node's result.

    Looks for ``_ab_usage`` dicts attached by :class:`ChatModel` on
    messages in the result, or for ``usage_metadata`` dicts injected
    by LangChain's AIMessage.
    """
    total = 0
    if not isinstance(result, dict):
        return total
    messages = result.get("messages", [])
    if not isinstance(messages, list):
        return total
    for msg in messages:
        # SDK ChatModel attaches _ab_usage
        usage = getattr(msg, "_ab_usage", None)
        if usage is None and isinstance(msg, dict):
            usage = msg.get("_ab_usage")
        if isinstance(usage, dict):
            total += usage.get("total_tokens", 0)
            continue
        # LangChain AIMessage may carry usage_metadata
        um = getattr(msg, "usage_metadata", None)
        if isinstance(um, dict):
            total += um.get("total_tokens", 0) or (
                um.get("input_tokens", 0) + um.get("output_tokens", 0)
            )
    return total


def _detect_model_name() -> str | None:
    """Detect the model name from the last created ChatModel (if any)."""
    try:
        from agentic_blueprint.core.models import ChatModel
        return ChatModel._last_created_model
    except (ImportError, AttributeError):
        return None


def _is_command_resume(input_state: Any) -> bool:
    """Check if the input is a LangGraph Command(resume=...) object."""
    try:
        from langgraph.types import Command
        return isinstance(input_state, Command) and hasattr(input_state, "resume")
    except ImportError:
        return False


def _extract_resume_value(input_state: Any) -> Any:
    """Extract the resume value from a Command object."""
    return getattr(input_state, "resume", None)


# ---------------------------------------------------------------------------
# GovernedGraph
# ---------------------------------------------------------------------------


class GovernedGraph(GovernedBase):
    """A compiled LangGraph wrapped with transparent governance.

    Inherits from :class:`~agentic_blueprint.frameworks.base.GovernedBase`
    for shared lifecycle management (identity resolution, trace creation,
    governance context, cleanup).

    Overrides ``ainvoke()`` for LangGraph-specific features:
    HITL resume via ``Command(resume=...)``, deep-copy state isolation,
    and LangGraph tracing integration.

    Created by :func:`~agentic_blueprint.core.wrap.wrap`.  Prefer using
    ``wrap()`` rather than constructing ``GovernedGraph`` directly.

    Langfuse tracing hierarchy::

        TRACE: my-agent (user_id, session_id, project_id)
          +-- SPAN: search         (input -> output)
          |     +-- GENERATION: gpt-5-mini (auto via langfuse.openai)
          +-- SPAN: synthesise     (input -> output)
                +-- GENERATION: gpt-5-mini (auto via langfuse.openai)
    """

    def __init__(
        self,
        compiled_graph: Any,
        *,
        name: str,
        guards: Sequence[GovernanceGuard] = (),
        scoped_guards: dict[str, Sequence[GovernanceGuard]] | None = None,
        tags: Sequence[str] = (),
        project_id: str | None = None,
        workflow_id: str | None = None,
        risk_class: RiskClass = RiskClass.MEDIUM,
        agent_id: str | None = None,
        agent_version: str | None = None,
        lifecycle: str = "active",
    ) -> None:
        super().__init__(
            name=name,
            guards=guards,
            scoped_guards=scoped_guards,
            tags=tags,
            project_id=project_id,
            workflow_id=workflow_id,
            risk_class=risk_class,
            agent_id=agent_id,
            agent_version=agent_version,
            lifecycle=lifecycle,
        )
        self._graph = compiled_graph

        # Mark the inner graph so the auto-governance patch
        # (governance.auto_patch) knows wrap() was already called.
        self._graph._ab_governed = True

        # Build scoped guard pipelines (pure scoped, merged at runtime)
        for node_name, nguards in self._scoped_guards_map.items():
            self._node_pipelines[node_name] = GuardsPipeline(nguards)

        # LangGraph-specific runtime state
        self._blocked: bool = False
        self._detected_model: str | None = _detect_model_name()

        # Inject LangGraph HITL strategy into any HumanReviewGuard
        self._inject_hitl_strategy()

        # Monkey-patch the compiled graph's nodes with governed wrappers.
        self._original_nodes: dict[str, Any] = {}
        self._patch_nodes()

    # ------------------------------------------------------------------
    # HITL strategy injection
    # ------------------------------------------------------------------

    def _inject_hitl_strategy(self) -> None:
        """Inject :class:`LangGraphHITLStrategy` into all HumanReviewGuards."""
        from agentic_blueprint.governance.guardrails.human_review import HumanReviewGuard
        from agentic_blueprint.governance.guardrails.hitl_strategy import (
            LangGraphHITLStrategy,
            NoOpHITLStrategy,
        )

        strategy = LangGraphHITLStrategy()
        for guard in self._base_guards:
            if isinstance(guard, HumanReviewGuard) and isinstance(
                guard.strategy, NoOpHITLStrategy
            ):
                guard.strategy = strategy
        for guards in self._scoped_guards_map.values():
            for guard in guards:
                if isinstance(guard, HumanReviewGuard) and isinstance(
                    guard.strategy, NoOpHITLStrategy
                ):
                    guard.strategy = strategy

    # ------------------------------------------------------------------
    # Node patching
    # ------------------------------------------------------------------

    def _patch_nodes(self) -> None:
        """Replace each node in the compiled graph with a governed wrapper."""
        nodes = getattr(self._graph, "nodes", None)
        if nodes is None:
            logger.warning(
                "Cannot patch nodes: compiled graph has no 'nodes' attribute. "
                "Governance will run at invoke-level only."
            )
            return

        for node_name, node_obj in nodes.items():
            original_fn = self._extract_callable(node_obj)
            if original_fn is None:
                continue
            self._original_nodes[node_name] = original_fn
            governed_fn = self._make_governed_node(node_name, original_fn)
            self._replace_callable(node_obj, governed_fn)

    @staticmethod
    def _find_runnable_callable(node_obj: Any) -> Any | None:
        """Locate the ``RunnableCallable`` that holds the user function.

        LangGraph >= 0.3 wraps every node in a ``PregelNode`` whose
        ``.bound`` points to the ``RunnableCallable``.  Older versions
        store the callable directly on the node object.
        """
        if hasattr(node_obj, "afunc") or hasattr(node_obj, "func"):
            if (
                getattr(node_obj, "afunc", None) is not None
                or getattr(node_obj, "func", None) is not None
            ):
                return node_obj
        bound = getattr(node_obj, "bound", None)
        if bound is not None:
            if (
                getattr(bound, "afunc", None) is not None
                or getattr(bound, "func", None) is not None
            ):
                return bound
        rseq = getattr(node_obj, "node", None)
        if rseq is not None:
            steps = getattr(rseq, "steps", None)
            if steps and len(steps) > 0:
                step0 = steps[0]
                if (
                    getattr(step0, "afunc", None) is not None
                    or getattr(step0, "func", None) is not None
                ):
                    return step0
        return None

    def _extract_callable(self, node_obj: Any) -> Callable | None:
        """Extract the user's callable from a LangGraph node object."""
        rc = self._find_runnable_callable(node_obj)
        if rc is not None:
            if getattr(rc, "afunc", None) is not None:
                return rc.afunc
            if getattr(rc, "func", None) is not None:
                return rc.func
        if callable(node_obj):
            return node_obj
        return None

    def _replace_callable(self, node_obj: Any, new_fn: Callable) -> None:
        """Replace the callable inside a LangGraph node object."""
        targets: list[Any] = list(self._iter_patchable(node_obj))
        for target in targets:
            if asyncio.iscoroutinefunction(new_fn):
                if hasattr(target, "afunc"):
                    target.afunc = new_fn
                if hasattr(target, "func"):
                    target.func = None  # force async path
            else:
                if hasattr(target, "func"):
                    target.func = new_fn

    @staticmethod
    def _iter_patchable(node_obj: Any):
        """Yield every object in the node tree that has afunc/func."""
        if hasattr(node_obj, "afunc") or hasattr(node_obj, "func"):
            yield node_obj
        bound = getattr(node_obj, "bound", None)
        if bound is not None and (hasattr(bound, "afunc") or hasattr(bound, "func")):
            yield bound
        rseq = getattr(node_obj, "node", None)
        if rseq is not None:
            steps = getattr(rseq, "steps", None)
            if steps and len(steps) > 0:
                step0 = steps[0]
                if hasattr(step0, "afunc") or hasattr(step0, "func"):
                    yield step0

    # ------------------------------------------------------------------
    # Governed node wrapper
    # ------------------------------------------------------------------

    def _make_governed_node(
        self, node_name: str, original_fn: Callable
    ) -> Callable:
        """Create a governed wrapper for a single node."""
        is_async = asyncio.iscoroutinefunction(original_fn)

        @functools.wraps(original_fn)
        async def _governed(state: dict[str, Any], *args: Any, **kwargs: Any) -> Any:
            async with self._step_lock:
                self._step_counter += 1
                current_step = self._step_counter

            gov_ctx = _get_governance_ctx()
            if gov_ctx is not None:
                gov_ctx.node_history.append(node_name)
                gov_ctx.step_count = current_step

            # Resolve trace context: contextvars (standard) > config fallback (hosted/serverless)
            _cfg = kwargs.get("config", {}).get("configurable", {})

            exec_ctx = ExecutionContext(
                agent_name=self.name,
                node_name=node_name,
                trace_id=(
                    get_current_trace_id()
                    or _cfg.get("_ab_trace_id")
                    or generate_id("tr-")
                ),
                session_id=get_session_id() or _cfg.get("_ab_session_id"),
                user_id=get_user_id() or _cfg.get("_ab_user_id"),
                workflow_id=get_workflow_id() or _cfg.get("_ab_workflow_id"),
                project_id=get_project_id() or _cfg.get("_ab_project_id"),
                risk_class=(
                    self.risk_class.value
                    if hasattr(self, "risk_class") else "medium"
                ),
                input_state=state,
                step_count=self._step_counter,
                node_step_count=(
                    gov_ctx.node_history.count(node_name) if gov_ctx else 1
                ),
                total_tokens=gov_ctx.total_tokens if gov_ctx else 0,
                total_cost=gov_ctx.total_cost if gov_ctx else 0.0,
                tags=self.tags,
            )
            # Auto-populate model for ModelAllowlistPolicy
            exec_ctx.governance_config["model"] = getattr(
                self, "_detected_model", None
            )

            # Combine base + node-level guards (additive)
            node_pipeline = self._node_pipelines.get(node_name)
            if node_pipeline is not None:
                pipeline = GuardsPipeline(
                    list(self._base_pipeline._guards)
                    + list(node_pipeline._guards)
                )
            else:
                pipeline = self._base_pipeline

            lf = get_langfuse_client()
            invoke_ctx = self._invoke_ctx or {}
            trace_id = exec_ctx.trace_id  # Use the trace_id from ExecutionContext
            has_callback = invoke_ctx.get("has_lf_callback", False)

            # Reset ChatModel's task-local token counter before the node runs
            try:
                from agentic_blueprint.core.models import ChatModel
                ChatModel._node_token_usage.set(0)
            except (ImportError, AttributeError):
                pass

            # Use span-based execution when Langfuse is available and no
            # callback handler is already attached (prevents double spans).
            if lf is not None and trace_id and not has_callback:
                result = await self._execute_with_span(
                    lf, trace_id, node_name, state, original_fn,
                    is_async, exec_ctx, pipeline, args, kwargs,
                )
            else:
                result = await self._execute_node(
                    state, original_fn, is_async, exec_ctx, pipeline,
                    args, kwargs,
                )

            # Persist guard metadata into sidecar context
            if gov_ctx is not None:
                guardrail_results = exec_ctx.metadata.get("guardrail_results", [])
                if guardrail_results:
                    raw = [
                        asdict(r) if is_dataclass(r) else {"raw": str(r)}
                        for r in guardrail_results
                    ]
                    serialized = _json.loads(_json.dumps(raw, default=str))
                    existing = gov_ctx.metadata.setdefault("guardrail_results", [])
                    existing.extend(serialized)

            return result

        return _governed

    # ------------------------------------------------------------------
    # Node execution helpers
    # ------------------------------------------------------------------

    async def _execute_with_span(
        self,
        lf: Any,
        trace_id: str,
        node_name: str,
        state: dict[str, Any],
        fn: Callable,
        is_async: bool,
        exec_ctx: ExecutionContext,
        pipeline: GuardsPipeline,
        args: tuple,
        kwargs: dict,
    ) -> dict[str, Any]:
        """Execute a node inside a Langfuse span."""
        span_input = {
            k: (f"[{len(v)} items]" if isinstance(v, list) and len(v) > 5 else v)
            for k, v in state.items()
        }

        invoke_ctx = self._invoke_ctx or {}
        trace_ctx: dict[str, str] = {"trace_id": trace_id}
        root_span_id = invoke_ctx.get("root_span_id")
        if root_span_id:
            trace_ctx["parent_span_id"] = root_span_id

        with lf.start_as_current_span(
            trace_context=trace_ctx,
            name=node_name,
            input=span_input,
        ) as span:
            result = await self._execute_node(
                state, fn, is_async, exec_ctx, pipeline, args, kwargs,
            )
            try:
                span.update(output=result)
            except Exception:
                logger.debug("node tracing span update failed", exc_info=True)

        return result

    async def _execute_node(
        self,
        state: dict[str, Any],
        fn: Callable,
        is_async: bool,
        exec_ctx: ExecutionContext,
        pipeline: GuardsPipeline,
        args: tuple,
        kwargs: dict,
    ) -> dict[str, Any]:
        """Run the node through the guards pipeline."""
        # Get governance context early (needed for multiple code paths)
        gov_ctx = _get_governance_ctx()
        
        # Fast-path: If a previous node was blocked, skip execution of this node
        # Return ONLY answer (no messages) so Azure Agent Server doesn't collect duplicates
        # The blocking node already returned complete messages - subsequent nodes pass through answer only
        # Use gov_ctx.blocked_response (contextvar-scoped, per-invocation) for the check.
        # Avoids using instance-level self._blocked which would race across parallel branches.
        is_blocked = bool(gov_ctx and gov_ctx.blocked_response)
        if is_blocked:
            logger.info("Fast-path: Previous node blocked, skipping execution (passing answer only)")
            return {
                "answer": state.get("answer", ""),
            }

        # Before hooks
        exec_ctx = await pipeline.run_before(exec_ctx)

        # Check if a guardrail soft-blocked with a block_response
        blocked_response = exec_ctx.metadata.get("guardrail_blocked_response") if exec_ctx.metadata else None
        if blocked_response:
            result = self._build_block_response_state(state, blocked_response)
            exec_ctx.output_state = result
            self._blocked = True
            if gov_ctx:
                gov_ctx.blocked_response = blocked_response
            await pipeline.run_after(exec_ctx)
            # Fast-path in _execute_node will skip subsequent nodes.
            return result

        # Execute the actual node function
        try:
            if is_async:
                result = await fn(state, *args, **kwargs)
            else:
                result = fn(state, *args, **kwargs)
        except Exception as exc:
            # HITL: if a NodeInterrupt is raised (by HumanReviewGuard or
            # the developer), serialize GovernanceCtx so it can be restored
            # on resume.
            _is_interrupt = False
            try:
                from langgraph.errors import NodeInterrupt as _NI
                _is_interrupt = isinstance(exc, _NI)
            except ImportError:
                pass

            if _is_interrupt and gov_ctx is not None:
                # Store governance checkpoint data on the interrupt for
                # downstream checkpoint persistence.
                if hasattr(exc, 'value') and isinstance(exc.value, dict):
                    exc.value["_ab_governance_checkpoint"] = (
                        gov_ctx.to_checkpoint_data()
                    )

            exec_ctx.error = exc
            await pipeline.run_after(exec_ctx)
            raise

        exec_ctx.output_state = result

        # Accumulate token usage BEFORE run_after so the audit guard
        # sees the updated total_tokens in the ExecutionContext.
        if gov_ctx is not None:
            _node_tokens = _extract_token_usage(result)
            if _node_tokens == 0:
                try:
                    from agentic_blueprint.core.models import ChatModel
                    _node_tokens = ChatModel._node_token_usage.get(0)
                except (ImportError, AttributeError):
                    pass
            if _node_tokens > 0:
                gov_ctx.total_tokens += _node_tokens
                exec_ctx.total_tokens = gov_ctx.total_tokens

        await pipeline.run_after(exec_ctx)

        # Check if a guardrail soft-blocked during after_node
        # (e.g. scoped OutputPIIGuardrail scanning context_keys)
        after_blocked = (
            exec_ctx.metadata.get("guardrail_blocked_response")
            if exec_ctx.metadata
            else None
        )
        if after_blocked:
            result = self._build_block_response_state(state, after_blocked)
            self._blocked = True
            if gov_ctx:
                gov_ctx.blocked_response = after_blocked

        return result

    @staticmethod
    def _build_block_response_state(
        state: dict[str, Any], response_text: str,
    ) -> dict[str, Any]:
        """Build a synthetic output state from a guardrail block_response.
        
        Returns answer + complete messages (user + AI) for Azure Agent Server.
        User message must be included here since fast-path will skip subsequent nodes.
        
        To avoid duplication with add_messages reducer, we return the complete conversation
        as a list, which replaces (not appends to) the messages field in state updates.
        """
        logger.info(f"_build_block_response_state: formatting complete messages for blocked response")
        
        # Extract user message from existing state
        messages = state.get("messages", [])
        user_messages = []
        
        # Collect all existing user messages (preserve original IDs for deduplication)
        for msg in messages:
            if hasattr(msg, "type") and msg.type == "human":
                user_messages.append(msg)
            elif isinstance(msg, dict) and msg.get("role") == "user":
                # Convert dict to HumanMessage if needed
                try:
                    from langchain_core.messages import HumanMessage
                    user_messages.append(HumanMessage(content=msg.get("content", ""), id=msg.get("id")))
                except ImportError:
                    user_messages.append(msg)
        
        # Import LangChain message types
        try:
            from langchain_core.messages import AIMessage
            
            # Build complete messages: preserve existing user messages + add AI response
            # This ensures Azure Agent Server sees the full conversation
            complete_messages = user_messages + [AIMessage(content=response_text)]
            
            return {
                "answer": response_text,
                "messages": complete_messages,
            }
        except ImportError:
            # Fallback: return dict-based messages
            logger.warning("langchain_core not available, using dict-based message")
            dict_user_messages = [{"role": "user", "content": m.content if hasattr(m, "content") else m.get("content", "")} for m in user_messages]
            
            return {
                "answer": response_text,
                "messages": dict_user_messages + [{"role": "assistant", "content": response_text}],
            }

    # ------------------------------------------------------------------
    # GovernedBase abstract — overridden by full ainvoke() below
    # ------------------------------------------------------------------

    async def _execute(
        self,
        gov_ctx: GovernanceCtx,
        lf: Any | None,
        trace_id: str,
        input_state: dict[str, Any],
        config: dict[str, Any] | None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Not used — GovernedGraph overrides ainvoke() directly for HITL."""
        raise NotImplementedError(
            "GovernedGraph overrides ainvoke() directly. "
            "This method should not be called."
        )

    # ------------------------------------------------------------------
    # ainvoke (overrides GovernedBase for HITL resume + deep-copy)
    # ------------------------------------------------------------------

    async def ainvoke(
        self,
        input_state: dict[str, Any],
        *,
        session_id: str | None = None,
        user_id: str | None = None,
        project_id: str | None = None,
        workflow_id: str | None = None,
        config: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Invoke the governed graph.

        Parameters match the underlying compiled graph's ``ainvoke()``,
        plus optional identity overrides for tracing.

        The developer's state is **never modified** with governance fields.
        All governance metadata is in the sidecar context.
        """
        require_platform_init()

        self._step_counter = 0
        self._blocked = False

        # Detect active pipeline context
        pipe_ctx = get_active_pipeline()
        is_pipeline_child = pipe_ctx is not None

        # Resolve identities (pipeline takes precedence)
        resolved_session = (
            session_id
            or (pipe_ctx.session_id if pipe_ctx else None)
            or generate_id("sess-")
        )
        resolved_user = (
            user_id
            or (pipe_ctx.user_id if pipe_ctx else None)
            or get_default_user_id()
        )
        resolved_project = (
            project_id or self.project_id
            or (pipe_ctx.project_id if pipe_ctx else None)
            or get_platform_project_id()
        )
        resolved_workflow = workflow_id or self.workflow_id

        # Check if trace context already exists in config (from parent/wrapper)
        _cfg_trace_id = (config or {}).get("configurable", {}).get("_ab_trace_id")

        # Create or reuse Langfuse trace
        lf = get_langfuse_client()
        if is_pipeline_child:
            trace_id = pipe_ctx.trace_id
        else:
            trace_id = _cfg_trace_id or (lf.create_trace_id() if lf else generate_id("tr-"))

        # Store invocation context for node wrappers
        self._invoke_ctx = {
            "trace_id": trace_id,
            "session_id": resolved_session,
            "user_id": resolved_user,
            "project_id": resolved_project,
            "workflow_id": resolved_workflow,
        }
        if is_pipeline_child and pipe_ctx.root_span_id:
            self._invoke_ctx["pipeline_root_span_id"] = pipe_ctx.root_span_id

        # Set tracing contextvars (save tokens for proper restoration)
        _tk_trace = set_current_trace_id(trace_id)
        _tk_session = set_session_id(resolved_session)
        _tk_user = set_user_id(resolved_user)
        _tk_project = set_project_id(resolved_project)
        _tk_workflow = set_workflow_id(resolved_workflow)

        # CRITICAL: Create separate copies for trace vs execution
        # Trace input must be pristine (only original user input)
        # Graph input will be mutated during execution
        # Create a minimal trace input with only essential fields to prevent contamination
        # Note: input_state may be a Command object (HITL resume), not a dict
        if isinstance(input_state, dict):
            input_state_for_trace = {
                "messages": copy.deepcopy(input_state.get("messages", []))
            }
        else:
            input_state_for_trace = {"messages": []}
        input_state_for_graph = copy.deepcopy(input_state)

        # Create sidecar governance context
        #
        # HITL resume: if input is a Command(resume=...), try to restore
        # governance state from the checkpoint and run before_node guards
        # on the resume value.
        _is_resume = _is_command_resume(input_state_for_graph)
        if _is_resume:
            _resume_value = _extract_resume_value(input_state_for_graph)
            # Restore governance state from checkpoint metadata if available
            _ckpt_data = (config or {}).get("configurable", {}).get(
                "_ab_governance_checkpoint"
            )
            if _ckpt_data and isinstance(_ckpt_data, dict):
                gov_ctx = GovernanceCtx.from_checkpoint_data(_ckpt_data)
                # Preserve new trace_id for the resumed segment
                gov_ctx.trace_id = trace_id
            else:
                gov_ctx = GovernanceCtx(
                    trace_id=trace_id,
                    session_id=resolved_session,
                    user_id=resolved_user or "",
                    project_id=resolved_project or "",
                    workflow_id=resolved_workflow or "",
                    agent_id=self.agent_id or "",
                    agent_version=self.agent_version or "",
                    input_state=(
                        input_state_for_graph if isinstance(input_state_for_graph, dict)
                        else {"_resume": str(input_state_for_graph)}
                    ),
                )
            # Inject resume value as a synthetic user message for guardrails
            if isinstance(_resume_value, str) and _resume_value:
                gov_ctx.input_state.setdefault("messages", []).append(
                    {"role": "user", "content": _resume_value}
                )
        else:
            gov_ctx = GovernanceCtx(
                trace_id=trace_id,
                session_id=resolved_session,
                user_id=resolved_user or "",
                project_id=resolved_project or "",
                workflow_id=resolved_workflow or "",
                agent_id=self.agent_id or "",
                agent_version=self.agent_version or "",
                input_state=input_state_for_graph,  # Use mutable copy
            )
        ctx_token = _set_governance_ctx(gov_ctx)

        start = time.perf_counter()
        
        _pipe_chain_run_id = None
        if is_pipeline_child and pipe_ctx is not None:
            _pipe_chain_run_id = pipe_ctx._start_agent_chain(
                self.name, input_state_for_graph,
            )

        try:
            # Inject trace context into config for cross-node propagation
            # (survives hosted runtimes where contextvars may reset)
            merged_config = self._inject_trace_config(
                config, trace_id, resolved_session, resolved_user,
                resolved_project, resolved_workflow,
            )

            if lf is not None:
                result = await self._invoke_with_tracing(
                    lf, trace_id, input_state_for_trace, input_state_for_graph,
                    resolved_session, resolved_user,
                    resolved_project, resolved_workflow,
                    merged_config, kwargs,
                )
            else:
                result = await self._graph.ainvoke(
                    input_state_for_graph, config=merged_config, **kwargs,
                )

            # Auto-capture output if developer didn't call set_output()
            if gov_ctx.output is None and isinstance(result, dict):
                for key in ("answer", "response", "output", "report"):
                    if key in result and isinstance(result[key], str):
                        gov_ctx.output = result[key]
                        break

            gov_ctx.output_state = result
            self.last_governance_ctx = gov_ctx

            # Report back to pipeline context
            if is_pipeline_child and pipe_ctx is not None:
                pipe_ctx.node_history.extend(gov_ctx.node_history)
                pipe_ctx.agent_names.append(self.name)
                pipe_ctx.sub_trace_ids.append(trace_id)
                pipe_ctx._last_gov_ctx = gov_ctx

            if _pipe_chain_run_id is not None and pipe_ctx is not None:
                pipe_ctx._end_agent_chain(
                    _pipe_chain_run_id, self.name, result,
                )

            return result

        except Exception:
            logger.debug(
                "GovernedGraph invocation failed (trace_id=%s)",
                trace_id, exc_info=True,
            )
            raise
        finally:
            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.debug(
                "GovernedGraph invocation complete "
                "(trace_id=%s, steps=%d, %.1fms)",
                trace_id, self._step_counter, elapsed_ms,
            )

            if is_pipeline_child:
                _governance_ctx_var.reset(ctx_token)
            else:
                if lf is not None:
                    try:
                        lf.flush()
                    except Exception:
                        logger.debug("Langfuse flush failed", exc_info=True)
                    _fix_trace_name(lf, trace_id, self.name)

                _governance_ctx_var.reset(ctx_token)
                _trace_id_var.reset(_tk_trace)
                _session_id_var.reset(_tk_session)
                _user_id_var.reset(_tk_user)
                _project_id_var.reset(_tk_project)
                _workflow_id_var.reset(_tk_workflow)

            self._invoke_ctx = None

    # ------------------------------------------------------------------
    # Config injection helper
    # ------------------------------------------------------------------

    @staticmethod
    def _inject_trace_config(
        config: dict[str, Any] | None,
        trace_id: str,
        session_id: str,
        user_id: str | None,
        project_id: str | None,
        workflow_id: str | None,
    ) -> dict[str, Any]:
        """Inject trace context into LangGraph config for cross-node propagation.

        LangGraph reliably passes ``config["configurable"]`` to every node
        callback, even in hosted runtimes (Azure Agent Server, AWS Lambda)
        where Python contextvars may reset across async boundaries.
        """
        merged = dict(config or {})
        cfgable = merged.setdefault("configurable", {})
        cfgable["_ab_trace_id"] = trace_id
        cfgable["_ab_session_id"] = session_id
        cfgable["_ab_user_id"] = user_id
        cfgable["_ab_project_id"] = project_id
        cfgable["_ab_workflow_id"] = workflow_id
        return merged

    # ------------------------------------------------------------------
    # Tracing-aware invocation
    # ------------------------------------------------------------------

    async def _invoke_with_tracing(
        self,
        lf: Any,
        trace_id: str,
        input_state_for_trace: dict[str, Any],  # Pristine copy for tracing
        input_state_for_graph: dict[str, Any],  # Copy for graph execution (will be mutated)
        session_id: str,
        user_id: str | None,
        project_id: str | None,
        workflow_id: str | None,
        config: dict[str, Any],
        extra_kwargs: dict[str, Any],
    ) -> dict[str, Any]:
        """Run the graph inside a Langfuse span with CallbackHandler."""
        settings = get_settings()
        env_tag = settings.environment.value

        pipe_ctx = get_active_pipeline()
        is_pipeline_child = pipe_ctx is not None
        trace_ctx: dict[str, str] = {"trace_id": trace_id}

        if is_pipeline_child and pipe_ctx.root_span_id:
            trace_ctx["parent_span_id"] = pipe_ctx.root_span_id

        try:
            with lf.start_as_current_span(
                trace_context=trace_ctx,
                name=self.name,
                input=input_state_for_trace,  # Use pristine copy for tracing
            ) as root_span:
                if not is_pipeline_child:
                    lf.update_current_trace(
                        name=self.name,
                        user_id=user_id,
                        session_id=session_id,
                        tags=list(self.tags or []) + [env_tag],
                        metadata={
                            "project_id": project_id,
                            "workflow_id": workflow_id,
                            "environment": env_tag,
                            "risk_class": (
                                self.risk_class.value
                                if hasattr(self, "risk_class") else "medium"
                            ),
                            "agent_id": getattr(self, "agent_id", None),
                            "agent_version": getattr(self, "agent_version", None),
                            "lifecycle": getattr(self, "lifecycle", "active"),
                        },
                        input=input_state_for_trace,  # Use pristine copy for tracing
                    )

                agent_span_id = lf.get_current_observation_id()
                self._invoke_ctx["root_span_id"] = agent_span_id

                # config already has trace context injected by caller
                merged_config = dict(config)
                merged_callbacks = list(merged_config.get("callbacks", []))
                try:
                    from langfuse.langchain import (
                        CallbackHandler as _LfCbHandler,
                    )

                    cb_trace_ctx: dict[str, str] = {"trace_id": trace_id}
                    if agent_span_id:
                        cb_trace_ctx["parent_span_id"] = agent_span_id
                    merged_callbacks.append(
                        _LfCbHandler(trace_context=cb_trace_ctx)
                    )
                    self._invoke_ctx["has_lf_callback"] = True
                except ImportError:
                    logger.debug(
                        "langfuse.langchain not available "
                        "-- graph structure won't appear in traces"
                    )

                if merged_callbacks:
                    merged_config["callbacks"] = merged_callbacks

                with _propagate_attrs(
                    trace_name=(
                        self.name if not is_pipeline_child
                        else pipe_ctx.name
                    ),
                    user_id=user_id,
                    session_id=session_id,
                    tags=list(self.tags or []) + [env_tag],
                ):
                    result = await self._graph.ainvoke(
                        input_state_for_graph,  # Use mutable copy for graph execution
                        config=merged_config,
                        **extra_kwargs,
                    )

                try:
                    root_span.update(output=result)
                except Exception:
                    logger.debug("root tracing span update failed", exc_info=True)

        finally:
            pass

        return result

    # ------------------------------------------------------------------
    # invoke (sync)
    # ------------------------------------------------------------------

    def invoke(
        self,
        input_state: dict[str, Any],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Synchronous convenience wrapper around :meth:`ainvoke`."""
        import contextvars

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if loop is not None:
            import concurrent.futures
            ctx = contextvars.copy_context()
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(ctx.run, asyncio.run, self.ainvoke(input_state, **kwargs)).result()
        return asyncio.run(self.ainvoke(input_state, **kwargs))

    # ------------------------------------------------------------------
    # astream
    # ------------------------------------------------------------------

    async def astream(
        self,
        input_state: dict[str, Any],
        *,
        session_id: str | None = None,
        user_id: str | None = None,
        project_id: str | None = None,
        workflow_id: str | None = None,
        config: dict[str, Any] | None = None,
        **kwargs: Any,
    ):
        """Stream graph execution events with governance.

        Yields the same events as the underlying graph's ``astream()``.
        """
        require_platform_init()

        self._step_counter = 0
        self._blocked = False

        # Detect active pipeline context
        pipe_ctx = get_active_pipeline()
        is_pipeline_child = pipe_ctx is not None

        # Resolve identities (pipeline takes precedence, matching ainvoke)
        resolved_session = (
            session_id
            or (pipe_ctx.session_id if pipe_ctx else None)
            or generate_id("sess-")
        )
        resolved_user = (
            user_id
            or (pipe_ctx.user_id if pipe_ctx else None)
            or get_default_user_id()
        )
        resolved_project = (
            project_id or self.project_id
            or (pipe_ctx.project_id if pipe_ctx else None)
            or get_platform_project_id()
        )
        resolved_workflow = workflow_id or self.workflow_id

        # Check if trace context already exists in config (from parent/wrapper)
        _cfg_trace_id = (config or {}).get("configurable", {}).get("_ab_trace_id")

        lf = get_langfuse_client()
        if is_pipeline_child:
            trace_id = pipe_ctx.trace_id
        else:
            trace_id = _cfg_trace_id or (lf.create_trace_id() if lf else generate_id("tr-"))

        self._invoke_ctx = {
            "trace_id": trace_id,
            "session_id": resolved_session,
            "user_id": resolved_user,
            "project_id": resolved_project,
            "workflow_id": resolved_workflow,
        }

        # Save contextvar tokens for proper restoration (supports nesting)
        _tk_trace = set_current_trace_id(trace_id)
        _tk_session = set_session_id(resolved_session)
        _tk_user = set_user_id(resolved_user)
        _tk_project = set_project_id(resolved_project)
        _tk_workflow = set_workflow_id(resolved_workflow)

        # Deep-copy input state to avoid mutation (matching ainvoke)
        input_state_for_stream = copy.deepcopy(input_state)

        gov_ctx = GovernanceCtx(
            trace_id=trace_id,
            session_id=resolved_session,
            user_id=resolved_user or "",
            project_id=resolved_project or "",
            workflow_id=resolved_workflow or "",
            agent_id=self.agent_id or "",
            agent_version=self.agent_version or "",
            input_state=input_state_for_stream,
        )
        ctx_token = _set_governance_ctx(gov_ctx)
        _pipe_chain_run_id = None
        _last_event = None  # Track last streamed event for output_state
        if is_pipeline_child and pipe_ctx is not None:
            _pipe_chain_run_id = pipe_ctx._start_agent_chain(
                self.name, input_state,
            )

        try:
            if lf is not None:
                settings = get_settings()
                env_tag = settings.environment.value

                stream_trace_ctx: dict[str, str] = {"trace_id": trace_id}
                if pipe_ctx is not None and pipe_ctx.root_span_id:
                    stream_trace_ctx["parent_span_id"] = pipe_ctx.root_span_id

                with lf.start_as_current_span(
                    trace_context=stream_trace_ctx,
                    name=self.name,
                    input=input_state_for_stream,
                ) as root_span:
                    lf.update_current_trace(
                        name=self.name,
                        user_id=resolved_user,
                        session_id=resolved_session,
                        tags=list(self.tags or []) + [env_tag],
                        metadata={
                            "project_id": resolved_project,
                            "workflow_id": resolved_workflow,
                            "environment": env_tag,
                            "risk_class": (
                                self.risk_class.value
                                if hasattr(self, "risk_class") else "medium"
                            ),
                            "agent_id": getattr(self, "agent_id", None),
                            "agent_version": getattr(self, "agent_version", None),
                            "lifecycle": getattr(self, "lifecycle", "active"),
                        },
                        input=input_state_for_stream,
                    )
                    agent_span_id = lf.get_current_observation_id()
                    self._invoke_ctx["root_span_id"] = agent_span_id

                    # config injection done once before the if/else
                    merged_config = self._inject_trace_config(
                        config, trace_id, resolved_session, resolved_user,
                        resolved_project, resolved_workflow,
                    )
                    merged_callbacks = list(
                        merged_config.get("callbacks", [])
                    )
                    try:
                        from langfuse.langchain import (
                            CallbackHandler as _LfCbHandler,
                        )

                        cb_trace_ctx: dict[str, str] = {
                            "trace_id": trace_id,
                        }
                        if agent_span_id:
                            cb_trace_ctx["parent_span_id"] = agent_span_id
                        merged_callbacks.append(
                            _LfCbHandler(trace_context=cb_trace_ctx)
                        )
                        self._invoke_ctx["has_lf_callback"] = True
                    except ImportError:
                        pass
                    if merged_callbacks:
                        merged_config["callbacks"] = merged_callbacks

                    with _propagate_attrs(
                        trace_name=self.name,
                        user_id=resolved_user,
                        session_id=resolved_session,
                        tags=list(self.tags or []) + [env_tag],
                    ):
                        async for event in self._graph.astream(
                            input_state_for_stream,
                            config=merged_config,
                            **kwargs,
                        ):
                            _last_event = event
                            yield event
                    try:
                        root_span.update(output={"streamed": True})
                    except Exception:
                        pass
            else:
                merged_config = self._inject_trace_config(
                    config, trace_id, resolved_session, resolved_user,
                    resolved_project, resolved_workflow,
                )
                async for event in self._graph.astream(
                    input_state_for_stream, config=merged_config, **kwargs,
                ):
                    _last_event = event
                    yield event
        finally:
            # Capture final output state for governance audit trail
            if _last_event is not None:
                gov_ctx.output_state = _last_event
            self.last_governance_ctx = gov_ctx

            if is_pipeline_child and pipe_ctx is not None:
                pipe_ctx.node_history.extend(gov_ctx.node_history)
                pipe_ctx.agent_names.append(self.name)
                pipe_ctx.sub_trace_ids.append(trace_id)
                pipe_ctx._last_gov_ctx = gov_ctx
            if _pipe_chain_run_id is not None and pipe_ctx is not None:
                pipe_ctx._end_agent_chain(
                    _pipe_chain_run_id, self.name, {"streamed": True},
                )

            if is_pipeline_child:
                _governance_ctx_var.reset(ctx_token)
            else:
                if lf is not None:
                    try:
                        lf.flush()
                    except Exception:
                        logger.debug("Langfuse flush failed", exc_info=True)
                    _fix_trace_name(lf, trace_id, self.name)

                _governance_ctx_var.reset(ctx_token)
                _trace_id_var.reset(_tk_trace)
                _session_id_var.reset(_tk_session)
                _user_id_var.reset(_tk_user)
                _project_id_var.reset(_tk_project)
                _workflow_id_var.reset(_tk_workflow)

            self._invoke_ctx = None

    # ------------------------------------------------------------------
    # Sidecar access
    # ------------------------------------------------------------------

    def last_governance_context(self) -> GovernanceCtx | None:
        """Return the governance context from the last invocation."""
        return _get_governance_ctx()
