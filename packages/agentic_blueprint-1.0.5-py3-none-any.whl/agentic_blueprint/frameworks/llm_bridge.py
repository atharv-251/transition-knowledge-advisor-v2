"""LLM bridge base — shared utilities for framework LLM adapters.

All framework-specific LLM adapters (LangChain ``LLMChatModel``,
CrewAI ``CrewAILLM``, future AutoGen/SK adapters) share common logic:

* Message format conversion (LangChain BaseMessage ↔ OpenAI dicts)
* Response normalization (ChatCompletionMessage / dict → AIMessage)
* Lazy model initialization via ``get_llm()``
* Sync/async bridge pattern

This module provides those shared building blocks so each new
framework adapter needs only ~50 lines of framework-specific glue.

Usage for new adapter authors::

    from agentic_blueprint.frameworks.llm_bridge import (
        messages_to_dicts,
        response_to_ai_message,
        lazy_get_model,
        sync_from_async,
    )
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import json
import logging
from typing import Any, Coroutine, TypeVar

logger = logging.getLogger(__name__)

__all__ = [
    "messages_to_dicts",
    "response_to_ai_message",
    "lazy_get_model",
    "sync_from_async",
]

T = TypeVar("T")


# ---------------------------------------------------------------------------
# Message conversion: framework messages → OpenAI dicts
# ---------------------------------------------------------------------------

def messages_to_dicts(messages: list) -> list[dict[str, Any]]:
    """Convert LangChain ``BaseMessage`` list to OpenAI-style dicts.

    Handles ``SystemMessage``, ``HumanMessage``, ``AIMessage`` (with
    optional ``tool_calls``), and ``ToolMessage``.  Falls back to
    plain ``{"role", "content"}`` for unknown message types.

    Also accepts plain dicts (pass-through) and strings (→ user message).
    """
    from langchain_core.messages import (
        AIMessage,
        BaseMessage,
        HumanMessage,
        SystemMessage,
        ToolMessage,
    )

    result: list[dict[str, Any]] = []
    for msg in messages:
        # Already a dict — pass through
        if isinstance(msg, dict):
            result.append(msg)
            continue
        # Plain string → user message
        if isinstance(msg, str):
            result.append({"role": "user", "content": msg})
            continue

        content = msg.content if isinstance(msg.content, (str, list)) else str(msg.content)

        if isinstance(msg, SystemMessage):
            result.append({"role": "system", "content": content})
        elif isinstance(msg, HumanMessage):
            result.append({"role": "user", "content": content})
        elif isinstance(msg, AIMessage):
            d: dict[str, Any] = {"role": "assistant", "content": content}
            if msg.tool_calls:
                d["tool_calls"] = [
                    {
                        "id": tc.get("id", ""),
                        "type": "function",
                        "function": {
                            "name": tc.get("name", ""),
                            "arguments": (
                                json.dumps(tc["args"])
                                if isinstance(tc.get("args"), dict)
                                else tc.get("args", "")
                            ),
                        },
                    }
                    for tc in msg.tool_calls
                ]
            result.append(d)
        elif isinstance(msg, ToolMessage):
            result.append({
                "role": "tool",
                "content": content,
                "tool_call_id": msg.tool_call_id,
            })
        else:
            result.append({
                "role": getattr(msg, "role", "user"),
                "content": content,
            })
    return result


# ---------------------------------------------------------------------------
# Response normalization: ChatModel response → LangChain AIMessage
# ---------------------------------------------------------------------------

def response_to_ai_message(response: Any) -> "AIMessage":
    """Convert a ``ChatModel`` response to a LangChain ``AIMessage``.

    Handles:
    * ``dict(role, content, tool_calls?)`` — Responses API (gpt-5 family)
    * ``ChatCompletionMessage`` — Chat Completions API (gpt-4o family)
    """
    from langchain_core.messages import AIMessage

    # --- dict from Responses API ---
    if isinstance(response, dict):
        content = response.get("content", "")
        tool_calls_raw = response.get("tool_calls")
        if tool_calls_raw:
            tool_calls = [
                _parse_tool_call(tc) for tc in tool_calls_raw
            ]
            return AIMessage(content=content, tool_calls=tool_calls)
        return AIMessage(content=content)

    # --- ChatCompletionMessage object ---
    content = getattr(response, "content", None) or ""
    tool_calls_raw = getattr(response, "tool_calls", None)
    if tool_calls_raw:
        tool_calls = [_parse_tool_call_obj(tc) for tc in tool_calls_raw]
        return AIMessage(content=content, tool_calls=tool_calls)

    return AIMessage(content=content)


def _parse_tool_call(tc: dict) -> dict[str, Any]:
    """Parse a tool call from a dict (Responses API format)."""
    fn = tc.get("function", {})
    raw_args = fn.get("arguments", "{}")
    return {
        "id": tc.get("id", ""),
        "name": fn.get("name", ""),
        "args": _safe_parse_args(raw_args),
    }


def _parse_tool_call_obj(tc: Any) -> dict[str, Any]:
    """Parse a tool call from a ChatCompletionMessage.ToolCall object."""
    if hasattr(tc, "function"):
        raw_args = tc.function.arguments
        name = tc.function.name
        tc_id = tc.id
    else:
        fn = tc.get("function", {})
        raw_args = fn.get("arguments", "{}")
        name = fn.get("name", "")
        tc_id = tc.get("id", "")
    return {
        "id": str(tc_id) if tc_id else "",
        "name": name,
        "args": _safe_parse_args(raw_args),
    }


def _safe_parse_args(raw: Any) -> dict:
    """Parse tool call arguments, handling malformed JSON gracefully."""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {"_raw": raw}
    return {"_raw": str(raw)}


# ---------------------------------------------------------------------------
# Response content extraction (for non-LangChain adapters)
# ---------------------------------------------------------------------------

def extract_content(response: Any) -> str:
    """Extract plain text content from a ChatModel response.

    Useful for framework adapters (like CrewAI) that need a string
    rather than a LangChain AIMessage.
    """
    if isinstance(response, dict):
        return str(response.get("content", ""))
    if isinstance(response, str):
        return response
    content = getattr(response, "content", None)
    if content is not None:
        return str(content)
    return str(response)


# ---------------------------------------------------------------------------
# Lazy model initialization
# ---------------------------------------------------------------------------

def lazy_get_model(
    holder: Any,
    attr: str = "_ab_model",
    *,
    model: str = "gpt-4o",
    temperature: float = 0.0,
    max_tokens: int | None = None,
) -> Any:
    """Lazily initialize an Agentic Blueprint ``ChatModel`` on *holder*.

    If ``holder.<attr>`` is ``None``, creates a new ``ChatModel`` via
    ``get_llm()`` and caches it.

    Returns the ``ChatModel`` instance.
    """
    existing = getattr(holder, attr, None)
    if existing is not None:
        return existing

    from agentic_blueprint.core.models import get_llm
    instance = get_llm(model=model, temperature=temperature, max_tokens=max_tokens)
    setattr(holder, attr, instance)
    return instance


# ---------------------------------------------------------------------------
# Sync/async bridge
# ---------------------------------------------------------------------------

def sync_from_async(coro: Coroutine[Any, Any, T]) -> T:
    """Run an async coroutine from a sync context.

    Handles the case where an event loop is already running (e.g.,
    inside Jupyter, Streamlit, or nested framework calls) by
    dispatching to a background thread.

    Uses ``contextvars.copy_context()`` so that observability context
    (trace_id, session_id, project_id, etc.) survives the thread boundary.
    """
    import contextvars

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None
    if loop is not None and loop.is_running():
        ctx = contextvars.copy_context()
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(ctx.run, asyncio.run, coro).result()
    return asyncio.run(coro)
